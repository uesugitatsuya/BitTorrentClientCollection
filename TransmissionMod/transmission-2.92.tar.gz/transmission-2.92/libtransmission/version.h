#define PEERID_PREFIX             "-TR2920-"
#define USERAGENT_PREFIX          "2.92"
#define SVN_REVISION              "14714"
#define SVN_REVISION_NUM          14714
#define SHORT_VERSION_STRING      "2.92"
#define LONG_VERSION_STRING       "2.92 (14714)"
#define VERSION_STRING_INFOPLIST  2.92
#define MAJOR_VERSION             2
#define MINOR_VERSION             92
#define TR_STABLE_RELEASE         1
