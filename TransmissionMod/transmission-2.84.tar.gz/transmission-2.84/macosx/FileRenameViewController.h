//
//  FileRenameViewController.h
//  Transmission
//
//  Created by Mitchell Livingston on 1/20/13.
//  Copyright (c) 2013 The Transmission Project. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FileRenameViewController : NSViewController

@end
