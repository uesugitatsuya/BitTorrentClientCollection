#include <boost/cstdint.hpp>

using boost::uint64_t;
using boost::int64_t;
using boost::int32_t;

