<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Acerca de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="56"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="89"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="121"/>
        <location filename="../gui/about.ui" line="212"/>
        <source>Nationality:</source>
        <translation>Nacionalidad:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="135"/>
        <location filename="../gui/about.ui" line="198"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <location filename="../gui/about.ui" line="205"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="101"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="95"/>
        <source>Current maintainer</source>
        <translation>Encargado actual</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="165"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="249"/>
        <source>Special Thanks</source>
        <translation>Agradecimientos especiales</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="275"/>
        <source>Translators</source>
        <translation>Traductores</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="323"/>
        <source>Libraries</source>
        <translation>Bibliotecas</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="329"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent fue compilado con las siguientes librerías:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="171"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="301"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Guardar en</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="79"/>
        <source>Browse...</source>
        <translation>Examinar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="88"/>
        <source>Set as default save path</source>
        <translation>Establecer como ubicación predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="108"/>
        <source>Never show again</source>
        <translation>No volver a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="125"/>
        <source>Torrent settings</source>
        <translation>Propiedades del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="131"/>
        <source>Set as default category</source>
        <translation>Establecer como categoría predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="140"/>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="201"/>
        <source>Torrent information</source>
        <translation>Información del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="175"/>
        <source>Skip hash check</source>
        <translation>No comprobar hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="254"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="220"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="268"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="247"/>
        <source>Date:</source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Modo de administración del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="98"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Al activarse, el archivo .torrent no sera borrado, no importa cual sea la configuración de &quot;Descargas&quot; de las opciones.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="101"/>
        <source>Do not delete .torrent file</source>
        <translation>No eliminar el archivo .torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="373"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="378"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="383"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="388"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="211"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="217"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="680"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="225"/>
        <source>Invalid torrent</source>
        <translation>Torrent inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="237"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="242"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="271"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="276"/>
        <source>Already in download list</source>
        <translation>Ya está en la lista de descargas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="706"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="707"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="715"/>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="260"/>
        <source>Invalid magnet link</source>
        <translation>Enlace magnet inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="211"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>El archivo torrent &apos;%1&apos; no existe.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="217"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>El archivo torrent &apos;%1&apos; no puede ser leído del disco.
Probablemente no tengas permisos suficientes.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="225"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Fallo al cargar el torrent: %1
Error: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="237"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="271"/>
        <source>Torrent is already in download list. Trackers weren&apos;t merged because it is a private torrent.</source>
        <translation>El torrent ya está en la lista de descargas. Los Trackers no fueron fusionados porque el torrent es privado.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="242"/>
        <source>Torrent is already in download list. Trackers were merged.</source>
        <translation>El torrent ya está en la lista de descargas. Los Trackers fueron fusionados.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="246"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <source>Cannot add torrent</source>
        <translation>No se pudo agregar el torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="246"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>No se pudo agregar este torrent. Tal vez ya se esté agregando.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="260"/>
        <source>This magnet link was not recognized</source>
        <translation>Este enlace magnet no pudo ser reconocido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="276"/>
        <source>Magnet link is already in download list. Trackers were merged.</source>
        <translation>El enlace magnet ya está en la lista de descargas. Los Trackers fueron fusionados.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>No se pudo agregar este torrent. Tal vez ya se esté agregando.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Magnet link</source>
        <translation>Enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="297"/>
        <source>Retrieving metadata...</source>
        <translation>Recibiendo metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="381"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="383"/>
        <source>Free space on disk: %1</source>
        <translation>Espacio libre en disco: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="424"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="426"/>
        <source>Choose save path</source>
        <translation>Elegir ruta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="459"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="460"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="464"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="489"/>
        <source>The file could not be renamed</source>
        <translation>No se pudo renombrar el archivo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="465"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nombre contiene caracteres prohibidos, por favor, elija uno diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="490"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="527"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="526"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se pudo renombrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="586"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="590"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="681"/>
        <source>Invalid metadata</source>
        <translation>Metadatos inválidos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="688"/>
        <source>Parsing metadata...</source>
        <translation>Analizando metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="692"/>
        <source>Metadata retrieval complete</source>
        <translation>Recepción de metadatos completa</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="747"/>
        <source>Download Error</source>
        <translation>Error de descarga</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="265"/>
        <source>Disk write cache size</source>
        <translation>Tamaño de la caché de escritura</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="196"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="285"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Puertos de salida (Min) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="290"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Puertos de salida (Máx) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="293"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar torrents completados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="299"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de actualización de la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="298"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="101"/>
        <source>Setting</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="101"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="194"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="207"/>
        <source>All addresses</source>
        <translation>Todas las direcciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="244"/>
        <source>qBittorrent Section</source>
        <translation>Sección de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="246"/>
        <location filename="../gui/advancedsettings.cpp" line="251"/>
        <source>Open documentation</source>
        <translation>Abrir documentación</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="249"/>
        <source>libtorrent Section</source>
        <translation>Sección de libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="270"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="271"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de expiración de la caché de disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="274"/>
        <source>Enable OS cache</source>
        <translation>Activar caché del S.O.</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="279"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="302"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Resolver países de los pares (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="305"/>
        <source>Resolve peer host names</source>
        <translation>Resolver nombres de host de los pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="313"/>
        <source>Strict super seeding</source>
        <translation>Super-Siembra</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="339"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interfaz de red (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="342"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Dirección IP opcional a escuchar (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="345"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Escuchar en la dirección IPv6 (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="353"/>
        <source>Display notifications</source>
        <translation>Mostrar notificaciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="356"/>
        <source>Display notifications for added torrents</source>
        <translation>Mostrar notificaciones para torrents agregados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="359"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Descargar favicon del tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="379"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmar la verificación del torrent</translation>
    </message>
    <message>
        <source>Exchange trackers with other peers</source>
        <translation type="obsolete">Intercambio de trackers con otros pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="382"/>
        <source>Always announce to all trackers</source>
        <translation>Siempre anunciar a todos los trackers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="315"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Cualquier interfaz</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="280"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Intervalo entre el guardado de datos de reanudación</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="310"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Número máximo de conexiones semi-abiertas [0: Sin límite]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="348"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Dirección IP para informar a los trackers (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="363"/>
        <source>Enable embedded tracker</source>
        <translation>Activar tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="368"/>
        <source>Embedded tracker port</source>
        <translation>Puerto del tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="371"/>
        <source>Check for software updates</source>
        <translation>Comprobar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="375"/>
        <source>Use system icon theme</source>
        <translation>Usar iconos del tema actual</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="132"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciado</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="260"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, ejecutando programa externo , comando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="269"/>
        <source>Torrent: %1, run external program command too long (length &gt; %2), execution failed.</source>
        <translation>Torrent: %1, Comando de programa demasiado largo (longitud &gt; %2), falló la ejecución.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="319"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, enviando correo de notificación</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="424"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="425"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Para controlar qBittorrent, accede a la interfaz Web en http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="426"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>El nombre de usuario del administrador de la interfaz Web es: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="429"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contraseña del administrador de la interfaz Web sigue siendo por defecto: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="430"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Esto es un riesgo de seguridad, por favor considere cambiar su contraseña en las preferencias del programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="593"/>
        <source>Saving torrent progress...</source>
        <translation>Guardando progreso del torrent...</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="218"/>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Descargador RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable Automated RSS Downloader</source>
        <translation>Activar el Descargador RSS Automático.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="48"/>
        <source>Download Rules</source>
        <translation>Reglas de descarga</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="88"/>
        <source>Rule Definition</source>
        <translation>Definición de reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="94"/>
        <source>Use Regular Expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="103"/>
        <source>Must Contain:</source>
        <translation>Debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="110"/>
        <source>Must Not Contain:</source>
        <translation>No debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="117"/>
        <source>Episode Filter:</source>
        <translation>Filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Assign Category:</source>
        <translation>Asignar categoría:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="206"/>
        <source>Save to a Different Directory</source>
        <translation>Guardar en una ruta diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="246"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorar coincidencias posteriores a (0 para deshabilitar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="253"/>
        <source>Disabled</source>
        <translation type="unfinished">Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="259"/>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="292"/>
        <source>Add Paused:</source>
        <translation>Agregar pausado:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="300"/>
        <source>Use global settings</source>
        <translation>Usar preferencias globales</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="305"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="310"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="331"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar regla a los canales:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="353"/>
        <source>Matching RSS Articles</source>
        <translation>Coincidencias de artículos RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="378"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="385"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Filtrar artículos en base al filtro de episodios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Example: </source>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>coincidirá con los episodios 2, 5, del 8 al 15, y del 30 en adelante de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Episode filter rules: </source>
        <translation>Reglas del filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada debe ser distinto de cero</translation>
    </message>
    <message>
        <source>Episode number is a mandatory non-zero value</source>
        <translation type="obsolete">El número de episodio debe ser distinto de cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Filter must end with semicolon</source>
        <translation>El filtro debe finalizar con punto y coma (;)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Son soportados tres tipos de rango de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Un número: &lt;b&gt;1x25;&lt;/b&gt; coincidirá con el episodio 25 de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Un rango: &lt;b&gt;1x25-40;&lt;/b&gt; coincidirá con los episodios del 25 al 40 de la temporada uno</translation>
    </message>
    <message>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one</source>
        <translation type="obsolete">Rango infinito: &lt;b&gt;1x25-;&lt;/b&gt; coincidirá con los episodios del 25 en adelante de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Episode number is a mandatory positive value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="85"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="313"/>
        <source>Last Match: %1 days ago</source>
        <translation>Última coincidencia: %1 días atrás</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="315"/>
        <source>Last Match: Unknown</source>
        <translation>Última coincidencia: Desconocida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>New rule name</source>
        <translation>Nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor, escriba el nombre de la nueva regla de descarga.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="423"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="554"/>
        <source>Rule name conflict</source>
        <translation>Conflicto con el nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="423"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="554"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ya existena una regla con este nombre, por favor, elija otro nombre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="446"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>¿Está seguro de querer eliminar la regla de descarga llamada &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>¿Está seguro que desea eliminar las reglas de descarga seleccionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar la eliminación de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="472"/>
        <source>Destination directory</source>
        <translation>Ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Invalid action</source>
        <translation>Acción no válida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La lista está vacía, no hay nada para exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="484"/>
        <source>Where would you like to save the list?</source>
        <translation>¿Dónde le gustaría guardar la lista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="484"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista de reglas (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="489"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="489"/>
        <source>Failed to create the destination file</source>
        <translation>Error al crear el archivo de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Por favor, seleccione el archivo de reglas de descarga de canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Rules list</source>
        <translation>Lista de reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="501"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="501"/>
        <source>Failed to import the selected rules file</source>
        <translation>Error al importar el archivo de reglas seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="512"/>
        <source>Add new rule...</source>
        <translation>Agregar nueva regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="520"/>
        <source>Rename rule...</source>
        <translation>Renombrar regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="523"/>
        <source>Delete selected rules</source>
        <translation>Eliminar reglas seleccionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="550"/>
        <source>Rule renaming</source>
        <translation>Renombrando regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="550"/>
        <source>Please type the new rule name</source>
        <translation>Por favor, escriba el nombre de la nueva regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="674"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Modo Regex: usar expresiones regulares como en Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="677"/>
        <source>Wildcard mode: you can use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="678"/>
        <source>? to match any single character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="679"/>
        <source>* to match zero or more of any characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="680"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="681"/>
        <source>| is used as OR operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="682"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="689"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="693"/>
        <source> will match all articles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="694"/>
        <source> will exclude all articles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="obsolete">Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para hacer coincidir cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más caracteres&lt;/li&gt;&lt;li&gt;Los espacios en blanco cuentan como operadores AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation type="obsolete">Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para hacer coincidir cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más caracteres&lt;/li&gt;&lt;li&gt;| es usado como operador OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="471"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Es necesario reiniciar para cambiar el soporte PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1252"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Tracker integrado [Activado]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1254"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error al iniciar el tracker integrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1257"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Tracker integrado [Desactivado]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1304"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removing...</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Eliminandolo...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1310"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Pausing...</source>
        <translation>&apos;%1&apos; alcanzó el ratio máximo establecido. Pausandolo...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1922"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>El estado de la red del equipo cambió a %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1922"/>
        <source>ONLINE</source>
        <translation>EN LÍNEA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1922"/>
        <source>OFFLINE</source>
        <translation>FUERA DE LÍNEA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1944"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>La configuración de red de %1 ha cambiado, refrescando la sesión</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1961"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>La interfaz de red configurada %1 no es válida</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2298"/>
        <source>Encryption support [%1]</source>
        <translation>Cifrado [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2299"/>
        <source>FORCED</source>
        <translation>FORZADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2504"/>
        <source>Anonymous mode [%1]</source>
        <translation>Modo Anónimo [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2890"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>No se pudo decodificar el torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3016"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Descarga recursiva del archivo &apos;%1&apos; incluido en el torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3115"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3314"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>No se pudo guardar &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3435"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>porque %1 está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3438"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>porque %1 está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3456"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Falló la búsqueda de la semilla Url: &apos;%1&apos;, mensaje: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3496"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>qBittorrent falló al escuchar en la interfaz %1 puerto: %2/%3. Razón: %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1426"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias y del disco.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1428"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1563"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, por favor espere...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="929"/>
        <location filename="../base/bittorrent/session.cpp" line="2038"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent está tratando de escuchar en cualquier interfaz, puerto: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1980"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfaz de red definida no es válida: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="942"/>
        <location filename="../base/bittorrent/session.cpp" line="2049"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está tratando de escuchar en la interfaz %1 puerto: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="442"/>
        <source>DHT support [%1]</source>
        <translation>DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="442"/>
        <location filename="../base/bittorrent/session.cpp" line="457"/>
        <location filename="../base/bittorrent/session.cpp" line="2299"/>
        <location filename="../base/bittorrent/session.cpp" line="2504"/>
        <source>ON</source>
        <translation>Activado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="442"/>
        <location filename="../base/bittorrent/session.cpp" line="457"/>
        <location filename="../base/bittorrent/session.cpp" line="2299"/>
        <location filename="../base/bittorrent/session.cpp" line="2504"/>
        <source>OFF</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="457"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Buscar pares locales [%1]</translation>
    </message>
    <message>
        <source>Restart is required to toggle Tracker Exchange support</source>
        <translation type="obsolete">Es necesario reiniciar para cambiar el soporte de intercambio de Trackers</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2014"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent no encuentra una dirección local %1 para escuchar</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2042"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent falló tratando de escuchar en cualquier interfaz, Puerto: %1. Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2801"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>El tracker &apos;%1&apos; se agregó al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2811"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>El tracker &apos;%1&apos; se eliminó del torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2826"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>La semilla URL &apos;%1&apos; se agregó al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2832"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>La semilla URL &apos;%1&apos; se eliminó del torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3064"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>No se pudo continuar el torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3141"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas aplicadas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3147"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Falló el análisis del filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3351"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>No se pudo agregar el torrent. Razón: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3297"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; continuado. (continuación rápida)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3328"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; agregado a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3399"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Ocurrió un error de I/O, &apos;%1&apos; pausado. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3407"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Falló el mapeo del puerto, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3413"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Puerto mapeado correctamente, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3423"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>por el filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3426"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>por el filtro de puertos.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3429"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>por restricciones del modo mixto i2p.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3432"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>por tener un puerto bajo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3470"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está escuchando en la interfaz %1 puerto: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3505"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP Externa: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1414"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>No se pudo mover el torrent: &apos;%1&apos;. Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1566"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>El tamaño de archivo no coincide con el torrent &apos;%1&apos;, pausandolo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1572"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Continuación rápida rechazada para el torrent: &apos;%1&apos;, Razón %2. Verificando de nuevo...</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="236"/>
        <source>Categories</source>
        <translation type="unfinished">Categorías</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="391"/>
        <source>All</source>
        <translation type="unfinished">Todos</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="398"/>
        <source>Uncategorized</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="114"/>
        <source>Add category...</source>
        <translation type="unfinished">Agregar categoría...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="122"/>
        <source>Add subcategory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="128"/>
        <source>Remove category</source>
        <translation type="unfinished">Eliminar categoría</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="134"/>
        <source>Remove unused categories</source>
        <translation type="unfinished">Eliminar categorías sin utilizar</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="141"/>
        <source>Resume torrents</source>
        <translation type="unfinished">Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="146"/>
        <source>Pause torrents</source>
        <translation type="unfinished">Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="151"/>
        <source>Delete torrents</source>
        <translation type="unfinished">Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="212"/>
        <source>New Category</source>
        <translation type="unfinished">Nueva categoría</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="212"/>
        <source>Category:</source>
        <translation type="unfinished">Categoría:</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="216"/>
        <source>Invalid category name</source>
        <translation type="unfinished">Nombre de la categoría no válido</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="217"/>
        <source>Category name must not contain &apos;\&apos;.
Category name must not start/end with &apos;/&apos;.
Category name must not contain &apos;//&apos; sequence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="234"/>
        <location filename="../gui/categoryfilterwidget.cpp" line="247"/>
        <source>Category exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="234"/>
        <source>Category name already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="248"/>
        <source>Subcategory name already exists in selected category.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFiltersList</name>
    <message>
        <source>All (0)</source>
        <comment>this is for the category filter</comment>
        <translation type="obsolete">Todos (0)</translation>
    </message>
    <message>
        <source>Uncategorized (0)</source>
        <translation type="obsolete">Sin categorizar (0)</translation>
    </message>
    <message>
        <source>%1 (%2)</source>
        <comment>category_name (10)</comment>
        <translation type="obsolete">%1 (%2)</translation>
    </message>
    <message>
        <source>Uncategorized (%1)</source>
        <translation type="obsolete">Sin categorizar (%1)</translation>
    </message>
    <message>
        <source>Add category...</source>
        <translation type="obsolete">Agregar categoría...</translation>
    </message>
    <message>
        <source>Remove category</source>
        <translation type="obsolete">Eliminar categoría</translation>
    </message>
    <message>
        <source>Remove unused categories</source>
        <translation type="obsolete">Eliminar categorías sin utilizar</translation>
    </message>
    <message>
        <source>Resume torrents</source>
        <translation type="obsolete">Reanudar torrents</translation>
    </message>
    <message>
        <source>Pause torrents</source>
        <translation type="obsolete">Pausar torrents</translation>
    </message>
    <message>
        <source>Delete torrents</source>
        <translation type="obsolete">Eliminar torrents</translation>
    </message>
    <message>
        <source>New Category</source>
        <translation type="obsolete">Nueva categoría</translation>
    </message>
    <message>
        <source>Category:</source>
        <translation type="obsolete">Categoría:</translation>
    </message>
    <message>
        <source>Invalid category name</source>
        <translation type="obsolete">Nombre de la categoría no válido</translation>
    </message>
    <message>
        <source>Category name must not contain &apos;\&apos;.
Category name must not start/end with &apos;/&apos;.
Category name must not contain &apos;//&apos; sequence.</source>
        <translation type="obsolete">El nombre de la categoría no debe contener &apos;\&apos;
El nombre de la categoría no debe contener &apos;//&apos;
El nombre de la categoría no debe comenzar o terminar con &apos;/&apos;.</translation>
    </message>
    <message>
        <source>All (%1)</source>
        <comment>this is for the category filter</comment>
        <translation type="obsolete">Todos (%1)</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Administrar Cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Dominio</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Fecha de caducidad</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>¿Seguro que desea eliminar &apos;%1&apos; de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="50"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>¿Seguro que desea eliminar estos %1 torrents de la lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>White: Missing pieces</source>
        <translation>Blanco: Piezas faltantes</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="178"/>
        <source>Green: Partial pieces</source>
        <translation>Verde: Piezas descargadas parcialmente</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="179"/>
        <source>Blue: Completed pieces</source>
        <translation>Azul: Piezas completadas</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="39"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="106"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue bloqueado %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="108"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue baneado</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="46"/>
        <source>RSS feeds</source>
        <translation>Canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="48"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="168"/>
        <source>An error occured while trying to open the log file. Logging to file is disabled.</source>
        <translation>Ocurrió un error de tratando de escribir el archivo de Logs. El archivo de logs está deshabilitado.</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="65"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="159"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="267"/>
        <source>I/O Error: Could not open ip filter file in read mode.</source>
        <translation>Error de I/O: No se pudo abrir el archivo de filtros IP en modo lectura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="278"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="290"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="311"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="320"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="330"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="340"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="360"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Error de análisis: El archivo de filtros no es un P2B valido de PeerGuardian.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="101"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="131"/>
        <source>Unsupported database file size.</source>
        <translation>El tamaño del archivo de base de datos no es soportado.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Error de metadatos: no se encontró la entrada &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Error de metadatos: la entrada &apos;%1&apos;  tiene un tipo invalido.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="246"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versión de base de datos no soportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="253"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versión de IP no soportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Unsupported record size: %1</source>
        <translation>Tamaño del registro no soportado: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="273"/>
        <source>Invalid database type: %1</source>
        <translation>Tipo de base de datos invalido: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de datos corrupta: no se encontró la sección de datos.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Exit qBittorrent</source>
        <translation>Salir de qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Only one link per line</source>
        <translation>Solamente un enlace por línea</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de subida debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>El límite alternativo de la tasa de descarga debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>El número máximo de descargas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>El número máximo de subidas activas debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>El número máximo de torrents activos debe ser mayor que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo de puestos de subida por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Error al guardar las preferencias del programa, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>El puerto utilizado para conexiones entrantes debe estar comprendido entre 1 y 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>El puerto utilizado para la interfaz Web debe estar comprendido entre 1 y 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Error al iniciar sesión, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>Invalid Username or Password.</source>
        <translation>Nombre de usuario o contraseña inválidos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>Upload Failed!</source>
        <translation>Error al subir!</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Original authors</source>
        <translation>Autores originales</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Upload limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Download limit:</source>
        <translation>Límite de descarga:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="116"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Subir Torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Seeding</source>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Resumed</source>
        <translation>Reanudados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="83"/>
        <source>Paused</source>
        <translation>Pausados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="84"/>
        <source>Active</source>
        <translation>Activos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Inactive</source>
        <translation>Inactivos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Save files to location:</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Type folder here</source>
        <translation>Escribir carpeta aquí</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Run an external program on torrent completion</source>
        <translation>Ejecutar un programa externo al completar el torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Habilitar gestión de ancho de banda (µTP)</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Aplicar límite para conexiones µTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Limites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="94"/>
        <source>More information</source>
        <translation>Más Información</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="95"/>
        <source>Information about certificates</source>
        <translation>Información sobre certificados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="96"/>
        <source>Save Files to</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="97"/>
        <source>Watch Folder</source>
        <translation>Carpeta vigilada</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="98"/>
        <source>Default Folder</source>
        <translation>Carpeta predeterminada</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="103"/>
        <source>from</source>
        <comment>from time1 to time2</comment>
        <translation>Desde las</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="104"/>
        <source>to</source>
        <comment>from time1 to time2</comment>
        <translation>hasta</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="105"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Otro...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="106"/>
        <source>Every day</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Todos los días</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="107"/>
        <source>Week days</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Días laborales</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="108"/>
        <source>Week ends</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Fines de semana</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="109"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lunes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="110"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Martes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="111"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Miércoles</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="112"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Jueves</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="113"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Viernes</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="114"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sábado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="115"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Domingo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="102"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Logout</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Download from URLs</source>
        <translation>Descargar de URLs</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Descargar torrents desde sus URL o enlaces magnet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Upload local torrent</source>
        <translation>Subir torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>¿Seguro que desea eliminar los torrents seleccionados de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Imposible conectar a qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>The following parameters are supported:</source>
        <translation>Están soportados los siguientes parámetros:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Torrent path</source>
        <translation>Ruta del torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Torrent name</source>
        <translation>Nombre del torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent se ha cerrado.</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../gui/lineedit/src/lineedit.cpp" line="35"/>
        <source>Clear the text</source>
        <translation>Borrar texto</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Al finalizar las &amp;descargas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="98"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="178"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="188"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reanudar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="221"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Crear torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="226"/>
        <source>Set Upload Limit...</source>
        <translation>Establecer límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="231"/>
        <source>Set Download Limit...</source>
        <translation>Establecer límite de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="241"/>
        <source>Set Global Download Limit...</source>
        <translation>Límite global de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="246"/>
        <source>Set Global Upload Limit...</source>
        <translation>Límite global de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="251"/>
        <source>Minimum Priority</source>
        <translation>Mínima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="259"/>
        <source>Top Priority</source>
        <translation>Máxima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="267"/>
        <source>Decrease Priority</source>
        <translation>Disminuir prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="275"/>
        <source>Increase Priority</source>
        <translation>Incrementar prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="286"/>
        <location filename="../gui/mainwindow.ui" line="289"/>
        <source>Alternative Speed Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="297"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="300"/>
        <source>Display Top Toolbar</source>
        <translation>Mostrar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="308"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Velocidad en la barra de título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="311"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar Velocidad de Transferencia en la Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="319"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="327"/>
        <source>Search &amp;Engine</source>
        <translation>Motor de Búsqu&amp;eda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="332"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Bl&amp;oquear qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="343"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="198"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eanudar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="414"/>
        <source>Manage Cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="417"/>
        <source>Manage stored network cookies</source>
        <translation>Administrar cookies de red almacenadas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="433"/>
        <source>Normal Messages</source>
        <translation>Mensajes Normales</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="441"/>
        <source>Information Messages</source>
        <translation>Mensajes de Información</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="449"/>
        <source>Warning Messages</source>
        <translation>Mensajes de advertencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="457"/>
        <source>Critical Messages</source>
        <translation>Mensajes Críticos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="102"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="354"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Salir de &amp;qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="362"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="370"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="378"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Apagar Equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="386"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="401"/>
        <source>&amp;Statistics</source>
        <translation>E&amp;stadísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="406"/>
        <source>Check for Updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="409"/>
        <source>Check for Program Updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="183"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="193"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="208"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="203"/>
        <source>P&amp;ause All</source>
        <translation>Pa&amp;usar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="165"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Agregar archivo torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="168"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="173"/>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="216"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="236"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="335"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="391"/>
        <location filename="../gui/mainwindow.ui" line="425"/>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1614"/>
        <source>Check for program updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="213"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Agregar &amp;enlace torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="346"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si le gusta qBittorrent, por favor realice una donación!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1643"/>
        <source>Execution Log</source>
        <translation>Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="578"/>
        <source>Clear the password</source>
        <translation>Borrar la contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="211"/>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="181"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Establecer Contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="183"/>
        <source>&amp;Clear Password</source>
        <translation>Limpiar C&amp;ontraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="230"/>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="384"/>
        <source>Torrent file association</source>
        <translation>Asociación de archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="385"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no es la aplicación por defecto para abrir archivos torrent o enlaces magnet.
¿Quiere que qBittorrent sea el programa por defecto para gestionar estos archivos?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="467"/>
        <source>Icons Only</source>
        <translation>Solo iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="469"/>
        <source>Text Only</source>
        <translation>Solo texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="471"/>
        <source>Text Alongside Icons</source>
        <translation>Texto al lado de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="473"/>
        <source>Text Under Icons</source>
        <translation>Texto debajo de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="475"/>
        <source>Follow System Style</source>
        <translation>Usar estilo del equipo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="562"/>
        <location filename="../gui/mainwindow.cpp" line="590"/>
        <location filename="../gui/mainwindow.cpp" line="915"/>
        <source>UI lock password</source>
        <translation>Contraseña de bloqueo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="562"/>
        <location filename="../gui/mainwindow.cpp" line="590"/>
        <location filename="../gui/mainwindow.cpp" line="915"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor, escriba la contraseña de bloqueo:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="566"/>
        <source>The password should contain at least 3 characters</source>
        <translation>La contraseña debe tener como mínimo 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="571"/>
        <source>Password update</source>
        <translation>Actualizar contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="571"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contraseña de bloqueo de qBittorrent se ha actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="578"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>¿Seguro que desea borrar la contraseña?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="629"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="735"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="735"/>
        <source>Failed to add torrent: %1</source>
        <translation>Error al agregar torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="742"/>
        <source>Torrent added</source>
        <translation>Torrent agregado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="742"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; fue agregado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="748"/>
        <source>Download completion</source>
        <translation>Descarga completada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="754"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="836"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación de descargas recursivas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="837"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="838"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="839"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="860"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite de velocidad de subida global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="873"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite de velocidad de descarga global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1018"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1019"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1020"/>
        <source>&amp;Always Yes</source>
        <translation>S&amp;iempre sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1533"/>
        <source>Old Python Interpreter</source>
        <translation>Intérprete de Python antiguo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1533"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Su versión de Python (%1) está desactualizada. Por favor actualizela a la ultima versión para poder utilizar el motor de búsqueda. La versión mínima es: 2.7.9/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1598"/>
        <source>qBittorrent Update Available</source>
        <translation>Actualización de qBittorrent disponible</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1599"/>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation>Hay una nueva versión disponible.
¿Desea descargar %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1608"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Ya está utilizando la versión mas reciente de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1543"/>
        <source>Undetermined Python version</source>
        <translation>Versión de Python indeterminada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="748"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; se ha descargado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="754"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Se produjo un error de I/O en el torrent &apos;%1&apos;.
Razón: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="836"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Este torrent &apos;%1&apos; contiene archivos torrent, ¿Desea seguir adelante con su descarga?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="851"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>No se pudo descargar el archivo desde la URL: &apos;%1&apos;, razón: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1515"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>Python encontrado en %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1543"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>No se pudo determinar su versión de Python (%1). Motor de búsqueda deshabilitado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1554"/>
        <location filename="../gui/mainwindow.cpp" line="1566"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta el intérprete de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1555"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python es necesario para utilizar el motor de búsqueda pero no parece que esté instalado.
¿Desea instalarlo ahora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1566"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python es necesario para utilizar el motor de búsqueda pero no parece que esté instalado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1609"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>No hay actualizaciones disponibles.
Ya está utilizando la versión mas reciente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1613"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1757"/>
        <source>Checking for Updates...</source>
        <translation>Buscando actualizaciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1758"/>
        <source>Already checking for program updates in the background</source>
        <translation>Ya se están buscando actualizaciones del programa en segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1774"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python encontrado en &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>La instalación de Python no se pudo realizar, la razón: %1.
Por favor, instálelo de forma manual.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="566"/>
        <location filename="../gui/mainwindow.cpp" line="930"/>
        <source>Invalid password</source>
        <translation>Contraseña no válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="608"/>
        <location filename="../gui/mainwindow.cpp" line="619"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="851"/>
        <source>URL download error</source>
        <translation>Error descargando de URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="930"/>
        <source>The password is invalid</source>
        <translation>La contraseña no es válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1317"/>
        <location filename="../gui/mainwindow.cpp" line="1324"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. descarga: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1320"/>
        <location filename="../gui/mainwindow.cpp" line="1326"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. subida: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1332"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[B: %1, S: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1015"/>
        <source>Exiting qBittorrent</source>
        <translation>Cerrando qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1016"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Algunos archivos aún están transfiriéndose.
¿Está seguro de querer cerrar qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1158"/>
        <source>Open Torrent Files</source>
        <translation>Abrir archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1159"/>
        <source>Torrent Files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1194"/>
        <source>Options were saved successfully.</source>
        <translation>Opciones guardadas correctamente.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="197"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>El DNS dinámico se actualizó correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="202"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error del DNS dinámico: El servicio no está disponible temporalmente, nuevo reintento en 30 minutos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="212"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error del DNS dinámico: El nombre de host proporcionado no existe en la cuenta especificada.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="218"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error del DNS dinámico: El nombre de usuario/contraseña no es válido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="224"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: qBittorrent ha sido incluido en la Lista Negra por el servicio, por favor, informar de ésto en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="231"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: %1 fue rechazado por el servicio, por favor, informe de este error en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="238"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error del DNS dinámico: Su nombre de usuario fue bloqueado debido a excesos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="259"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error del DNS dinámico: El nombre de dominio proporcionado no válido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="270"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error del DNS dinámico: El nombre de usuario proporcionado es demasiado corto.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="281"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error del DNS dinámico: La contraseña proporcionada demasiado corta.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="104"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="117"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>El tamaño de archivo es %1. Excede el limite de descarga de %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="186"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redirección inesperada hacia un enlace magnet.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="103"/>
        <location filename="../base/net/geoipmanager.cpp" line="430"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Base de datos GeoIP cargada. Tipo: %1. Creada el: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="107"/>
        <location filename="../base/net/geoipmanager.cpp" line="451"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>No se pudo cargar la base de datos GeoIP. Razon: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Viet Nam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <location filename="../base/net/geoipmanager.cpp" line="396"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="142"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="143"/>
        <source>United Arab Emirates</source>
        <translation>Emiratos Árabes Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Afghanistan</source>
        <translation>Afganistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua y Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Anguilla</source>
        <translation>Anguila</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Albania</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Armenia</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Antarctica</source>
        <translation>Antártida</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>American Samoa</source>
        <translation>Samoa Americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Austria</source>
        <translation>Austria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Azerbaijan</source>
        <translation>Azerbaiyán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnia y Herzegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bangladesh</source>
        <translation>Bangladés</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Belgium</source>
        <translation>Bélgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Bulgaria</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Bahrain</source>
        <translation>Baréin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Benin</source>
        <translation>Benín</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Bermuda</source>
        <translation>Bermudas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Brunei Darussalam</source>
        <translation>Brunéi Darussalam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Bhutan</source>
        <translation>Bután</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bouvet Island</source>
        <translation>Isla Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Botswana</source>
        <translation>Botsuana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Belarus</source>
        <translation>Bielorrusia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Belize</source>
        <translation>Belice</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Canada</source>
        <translation>Canadá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Islas Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>República Democrática del Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Central African Republic</source>
        <translation>República Centroafricana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Switzerland</source>
        <translation>Suiza</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Cook Islands</source>
        <translation>Islas Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cameroon</source>
        <translation>Camerún</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Colombia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cape Verde</source>
        <translation>Cabo Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Curacao</source>
        <translation>Curazao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Christmas Island</source>
        <translation>Isla de Navidad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Cyprus</source>
        <translation>Chipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Czech Republic</source>
        <translation>República Checa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Germany</source>
        <translation>Alemania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Djibouti</source>
        <translation>Yibuti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Algeria</source>
        <translation>Argelia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Estonia</source>
        <translation>Estonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Egypt</source>
        <translation>Egipto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Western Sahara</source>
        <translation>Sahara Occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Spain</source>
        <translation>España</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Ethiopia</source>
        <translation>Etiopía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Finland</source>
        <translation>Finlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Fiji</source>
        <translation>Fiyi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Islas Malvinas (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Micronesia, Federated States of</source>
        <translation>Estados Federados de Micronesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Faroe Islands</source>
        <translation>Islas Feroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Gabon</source>
        <translation>Gabón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>United Kingdom</source>
        <translation>Reino Unido</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Georgia</source>
        <translation>Georgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>French Guiana</source>
        <translation>Guayana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Greenland</source>
        <translation>Groenlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Ecuatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Islas Georgias del Sur y Sandwich del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bisáu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Islas Heard y McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Croatia</source>
        <translation>Croacia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Haiti</source>
        <translation>Haití</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Hungary</source>
        <translation>Hungría</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Indonesia</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>India</source>
        <translation>India</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territorio Británico del Océano Índico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Irán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iceland</source>
        <translation>Islandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Italy</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jordan</source>
        <translation>Jordania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Japan</source>
        <translation>Japón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Kyrgyzstan</source>
        <translation>Kirguistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Cambodia</source>
        <translation>Camboya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Comoros</source>
        <translation>Comoras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Saint Kitts and Nevis</source>
        <translation>San Cristóbal y Nieves</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Corea del Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Korea, Republic of</source>
        <translation>Corea del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Cayman Islands</source>
        <translation>Islas Caimán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kazakhstan</source>
        <translation>Kazajistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Lebanon</source>
        <translation>Líbano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Saint Lucia</source>
        <translation>Santa Lucía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Lesotho</source>
        <translation>Lesoto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Lithuania</source>
        <translation>Lituania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Luxembourg</source>
        <translation>Luxemburgo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Latvia</source>
        <translation>Letonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Morocco</source>
        <translation>Marruecos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Monaco</source>
        <translation>Mónaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Moldova, Republic of</source>
        <translation>Moldavia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Marshall Islands</source>
        <translation>Islas Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Mali</source>
        <translation>Malí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Myanmar</source>
        <translation>Birmania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mongolia</source>
        <translation>Mongolia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Northern Mariana Islands</source>
        <translation>Islas Marianas del Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Mauritania</source>
        <translation>Mauritania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Mauritius</source>
        <translation>Mauricio</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Maldives</source>
        <translation>Maldivas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Malawi</source>
        <translation>Malaui</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Mexico</source>
        <translation>México</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malaysia</source>
        <translation>Malasia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>New Caledonia</source>
        <translation>Nueva Caledonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Norfolk Island</source>
        <translation>Isla Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Netherlands</source>
        <translation>Países Bajos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>New Zealand</source>
        <translation>Nueva Zelanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Oman</source>
        <translation>Omán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>French Polynesia</source>
        <translation>Polinesia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Papua New Guinea</source>
        <translation>Papúa Nueva Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Philippines</source>
        <translation>Filipinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Pakistan</source>
        <translation>Pakistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Poland</source>
        <translation>Polonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>San Pedro y Miquelón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palau</source>
        <translation>Palaos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Qatar</source>
        <translation>Catar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Reunion</source>
        <translation>Reunión</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Romania</source>
        <translation>Rumanía </translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Russian Federation</source>
        <translation>Rusia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Saudi Arabia</source>
        <translation>Arabia Saudita</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Solomon Islands</source>
        <translation>Islas Salomón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Sudan</source>
        <translation>Sudán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Sweden</source>
        <translation>Suecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Slovenia</source>
        <translation>Eslovenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard y Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovakia</source>
        <translation>Eslovaquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leona</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Sao Tome and Principe</source>
        <translation>Santo Tomé y Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Syrian Arab Republic</source>
        <translation>Siria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Swaziland</source>
        <translation>Suazilandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Turks and Caicos Islands</source>
        <translation>Islas Turcas y Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Chad</source>
        <translation>Chad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>French Southern Territories</source>
        <translation>Tierras Australes y Antárticas Francesas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Thailand</source>
        <translation>Tailandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Tajikistan</source>
        <translation>Tayikistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Tunisia</source>
        <translation>Túnez</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Timor-Leste</source>
        <translation>Timor Oriental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Costa de Marfil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Libya</source>
        <translation>Libia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Saint Martin (French part)</source>
        <translation>San Martín (Parte Francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Pitcairn</source>
        <translation>Islas Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Palestine, State of</source>
        <translation>Palestina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Elena, Ascensión y Tristán de Acuña</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>South Sudan</source>
        <translation>Sudán del Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (Parte neerlandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Turkey</source>
        <translation>Turquía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad y Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Taiwan</source>
        <translation>Taiwán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Ukraine</source>
        <translation>Ucrania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Islas Ultramarinas Menores de Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>United States</source>
        <translation>Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Santa Sede (Estado de la ciudad del Vaticano)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>San Vicente y las Granadinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Virgin Islands, British</source>
        <translation>Islas Vírgenes Británicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Islas Vírgenes de los Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis y Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Yemen</source>
        <translation>Yemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Serbia</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>South Africa</source>
        <translation>Sudáfrica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Zambia</source>
        <translation>Zambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Zimbabwe</source>
        <translation>Zimbabue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Aland Islands</source>
        <translation>Åland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Isle of Man</source>
        <translation>Isla de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Saint Barthelemy</source>
        <translation>San Bartolomé</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="419"/>
        <source>Could not uncompress GeoIP database file.</source>
        <translation>No se pudo descomprimir el archivo de base de datos GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="440"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>No se pudo guardar la base de datos GeoIP descargada.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="443"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Base de datos GeoIP actualizada correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="458"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>No se pudo descargar la base de datos GeoIP. Razon: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="127"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [Activado]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="143"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [Desactivado]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="510"/>
        <source>Email Notification Error:</source>
        <translation>Error en la notificación por E-mail:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdlg.ui" line="14"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="57"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="62"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="67"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="77"/>
        <source>Web UI</source>
        <translation>Interfaz Web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="82"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="128"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="136"/>
        <source>User Interface Language:</source>
        <translation>Idioma de la interfaz:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="164"/>
        <source>(Requires restart)</source>
        <translation>(Es necesario reiniciar qBittorrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="192"/>
        <source>Transfer List</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="198"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar al eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="208"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternar colores en la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="220"/>
        <source>Hide zero and infinity values</source>
        <translation>Ocultar los valores cero e infinito</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="228"/>
        <source>Always</source>
        <translation>Siempre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="233"/>
        <source>Paused torrents only</source>
        <translation>Solo torrents pausados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="262"/>
        <source>Action on double-click</source>
        <translation>Acción a realizar con un doble-click</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="271"/>
        <source>Downloading torrents:</source>
        <translation>Torrents descargando:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="288"/>
        <location filename="../gui/optionsdlg.ui" line="314"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="293"/>
        <location filename="../gui/optionsdlg.ui" line="319"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="298"/>
        <location filename="../gui/optionsdlg.ui" line="324"/>
        <source>No action</source>
        <translation>Sin acción</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="306"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="338"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="344"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent cuando arranque Windows</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="351"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar pantalla de bienvenida al iniciar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="361"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="368"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmación al salir mientras haya torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="378"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirmar la salida automática cuando las descargas finalicen</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="388"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostrar qBittorrent en el área de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="397"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar qBittorrent en el area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="407"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Cerrar qBittorrent al area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="416"/>
        <source>Tray icon style:</source>
        <translation>Estilo del icono del area de notificación:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="424"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="429"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromo (tema oscuro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="434"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromo (tema claro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="447"/>
        <source>File association</source>
        <translation>Asociación de archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="453"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar qBittorrent para los archivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="460"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar qBittorrent para los enlaces magnet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="473"/>
        <source>Power Management</source>
        <translation>Administración de energía</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="479"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhabilitar la suspensión del equipo cuando queden torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="489"/>
        <source>Log file</source>
        <translation>Archivo de logs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="503"/>
        <source>Save path:</source>
        <translation>Ruta Destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="533"/>
        <source>Backup the log file after:</source>
        <translation>Respaldar el archivo de logs después de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="540"/>
        <source> MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="576"/>
        <source>Delete backup logs older than:</source>
        <translation>Eliminar logs de más antiguos que:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="600"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="605"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>meses</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="610"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>años</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="684"/>
        <source>When adding a torrent</source>
        <translation>Al agregar un torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="690"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar el contenido del torrent y opciones</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="702"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Traer el diálogo del torrent al frente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="715"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciar las descargas de forma automática</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="722"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>Debería el archivo .torrent ser borrado después de ser agregado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="725"/>
        <source>Delete .torrent files afterwards </source>
        <translation>Después eliminar el archivo .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="737"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>También eliminar archivos .torrent si su agregado fue cancelado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="740"/>
        <source>Also when addition is cancelled</source>
        <translation>También cuando su agregado es cancelado.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="762"/>
        <source>Warning! Data loss possible!</source>
        <translation>¡Peligro! Perdida de datos posible.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="777"/>
        <source>Saving Management</source>
        <translation>Administración de guardado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="785"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Administración de Torrents predeterminada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="797"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="801"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="806"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="829"/>
        <source>When Torrent Category changed:</source>
        <translation>Cuando cambia la categoría del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="839"/>
        <source>Relocate torrent</source>
        <translation>Reubicar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="844"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Cambiar torrent a modo manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="867"/>
        <source>When Default Save Path changed:</source>
        <translation>Cuando la ubicación de guardado predeterminada cambia:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="880"/>
        <location filename="../gui/optionsdlg.ui" line="921"/>
        <source>Relocate affected torrents</source>
        <translation>Reubicar los torrents afectados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="885"/>
        <location filename="../gui/optionsdlg.ui" line="926"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Cambiar los torrents afectados a modo manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="908"/>
        <source>When Category changed:</source>
        <translation>Cuando cambia la categoría:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="951"/>
        <source>Use Subcategories</source>
        <translation>Usar subcategorias:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="960"/>
        <source>Default Save Path:</source>
        <translation>Ubicación de guardado predeterminada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1006"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantener torrents incompletos en:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1045"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar archivos .torrent en:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1078"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar archivos .torrent de descargas finalizadas a:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1113"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar espacio en el disco para todos los archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1120"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Agregar la extensión .!qB a los archivos incompletos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1130"/>
        <source>Automatically add torrents from:</source>
        <translation>Agregar automáticamente los torrents de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1177"/>
        <source>Add entry</source>
        <translation>Agregar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1187"/>
        <source>Remove entry</source>
        <translation>Eliminar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1214"/>
        <source>Email notification upon download completion</source>
        <translation>Notificar por correo electrónico de la finalización de las descargas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1231"/>
        <source>Destination email:</source>
        <translation>Dirección de correo electrónico:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1238"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1250"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requiere una conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1257"/>
        <location filename="../gui/optionsdlg.ui" line="1669"/>
        <location filename="../gui/optionsdlg.ui" line="2806"/>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1269"/>
        <location filename="../gui/optionsdlg.ui" line="1683"/>
        <location filename="../gui/optionsdlg.ui" line="2845"/>
        <location filename="../gui/optionsdlg.ui" line="2920"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1279"/>
        <location filename="../gui/optionsdlg.ui" line="1693"/>
        <location filename="../gui/optionsdlg.ui" line="2852"/>
        <location filename="../gui/optionsdlg.ui" line="2934"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1299"/>
        <source>Run external program on torrent completion</source>
        <translation>Ejecutar un programa externo al completar el torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1359"/>
        <source>Listening Port</source>
        <translation>Puerto de escucha</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1367"/>
        <source>Port used for incoming connections:</source>
        <translation>Puerto utilizado para conexiones entrantes:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1387"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1409"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar reenvío de puertos UPnP / NAT-PMP de mi router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1419"/>
        <source>Use different port on each startup</source>
        <translation>Usar un puerto diferente en cada inicio</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1429"/>
        <source>Connections Limits</source>
        <translation>Límites de conexión</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1445"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Máximo de conexiones por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1455"/>
        <source>Global maximum number of connections:</source>
        <translation>Máximo de conexiones totales:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1494"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Máximo de puestos de subida por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1504"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Máximo total de puestos de subida:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1543"/>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1551"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1559"/>
        <source>(None)</source>
        <translation>(Ninguno)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1564"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1569"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1574"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1585"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1605"/>
        <location filename="../gui/optionsdlg.ui" line="2630"/>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1633"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Sino, el servidor proxy se utilizará solamente para las conexiones al tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1636"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para las conexiones a los pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1643"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Deshabilitar conexiones no soportadas por los proxis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1653"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Canales RSS, motores de búsqueda. actualizaciones del software o cualquier otra cosa que no sean transferencias de torrents y operaciones relacionadas (como intercambio de pares) usarán una conexión directa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1656"/>
        <source>Use proxy only for torrents</source>
        <translation>Usar proxy solo para torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1709"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: La contraseña se guarda sin cifrar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1722"/>
        <source>IP Filtering</source>
        <translation>Filtrado IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1736"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta del filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1765"/>
        <source>Reload the filter</source>
        <translation>Actualizar el filtro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1774"/>
        <source>Apply to trackers</source>
        <translation>Aplicar a los trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1832"/>
        <source>Global Rate Limits</source>
        <translation>Limites globales de velocidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1854"/>
        <location filename="../gui/optionsdlg.ui" line="2045"/>
        <source>Upload:</source>
        <translation>Subida:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1861"/>
        <location filename="../gui/optionsdlg.ui" line="1884"/>
        <location filename="../gui/optionsdlg.ui" line="2091"/>
        <location filename="../gui/optionsdlg.ui" line="2098"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1898"/>
        <location filename="../gui/optionsdlg.ui" line="2052"/>
        <source>Download:</source>
        <translation>Bajada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1921"/>
        <source>Alternative Rate Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1927"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar el uso de límites alternativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1939"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Desde las:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1963"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Hasta:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1990"/>
        <source>When:</source>
        <translation>Cuándo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2004"/>
        <source>Every day</source>
        <translation>Todos los días</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2009"/>
        <source>Weekdays</source>
        <translation>Días laborales</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2014"/>
        <source>Weekends</source>
        <translation>Fines de semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2121"/>
        <source>Rate Limits Settings</source>
        <translation>Configuración de los limites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2127"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar el límite a los pares en LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2134"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límite para el exceso de transporte (Overhead)</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2141"/>
        <source>Enable µTP protocol</source>
        <translation>Activar protocolo µTP</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2148"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar límite para conexiones µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2219"/>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2225"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (red descentralizada) para encontrar más pares</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2235"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercambiar pares con clientes Bittorrent compatibles (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2238"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercambio de pares (PeX) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2248"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar pares en su red local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2251"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar busqueda local de pares para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2263"/>
        <source>Encryption mode:</source>
        <translation>Modo de cifrado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2271"/>
        <source>Prefer encryption</source>
        <translation>Preferir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2276"/>
        <source>Require encryption</source>
        <translation>Exigir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2281"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar cifrado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2306"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilitar cuando se use un proxy o un VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2309"/>
        <source>Enable anonymous mode</source>
        <translation>Activar modo anónimo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2316"/>
        <source> (&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Más información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2344"/>
        <source>Torrent Queueing</source>
        <translation>Torrents en cola</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2359"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de descargas activas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2379"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de subidas activas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2399"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents activos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2458"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>No contar torrents lentos en estos límites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2468"/>
        <source>Share Ratio Limiting</source>
        <translation>Limite de ratio de compartición</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2479"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sembrar torrents hasta que su ratio sea</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2508"/>
        <source>then</source>
        <translation>luego</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2519"/>
        <source>Pause them</source>
        <translation>Pausarlos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2524"/>
        <source>Remove them</source>
        <translation>Eliminarlos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2543"/>
        <source>Automatically add these trackers to new downloads:</source>
        <translation>Agregar automáticamente estos trackers a las descargas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2616"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Habilitar interfaz Web (Control remoto)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2665"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP para redirigir el puerto de mi router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2675"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS en lugar de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2706"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2718"/>
        <source>Import SSL Certificate</source>
        <translation>Importar certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2759"/>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2771"/>
        <source>Import SSL Key</source>
        <translation>Importar clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2793"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Información acerca de los certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2838"/>
        <source>Bypass authentication for localhost</source>
        <translation>Eludir la autenticación para localhost</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2862"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar mi nombre de dominio dinámico</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2874"/>
        <source>Service:</source>
        <translation>Servicio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2897"/>
        <source>Register</source>
        <translation>Registro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2906"/>
        <source>Domain name:</source>
        <translation>Nombre de dominio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="102"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Al activar estas opciones, puedes &lt;strong&gt;perder permanentemente&lt;/strong&gt; tus archivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="104"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Cuando estas opciones estén habilitadas, qBittorrent &lt;strong&gt;eliminará&lt;/strong&gt; los archivos .torrent después de ser exitosamente (la primera opción) o no (la segunda opción) agregado a la lista de descargas. Esto aplicará &lt;strong&gt;no solo&lt;/strong&gt; a los archivos abiertos por &amp;ldquo;Abrir torrent&amp;rdquo; del menú, sino a aquellos abiertos por su asociación de &lt;strong&gt;tipo de archivo&lt;/strong&gt; también.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="109"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Si habilitas la segunda opción (&amp;ldquo;También cuando la agregado es cancelado&amp;rdquo;) el archivo .torrent &lt;strong&gt; será borrado &lt;/strong&gt; incluso si elijes &amp;ldquo;&lt;strong&gt;Cancelar&lt;/strong&gt;&amp;rdquo; en la ventana de &amp;ldquo;Agregar torrent&amp;rdquo; </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="248"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parámetros soportados (sensible a mayúsculas):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="249"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nombre del torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="250"/>
        <source>%L: Category</source>
        <translation>%L: Categoría</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="251"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Ruta del contenido (misma ruta que la raíz para torrents muilti-archivo)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="252"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Ruta Raíz (primer subdirectorio del torrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="253"/>
        <source>%D: Save path</source>
        <translation>%D: Ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="254"/>
        <source>%C: Number of files</source>
        <translation>%C: Cantidad de archivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="255"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamaño del torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="256"/>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker actual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="257"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="258"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Consejo: Encapsula el parámetro con comillas para evitar que el texto sea cortado en un espacio (ej: &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1359"/>
        <source>Select folder to monitor</source>
        <translation>Seleccione una carpeta para monitorear</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1366"/>
        <source>Folder is already being monitored:</source>
        <translation>Esta carpeta ya está monitoreada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1369"/>
        <source>Folder does not exist:</source>
        <translation>La carpeta no existe:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1372"/>
        <source>Folder is not readable:</source>
        <translation>La carpeta no es legible:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1383"/>
        <source>Adding entry failed</source>
        <translation>Fallo al agregar entrada </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1411"/>
        <location filename="../gui/optionsdlg.cpp" line="1413"/>
        <source>Choose export directory</source>
        <translation>Selecciona una ruta de exportación</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1423"/>
        <location filename="../gui/optionsdlg.cpp" line="1425"/>
        <location filename="../gui/optionsdlg.cpp" line="1460"/>
        <location filename="../gui/optionsdlg.cpp" line="1462"/>
        <location filename="../gui/optionsdlg.cpp" line="1473"/>
        <location filename="../gui/optionsdlg.cpp" line="1475"/>
        <source>Choose a save directory</source>
        <translation>Seleccione una ruta para guardar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1448"/>
        <source>Choose an IP filter file</source>
        <translation>Seleccione un archivo de filtro IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1448"/>
        <source>All supported filters</source>
        <translation>Todos los filtros soportados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1515"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1527"/>
        <source>SSL Key</source>
        <translation>Clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1559"/>
        <source>Parsing error</source>
        <translation>Error de análisis</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1559"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No se ha podido analizar el filtro IP proporcionado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1561"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1561"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas fueron aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1653"/>
        <source>Invalid key</source>
        <translation>Clave no válida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1653"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta no es una clave SSL válida.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1672"/>
        <source>Invalid certificate</source>
        <translation>Certificado no válido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1672"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este no es un Certificado SSL válido.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1683"/>
        <source>Time Error</source>
        <translation>Error de tiempo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1683"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Los tiempos de inicio y finalización no pueden ser iguales.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1692"/>
        <location filename="../gui/optionsdlg.cpp" line="1696"/>
        <source>Length Error</source>
        <translation>Error de longitud</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1692"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nombre de usuario de la interfaz Web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1696"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>La contraseña de Interfaz de Usuario Web debe ser de al menos 6 caracteres.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="293"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interesado(local) y bloqueado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="299"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interesado(local) y no bloqueado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="308"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interesado(par) y bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="314"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interesado(par) y no bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="322"/>
        <source>optimistic unchoke</source>
        <translation>desbloqueo optimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="329"/>
        <source>peer snubbed</source>
        <translation>par descartado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="336"/>
        <source>incoming connection</source>
        <translation>Conexión entrante</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="343"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>no interesado(local) y no bloqueado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="350"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>no interesado(par) y no bloqueado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="357"/>
        <source>peer from PEX</source>
        <translation>par de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="364"/>
        <source>peer from DHT</source>
        <translation>par de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="371"/>
        <source>encrypted traffic</source>
        <translation>trafico cifrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="378"/>
        <source>encrypted handshake</source>
        <translation>negociación cifrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="393"/>
        <source>peer from LSD</source>
        <translation>par de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Flags</source>
        <translation>Banderas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="84"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Importancia</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="85"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Archivos</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="162"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="239"/>
        <source>Add a new peer...</source>
        <translation>Agregar nuevo par...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="247"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="285"/>
        <source>Ban peer permanently</source>
        <translation>Prohibir este par permanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Agregando manualmente el par &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="263"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>El par no se pudo agregar al torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="296"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Prohibiendo manualmente al par &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="267"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="269"/>
        <source>Peer addition</source>
        <translation>Agregar par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Country</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="245"/>
        <source>Copy IP:port</source>
        <translation>Copiar IP:puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="267"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Algunos pares no pudieron agregarse. Revisa el log para obtener más detalles.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="269"/>
        <source>The peers were added to this torrent.</source>
        <translation>Los pares se agregaron a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="285"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>¿Seguro que desea prohibir permanentemente los pares seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="286"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="286"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="58"/>
        <source>No peer entered</source>
        <translation>No se ha introducido ningún par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="59"/>
        <source>Please type at least one peer.</source>
        <translation>Por favor introduce al menos un par.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="69"/>
        <source>Invalid peer</source>
        <translation>Par invalido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="70"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>El par &apos;%1&apos; es invalido.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="163"/>
        <source>White: Unavailable pieces</source>
        <translation>Blanco: Piezas no disponibles</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="164"/>
        <source>Blue: Available pieces</source>
        <translation>Azul: Piezas disponibles</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="265"/>
        <source>Files in this piece:</source>
        <translation>Archivos en esta pieza:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="269"/>
        <source>File in this piece</source>
        <translation>Archivo en esta pieza</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="271"/>
        <source>File in these pieces</source>
        <translation>Archivo en estas piezas</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="289"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Mantén Shift para información detallada</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Plugins de búsqueda instalados:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="50"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="55"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="60"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="65"/>
        <location filename="../gui/search/pluginselectdlg.ui" line="121"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="83"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Puedes obtener nuevos plugins de búsqueda aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="95"/>
        <source>Install a new one</source>
        <translation>Instalar uno nuevo</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="102"/>
        <source>Check for updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="109"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="126"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="161"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="223"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="282"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="165"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="204"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="227"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="286"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="210"/>
        <source>Uninstall warning</source>
        <translation>Advertencia de desinstalación</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="210"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Algunos plugins no pudieron ser desinstalados porque vienen incluidos en qBittorrent. Solamente pueden desinstalarse los que han sido agregados por ti.
En su lugar, esos plugins fueron deshabilitados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="212"/>
        <source>Uninstall success</source>
        <translation>Desinstalación correcta</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="212"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Todos los plugins seleccionados fueron desinstalados correctamente</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="332"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="339"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nuevo plugin de motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="333"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="340"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="337"/>
        <source>Invalid link</source>
        <translation>Enlace inválido</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="337"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>El enlace no parece contener un plugin de búsqueda.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="353"/>
        <source>Select search plugins</source>
        <translation>Seleccione los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="354"/>
        <source>qBittorrent search plugin</source>
        <translation>Plugin de búsqueda de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="394"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="407"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="436"/>
        <source>Search plugin update</source>
        <translation>Actualización de los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="394"/>
        <source>All your plugins are already up to date.</source>
        <translation>Todos los plugins ya están actualizados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="407"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>No se pudo buscar actualizaciones de plugins. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="414"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="420"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="429"/>
        <source>Search plugin install</source>
        <translation>Instalar plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="414"/>
        <source>&quot;%1&quot; search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda &quot;%1&quot; fue instalado correctamente.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="420"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>No se pudo instalar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="429"/>
        <source>&quot;%1&quot; search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda &quot;%1&quot; fue actualizado correctamente.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="436"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>No se pudo actualizar el plugin de motor de búsqueda &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Fuente del plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Fuente del plugin de búsqueda:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="36"/>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="43"/>
        <source>Web link</source>
        <translation>Enlace web</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../gui/previewselect.cpp" line="54"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="55"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="56"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Preview impossible</source>
        <translation>Imposible previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>No se pudo previsualizar este archivo</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="130"/>
        <source>Not downloaded</source>
        <translation>No descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="139"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="188"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="187"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation type="unfinished">No descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="133"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="obsolete">N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="136"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="46"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="56"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="61"/>
        <source>HTTP Sources</source>
        <translation>Fuentes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="66"/>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="73"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Disponibilidad:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tiempo activo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Tiempo restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocidad de descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocidad de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Límite de descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Desperdiciado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Conexiones:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1020"/>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1027"/>
        <source>Select None</source>
        <translation>Seleccionar ninguno</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1103"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1098"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Ratio de compartición:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Anunciar en:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Ultima vez visto completo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Tamaño total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Piezas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Creado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Agregado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Completado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Creado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Hash del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1093"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1085"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="440"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="447"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tienes %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="392"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="395"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 en esta sesión)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="404"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrado durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="411"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="424"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="428"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="432"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="436"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 prom.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="582"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="583"/>
        <source>Open Containing Folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="584"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="589"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="639"/>
        <source>New Web seed</source>
        <translation>Nueva semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="645"/>
        <source>Remove Web seed</source>
        <translation>Eliminar semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="647"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="648"/>
        <source>Edit Web seed URL</source>
        <translation>Editar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="674"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="675"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="679"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="706"/>
        <source>The file could not be renamed</source>
        <translation>No se pudo renombrar el archivo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="680"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nombre introducido contiene caracteres prohibidos, por favor elija otro.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="707"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="749"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="748"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se pudo renombrar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="856"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="83"/>
        <source>Filter files...</source>
        <translation>Filtrar archivos...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="796"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nueva semilla URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="797"/>
        <source>New URL seed:</source>
        <translation>Nueva semilla URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="803"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="857"/>
        <source>This URL seed is already in the list.</source>
        <translation>Esta semilla URL ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="849"/>
        <source>Web seed editing</source>
        <translation>Editando semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="850"/>
        <source>Web seed URL:</source>
        <translation>URL de la semilla Web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="114"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Su dirección IP ha sido bloqueada debido a demasiados intentos fallados de autenticación.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="422"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Error: &apos;%1&apos; no es un archivo torrent valido.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="430"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Error: No se pudo agregar el torrent a la sesión.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="439"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Error de I/O: No se pudo crear un archivo temporal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="155"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 es un parámetro de la línea de comandos desconocido.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="167"/>
        <location filename="../app/main.cpp" line="180"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 debe ser el único parámetro de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="190"/>
        <source>%1 must specify the correct port (1 to 65535).</source>
        <translation>%1 debe especificar el puerto correcto (entre 1 y 65535).</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="214"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>No puedes usar %1: qBittorrent ya se está ejecutando para este usuario.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="407"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="422"/>
        <source>Displays program version</source>
        <translation>Muestra la versión del programa</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="424"/>
        <source>Displays this help message</source>
        <translation>Muestra este mensaje de ayuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="426"/>
        <source>Changes the Web UI port (current: %1)</source>
        <translation>Cambia el puerto de la interfaz Web (actual: %1)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="429"/>
        <source>Disable splash screen</source>
        <translation>Desactivar pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="431"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Ejecutar en modo servicio (segundo plano)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="433"/>
        <source>Downloads the torrents passed by the user</source>
        <translation>Descarga los torrents pasados por el usuario</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="443"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="452"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Ejecuta la aplicación con la opción -h para obtener información sobre los parámetros de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="454"/>
        <source>Bad command line</source>
        <translation>Parámetros de la línea de comandos incorrectos</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="460"/>
        <source>Bad command line: </source>
        <translation>Parámetros de la línea de comandos incorrectos:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="473"/>
        <source>Legal Notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="474"/>
        <location filename="../app/main.cpp" line="484"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent es un programa para compartir archivos. Cuando se descarga un torrent, los datos del mismo se pondrán a disposición de los demás usuarios por medio de las subidas. Cualquier contenido que usted comparta, lo hace bajo su propia responsabilidad.

No se le volverá a notificar sobre esto.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="475"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pulse la tecla %1 para aceptar y continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="485"/>
        <source>Legal notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="486"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="487"/>
        <source>I Agree</source>
        <translation>Estoy de acuerdo</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="293"/>
        <source>Torrent name: %1</source>
        <translation>Nombre del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="294"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="295"/>
        <source>Save path: %1</source>
        <translation>Guardar en: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="296"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt se descargó en %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="299"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gracias por utilizar qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="305"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; ha terminado de descargarse</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="204"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The operation was canceled</source>
        <translation>La operación fue cancelada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remoto cerró la conexión prematuramente, antes de que se recibiera y procesara toda la respuesta</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The connection to the remote server timed out</source>
        <translation>La conexión con el servidor remoto ha agotado el tiempo de espera</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Handshake SSL/TLS fallido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La conexión con el servidor proxy fué rechazada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>El servidor proxy cerró la conexión antes de tiempo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy host name was not found</source>
        <translation>No se encontró el nombre del servidor proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La conexión con el servidor proxy ha agotado el tiempo de espera o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>El proxy requiere autenticación para poder atender la solicitud, pero no aceptó las credenciales proporcionadas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>La operación solicitada en el contenido remoto no está permitida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contenido remoto no se encontró en el servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remoto requiere autenticación para servir el contenido, pero no se aceptaron las credenciales proporcionadas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>La API de acceso a la red no pudo cumplir con la solicitud debido a que el protocolo es desconocido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>An unknown network-related error was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con la red</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con el proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con el contenido remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Se ha detectado una ruptura en el protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="61"/>
        <location filename="../app/upgrade.h" line="74"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Actualizaste desde una versión anterior que guardaba las cosas de forma diferente. Debes migrar al nuevo sistema de guardado. Si continuas, no podrás volver a usar una versión anterior a v3.3.0. ¿Continuar? [y/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="73"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Actualizaste desde una versión anterior que guardaba las cosas de forma diferente. Debes migrar al nuevo sistema de guardado. Si continuas, no podrás volver a usar una versión anterior a v3.3.0.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="184"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>No se pudo migrar el torrent con el hash: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="187"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>No se pudo migrar el torrent. Nombre del archivo de continuación rapida invalido: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="271"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>Se ha detectado un cierre inesperado. Usando el archivo de respaldo para restaurar la configuración.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="334"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Ocurrió un error de acceso tratando de escribir el archivo de configuración.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="336"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Ocurrió un error de formato tratando de escribir el archivo de configuración.</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../gui/rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="25"/>
        <source>New subscription</source>
        <translation>Nueva subscripción</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="32"/>
        <location filename="../gui/rss/rss.ui" line="171"/>
        <location filename="../gui/rss/rss.ui" line="174"/>
        <source>Mark items read</source>
        <translation>Marcar como leídos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="42"/>
        <source>Update all</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="62"/>
        <source>RSS Downloader...</source>
        <translation>Descargador RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="69"/>
        <source>Settings...</source>
        <translation>Configuración...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="97"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (doble-click para descargar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="134"/>
        <location filename="../gui/rss/rss.ui" line="137"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="142"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="145"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="150"/>
        <location filename="../gui/rss/rss.ui" line="153"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="158"/>
        <source>New subscription...</source>
        <translation>Nueva suscripción...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="163"/>
        <location filename="../gui/rss/rss.ui" line="166"/>
        <source>Update all feeds</source>
        <translation>Actualizar todos los canales</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="179"/>
        <source>Download torrent</source>
        <translation>Descargar torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="184"/>
        <source>Open news URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="189"/>
        <source>Copy feed URL</source>
        <translation>Copiar URL del canal</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="194"/>
        <source>New folder...</source>
        <translation>Nueva carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="39"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar canales RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="198"/>
        <source>Stream URL:</source>
        <translation>URL del canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="198"/>
        <source>Please type a RSS stream URL</source>
        <translation>Por favor escribe una URL de un Canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="208"/>
        <source>This RSS feed is already in the list.</source>
        <translation>Esta fuente de RSS ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="151"/>
        <source>Please choose a folder name</source>
        <translation>Por favor elija un nombre para la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="151"/>
        <source>Folder name:</source>
        <translation>Nombre de la carpeta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="151"/>
        <source>New folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="239"/>
        <source>Deletion confirmation</source>
        <translation>Confirmar eliminación</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="240"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>¿Esta seguro de querer eliminar los canales RSS seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="393"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor, elija un nuevo nombre para el canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="393"/>
        <source>New feed name:</source>
        <translation>Nombre del nuevo canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="397"/>
        <source>Name already in use</source>
        <translation>Ese nombre ya está en uso</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="397"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Ese nombre ya está siendo usado por otro elemento, por favor, elija otro.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="568"/>
        <source>Date: </source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="570"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="647"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>Rss::Feed</name>
    <message>
        <location filename="../base/rss/rssfeed.cpp" line="391"/>
        <source>Automatic download of &apos;%1&apos; from &apos;%2&apos; RSS feed failed because it doesn&apos;t contain a torrent or a magnet link...</source>
        <translation>La descarga automática de &apos;%1&apos; desde el canal RSS &apos;%2&apos; falló debido a que no contiene un torrent o un enlace magnet...</translation>
    </message>
    <message>
        <location filename="../base/rss/rssfeed.cpp" line="396"/>
        <source>Automatically downloading &apos;%1&apos; torrent from &apos;%2&apos; RSS feed...</source>
        <translation>Descargando automáticamente el torrent &apos;%1&apos; desde el canal RSS &apos;%2&apos;...</translation>
    </message>
</context>
<context>
    <name>Rss::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rssparser.cpp" line="248"/>
        <source>Invalid RSS feed.</source>
        <translation>Canal RSS inválido.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Ajustes del lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="32"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Intervalo de actualización de canales RSS:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="39"/>
        <source> min</source>
        <translation>min</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="55"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artículos por canal:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Select save location</source>
        <translation>Seleccione la ubicación de guardado</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="151"/>
        <source>Monitored Folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="154"/>
        <source>Override Save Location</source>
        <translation>Cambiar ubicación de guardado</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Monitored folder</source>
        <translation>Carpeta Monitoreada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Default save location</source>
        <translation>Ubicación de guardado predeterminada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="399"/>
        <source>Browse...</source>
        <translation>Examinar...</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../base/searchengine.cpp" line="171"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Formato de plugin de motor de búsqueda desconocido.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="185"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Una versión más reciente del plugin ya está instalada.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="213"/>
        <location filename="../base/searchengine.cpp" line="216"/>
        <source>Plugin is not supported.</source>
        <translation>Plugin no soportado.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="357"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>El servidor de actualizaciones no está disponible temporalmente. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="375"/>
        <location filename="../base/searchengine.cpp" line="377"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Error al descargar el plugin. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="638"/>
        <source>An incorrect update info received.</source>
        <translation>La información de actualización recibida es incorrecta.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="662"/>
        <source>All categories</source>
        <translation>Todas las categorías</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="663"/>
        <source>Movies</source>
        <translation>Películas</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="664"/>
        <source>TV shows</source>
        <translation>Programas de TV</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="665"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="666"/>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="667"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="668"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="669"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="670"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="59"/>
        <location filename="../gui/search/searchlistdelegate.cpp" line="64"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="84"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="85"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="86"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="87"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="88"/>
        <source>Search engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="214"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados (mostrando &lt;i&gt;%1&lt;/i&gt; de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="264"/>
        <source>Torrent names only</source>
        <translation>Solo nombres de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="265"/>
        <source>Everywhere</source>
        <translation>En todas partes</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="277"/>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="279"/>
        <source>Search has finished</source>
        <translation>La búsqueda ha finalizado</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="281"/>
        <source>Search aborted</source>
        <translation>Búsqueda abortada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="283"/>
        <source>An error occurred during search...</source>
        <translation>Ha ocurrido un error durante la búsqueda...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="285"/>
        <source>Search returned no results</source>
        <translation>La búsqueda no ha devuelto resultados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="329"/>
        <source>Column visibility</source>
        <translation type="unfinished">Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Resultados(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="45"/>
        <source>Search in:</source>
        <translation>Buscar en:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everyhing returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Algunos motores de búsqueda, buscan en la descripción del torrent y también en los nombres de archivo. Este modo controla si esos resultados son o no mostrados.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Todo &lt;/span&gt;deshabilita el filtrado y muestra todo lo devuelto por los motores de búsqueda.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Solo nombres de torrent&lt;/span&gt; muestra solo los torrents cuyo nombre coincide con los términos de búsqueda.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establece el número mínimo y máximo de sembradores permitidos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número mínimo de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="116"/>
        <location filename="../gui/search/searchtab.ui" line="204"/>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Máximo numero de semillas&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/search/searchtab.ui" line="126"/>
        <location filename="../gui/search/searchtab.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Establecer los tamaños mínimos y máximos permitidos de un torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="170"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño mínimo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño máximo del torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="226"/>
        <location filename="../gui/search/searchwidget.cpp" line="252"/>
        <location filename="../gui/search/searchwidget.cpp" line="319"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="72"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="82"/>
        <source>Go to description page</source>
        <translation>Ir a la página de la descripción</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="92"/>
        <source>Copy description page URL</source>
        <translation>Copiar URL de la descripción</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="112"/>
        <source>Search plugins...</source>
        <translation>Plugins de búsqueda...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="82"/>
        <source>A phrase to search for.</source>
        <translation>Una frase a buscar.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="83"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Los espacios de una búsqueda pueden ser protegidos por comillas dobles.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="85"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="87"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: buscar &lt;b&gt;foo&lt;/b&gt; y &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="91"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: buscar &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="143"/>
        <source>All plugins</source>
        <translation>Todos los motores</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="142"/>
        <source>Only enabled</source>
        <translation>Solo habilitados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="144"/>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="244"/>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <location filename="../gui/search/searchwidget.cpp" line="325"/>
        <source>Search Engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="244"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Por favor, instala Python para usar el motor de búsqueda.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="262"/>
        <source>Empty search pattern</source>
        <translation>Patrón de búsqueda vacío</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="262"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor, escriba un patrón de búsqueda primero</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="298"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <source>Search has finished</source>
        <translation>La búsqueda ha terminado</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="325"/>
        <source>Search has failed</source>
        <translation>La búsqueda ha fallado</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="113"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorrent se cerrará ahora.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="115"/>
        <source>E&amp;xit Now</source>
        <translation>&amp;Salir ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="116"/>
        <source>Exit confirmation</source>
        <translation>Confirmar salida</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="119"/>
        <source>The computer is going to shutdown.</source>
        <translation>El equipo se apagará.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="121"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Apagar ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="125"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>El equipo  entrará en modo suspensión.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="127"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Suspender Ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="128"/>
        <source>Suspend confirmation</source>
        <translation>Confirmar Suspensión</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="131"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>El equipo entrará en modo hibernación.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="133"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Hibernar Ahora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="134"/>
        <source>Hibernate confirmation</source>
        <translation>Confirmar Hibernación</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="144"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Puedes cancelar la acción durante %1 segundos.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="122"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmar al cerrar</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="78"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Total Upload</source>
        <translation>Subida total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Download</source>
        <translation>Descarga total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Payload Upload</source>
        <translation>Subida útil </translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Download</source>
        <translation>Descarga útil</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>Overhead Upload</source>
        <translation>Subida exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Download</source>
        <translation>Descarga exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>DHT Upload</source>
        <translation>Subida DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="72"/>
        <source>Tracker Upload</source>
        <translation>Subida tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Download</source>
        <translation>Descarga tracker</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="66"/>
        <source>Period:</source>
        <translation>Periodo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="69"/>
        <source>1 Minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="70"/>
        <source>5 Minutes</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>30 Minutes</source>
        <translation>30 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>6 Hours</source>
        <translation>6 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="101"/>
        <source>Select Graphs</source>
        <translation>Seleccionar gráficas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="77"/>
        <source>Total Upload</source>
        <translation>Subida total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="78"/>
        <source>Total Download</source>
        <translation>Descarga total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="79"/>
        <source>Payload Upload</source>
        <translation>Subida útil </translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Payload Download</source>
        <translation>Descarga útil</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Overhead Upload</source>
        <translation>Subida exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Overhead Download</source>
        <translation>Descarga exceso</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>DHT Upload</source>
        <translation>Subida DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Tracker Upload</source>
        <translation>Subida tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Tracker Download</source>
        <translation>Descarga tracker</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadísticas del usuario</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Total de pares conectados:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Ratio global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Total descargado:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Total subido:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Desperdiciado (esta sesión):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadísticas de la caché</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Uso de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Tiempo promedio en cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Tamaño total de los buffers:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendimiento</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Trabajos de I/O en cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga de la caché de escritura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamaño total de cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="243"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="101"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="66"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="66"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hay conexiones directas. Esto puede indicar problemas en la configuración de red.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="86"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="156"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>Es necesario reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="166"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent ha sido actualizado y debe ser reiniciado para que los cambios sean efectivos.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fuera de línea. Esto normalmente significa que qBittorrent no puede escuchar el puerto seleccionado para las conexiones entrantes.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="237"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Click para cambiar a los límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="232"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Click para cambiar a los límites de velocidad normales</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="247"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Cambio de límites en modo manual. El programador está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="256"/>
        <source>Global Download Speed Limit</source>
        <translation>Máxima velocidad global de descarga</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="269"/>
        <source>Global Upload Speed Limit</source>
        <translation>Máxima velocidad global de subida</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="118"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="121"/>
        <source>Downloading (0)</source>
        <translation>Descargando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="124"/>
        <source>Seeding (0)</source>
        <translation>Sembrando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="127"/>
        <source>Completed (0)</source>
        <translation>Completados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="130"/>
        <source>Resumed (0)</source>
        <translation>Reanudados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="133"/>
        <source>Paused (0)</source>
        <translation>Pausados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="136"/>
        <source>Active (0)</source>
        <translation>Activos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="139"/>
        <source>Inactive (0)</source>
        <translation>Inactivos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="142"/>
        <source>Errored (0)</source>
        <translation>Con errores (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="159"/>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="160"/>
        <source>Downloading (%1)</source>
        <translation>Descargando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Seeding (%1)</source>
        <translation>Sembrando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="162"/>
        <source>Completed (%1)</source>
        <translation>Completados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="163"/>
        <source>Paused (%1)</source>
        <translation>Pausados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="164"/>
        <source>Resumed (%1)</source>
        <translation>Reanudados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>Active (%1)</source>
        <translation>Activos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Inactive (%1)</source>
        <translation>Inactivos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="167"/>
        <source>Errored (%1)</source>
        <translation>Con errores (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Download Priority</source>
        <translation>Prioridad de descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Remaining</source>
        <translation>Restante</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="78"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccione una carpeta para agregar al torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="92"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccione un archivo para agregar al torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>No input path set</source>
        <translation>No se ha establecido la ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>Please type an input path first</source>
        <translation>Por favor escriba primero una ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Select destination torrent file</source>
        <translation>Seleccione el torrent de destino</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Archivos Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully: %1</source>
        <comment>%1 is the path of the torrent</comment>
        <translation>El torrent se creó correctamente: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Crear nuevo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>La creación del torrent no ha fallado, razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>El torrent creado no es válido. No se agregará a la lista de descargas.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tiempo Restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Agregado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite Subida</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Desc. Sesión</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Sub. Sesión</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tiempo Activo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Ruta Destino</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límite de ratio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Visto Completo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última Actividad</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamaño Total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="187"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="190"/>
        <source>Trackerless (0)</source>
        <translation>Sin tracker (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="193"/>
        <source>Error (0)</source>
        <translation>Error (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="196"/>
        <source>Warning (0)</source>
        <translation>Advertencia (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="240"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="295"/>
        <source>Trackerless (%1)</source>
        <translation>Sin tracker (%1)</translation>
    </message>
    <message>
        <source>%1 (%2)</source>
        <comment>openbittorrent.com (10)</comment>
        <translation type="obsolete">%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="333"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="365"/>
        <source>Error (%1)</source>
        <translation>Error (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="346"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="380"/>
        <source>Warning (%1)</source>
        <translation>Advertencia (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="430"/>
        <source>Resume torrents</source>
        <translation>Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="431"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="432"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="466"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="480"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="69"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="70"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="71"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="72"/>
        <source>Seeds</source>
        <translation type="unfinished">Semillas</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="73"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="74"/>
        <source>Downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="75"/>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="224"/>
        <location filename="../gui/properties/trackerlist.cpp" line="311"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="225"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="246"/>
        <source>This torrent is private</source>
        <translation>Este torrent es privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="315"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="319"/>
        <source>Not working</source>
        <translation>No funciona</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="323"/>
        <source>Not contacted yet</source>
        <translation>Todavía no contactado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="415"/>
        <source>Tracker URL:</source>
        <translation>URL del tracker:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="415"/>
        <source>Tracker editing</source>
        <translation>Editando tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="421"/>
        <location filename="../gui/properties/trackerlist.cpp" line="432"/>
        <source>Tracker editing failed</source>
        <translation>Falló la edición del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="421"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>La URL del tracker es inválida.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="432"/>
        <source>The tracker URL already exists.</source>
        <translation>La URL del tracker ya existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="483"/>
        <source>Add a new tracker...</source>
        <translation>Agregar nuevo tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="489"/>
        <source>Copy tracker URL</source>
        <translation>Copiar URL del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="490"/>
        <source>Edit selected tracker URL</source>
        <translation>Editar el tracker seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="495"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forzar recomunicación con los trackers seleccionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="497"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forzar recomunicación con todos los trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="488"/>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo para agregar trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers a agregar (uno por línea):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Lista de URL compatible con μTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="79"/>
        <source>I/O Error</source>
        <translation>Error de I/O</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="79"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error al intentar abrir el archivo descargado.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="117"/>
        <source>No change</source>
        <translation>Sin cambios</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="117"/>
        <source>No additional trackers were found.</source>
        <translation>No se encontró ningún tracker adicional.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="125"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="125"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La lista de trackers no pudo ser descargada. Razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="240"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="246"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Descargando metadatos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="252"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Reservando espacio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="276"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="263"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>En cola</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="256"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="243"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="249"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="259"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="267"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="270"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>En cola para verificación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="273"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Verificando datos de reanudación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="279"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="282"/>
        <source>Missing Files</source>
        <translation>Faltan archivos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="285"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Con errores</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="133"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrado durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="199"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>hace %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="560"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="568"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="586"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="523"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="261"/>
        <source>Choose save path</source>
        <translation>Seleccione una ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="454"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límite de velocidad de descarga del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="479"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límite de velocidad de subida del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="511"/>
        <source>Recheck confirmation</source>
        <translation>Confirmación de comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="511"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>¿Esta seguro que desea comprobar los torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="620"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="620"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="640"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reanudar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="644"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forzar reanudación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="642"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="593"/>
        <source>New Category</source>
        <translation>Nueva categoría</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="593"/>
        <source>Category:</source>
        <translation>Categoría:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="596"/>
        <source>Invalid category name</source>
        <translation>Nombre de la categoría no válido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="597"/>
        <source>Category name must not contain &apos;\&apos;.
Category name must not start/end with &apos;/&apos;.
Category name must not contain &apos;//&apos; sequence.</source>
        <translation>El nombre de la categoría no debe contener &apos;\&apos;
El nombre de la categoría no debe contener &apos;//&apos;
El nombre de la categoría no debe comenzar o terminar con &apos;/&apos;.
</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="646"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="648"/>
        <source>Preview file...</source>
        <translation>Previsualizar archivo...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="650"/>
        <source>Limit share ratio...</source>
        <translation>Límitar ratio de compartición...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="652"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="654"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="656"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="658"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="660"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="662"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover al principio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="664"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover al final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="666"/>
        <source>Set location...</source>
        <translation>Establecer destino...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="672"/>
        <source>Copy name</source>
        <translation>Copiar nombre</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="682"/>
        <source>Download first and last pieces first</source>
        <translation>Descargar antes primeras y últimas partes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="685"/>
        <source>Automatic Torrent Management</source>
        <translation>Administración automática de torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="687"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El moto automático hace que varias propiedades del torrent (por ej: la ruta de guardado) sean decididas por la categoría asociada. </translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="785"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="786"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nueva...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="787"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Descategorizar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="842"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="668"/>
        <source>Force recheck</source>
        <translation>Forzar verificación de archivo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="670"/>
        <source>Copy magnet link</source>
        <translation>Copiar enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="674"/>
        <source>Super seeding mode</source>
        <translation>Modo supersiembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="677"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="679"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites de ratio de subida/descarga</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Usar límite de ratio global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Sin límites de ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Establecer límite de ratio en</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="775"/>
        <source>Incorrect category name</source>
        <translation>Nombre de la categoría incorrecto</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="85"/>
        <source>The Web UI is listening on port %1</source>
        <translation>La interfaz Web está escuchando en el puerto %1</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="87"/>
        <source>Web UI Error - Unable to bind Web UI to port %1</source>
        <translation>Error de la interfaz de Usuario Web - No se puede enlazar al puerto %1</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="63"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un cliente BitTorrent avanzado programado en C++, basado en el toolkit Qt y en libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="64"/>
        <source>Copyright %1 2006-2016 The qBittorrent project</source>
        <translation>Copyright ©2006-2016 El proyecto qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="65"/>
        <source>Home Page:</source>
        <translation>Página Web:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="66"/>
        <source>Forum:</source>
        <translation>Foro: </translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="67"/>
        <source>Bug Tracker:</source>
        <translation>Bug Tracker: </translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Agregar pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one per line):</source>
        <translation>Lista de pares a agregar (uno por línea):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:puerto / [IPv6]:puerto</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autenticación del tracker</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Usuario:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="154"/>
        <source>Log in</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmar borrado - qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recordar siempre esta elección</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Eliminar también los archivos del disco duro</translation>
    </message>
</context>
<context>
    <name>confirmShutdownDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>No volver a mostrar</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="308"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Herramienta de creación de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Creación de un nuevo archivo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="60"/>
        <source>Add file</source>
        <translation>Nuevo archivo</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="67"/>
        <source>Add folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Archivo o carpeta a agregar al torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>Semillas Web URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="98"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Puedes separar los grupos de trackers con una linea vacía.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Tamaño de la pieza:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="165"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="170"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="175"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="180"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="185"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="190"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="195"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="200"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="205"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="210"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="215"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="223"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="248"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privado (no se distribuirá por la red DHT si se marca)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="255"/>
        <source>Start seeding after creation</source>
        <translation>Comenzar la siembra después de la creación</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar los límites de ratio para este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="301"/>
        <source>Create and save...</source>
        <translation>Crear y guardar...</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Agregar enlace torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="58"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Solo uno por línea (pueden ser enlaces HTTP, enlaces magnet o info-hashes)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="80"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="87"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descargar de URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>No URL entered</source>
        <translation>No se ha introducido ninguna URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>Please type at least one URL.</source>
        <translation>Por favor introduce al menos una URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Información del problema</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/utils/fs.cpp" line="420"/>
        <location filename="../base/utils/fs.cpp" line="427"/>
        <location filename="../base/utils/fs.cpp" line="437"/>
        <location filename="../base/utils/fs.cpp" line="470"/>
        <location filename="../base/utils/fs.cpp" line="482"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="87"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="88"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="89"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="90"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="91"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="92"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="290"/>
        <source>Python not detected</source>
        <translation>Python no detectado</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="319"/>
        <source>Python version: %1</source>
        <translation>Versión de Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="365"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="457"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="462"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="358"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="124"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Todas las descargas se han completado. qBittorrent apagará el equipo ahora.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="448"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="452"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="512"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="510"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="514"/>
        <source>Not working</source>
        <translation>No funciona</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="508"/>
        <source>Not contacted yet</source>
        <translation>Aún no contactado</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Previsualizar selección</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="26"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Los siguientes archivos pueden previzualizarse, por favor seleccione uno de ellos:</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="61"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="68"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>
