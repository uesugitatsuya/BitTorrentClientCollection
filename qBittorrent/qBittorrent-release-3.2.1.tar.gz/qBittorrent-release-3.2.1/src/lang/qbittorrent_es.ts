<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Acerca de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="83"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="216"/>
        <location filename="../gui/about.ui" line="293"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="240"/>
        <location filename="../gui/about.ui" line="281"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="228"/>
        <location filename="../gui/about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="262"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Encargado actual</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="354"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="412"/>
        <source>Libraries</source>
        <translation>Bibliotecas</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="424"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Esta versión de qBittorrent fue construida con las siguientes bibliotecas:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="184"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="382"/>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="399"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Gracias a</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="53"/>
        <source>Browse...</source>
        <translation>Examinar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="62"/>
        <source>Set as default save path</source>
        <translation>Establecer como ubicación predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="72"/>
        <source>Never show again</source>
        <translation>No volver a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Torrent settings</source>
        <translation>Propiedades del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="95"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="126"/>
        <source>Skip hash check</source>
        <translation>No comprobar hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="136"/>
        <source>Torrent Information</source>
        <translation>Información del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="158"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="172"/>
        <source>Date:</source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="186"/>
        <source>Info Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="277"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="282"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="287"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="292"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="192"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="643"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="192"/>
        <source>The torrent file does not exist.</source>
        <translation>El archivo torrent no existe.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="207"/>
        <source>Invalid torrent</source>
        <translation>Torrent inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="207"/>
        <source>Failed to load the torrent: %1</source>
        <translation>Fallo al cargar el torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="236"/>
        <source>Already in download list</source>
        <translation>Ya está en la lista de descargas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <source>Torrent is already in download list. Merging trackers.</source>
        <translation>El torrent ya está en la lista de descargas. Fusionando trackers.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="236"/>
        <source>Magnet link is already in download list. Merging trackers.</source>
        <translation>El enlace magnet ya está en la lista de descargas. Fusionando trackers.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="317"/>
        <source>Free disk space: %1</source>
        <translation>Espacio libre en disco: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="644"/>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="660"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="661"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="670"/>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="230"/>
        <source>Invalid magnet link</source>
        <translation>Enlace magnet inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="230"/>
        <source>This magnet link was not recognized</source>
        <translation>Este enlace magnet no pudo ser reconocido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="243"/>
        <source>Magnet link</source>
        <translation>Enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="253"/>
        <source>Retrieving metadata...</source>
        <translation>Recibiendo metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="315"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="346"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="354"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="356"/>
        <source>Choose save path</source>
        <translation>Elegir ruta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="406"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="407"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="411"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="436"/>
        <source>The file could not be renamed</source>
        <translation>No se puede renombrar el archivo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="412"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nombre contiene caracteres prohibidos, por favor, elija uno diferente</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="437"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="472"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="471"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se puede renombrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="529"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="533"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="637"/>
        <source>Parsing metadata...</source>
        <translation>Analizando metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="641"/>
        <source>Metadata retrieval complete</source>
        <translation>Recepción de metadatos completa</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.h" line="190"/>
        <source>Disk write cache size</source>
        <translation>Tamaño de la caché de escritura</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="171"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="210"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Puertos de salida (Min) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="215"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Puertos de salida (Máx) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="221"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar torrents completados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="227"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de actualización de la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="226"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="53"/>
        <source>Setting</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="53"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="169"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="195"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="196"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de expiración de la caché de disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="199"/>
        <source>Enable OS cache</source>
        <translation>Activar caché del S.O.</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="204"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="230"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Resolver países de los pares (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="233"/>
        <source>Resolve peer host names</source>
        <translation>Resolver nombres de host de los pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="238"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Número máximo de conexiones semi-abiertas [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="241"/>
        <source>Strict super seeding</source>
        <translation>Siembra super estricta</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="261"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interfaz de red (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="264"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Escuchar en la dirección IPv6 (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="292"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercambio de trackers con otros pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="295"/>
        <source>Always announce to all trackers</source>
        <translation>Siempre anunciar a todos los trackers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="243"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Cualquier interfaz</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="205"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Intervalo entre el guardado de datos de reanudación</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="267"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Dirección IP para informar a los trackers (es necesario reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="270"/>
        <source>Display program on-screen notifications</source>
        <translation>Mostrar notificaciones en pantalla</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="273"/>
        <source>Enable embedded tracker</source>
        <translation>Habilitar tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="278"/>
        <source>Embedded tracker port</source>
        <translation>Puerto del tracker integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="281"/>
        <source>Check for software updates</source>
        <translation>Comprobar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="285"/>
        <source>Use system icon theme</source>
        <translation>Usar iconos del tema actual</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="289"/>
        <source>Confirm torrent deletion</source>
        <translation>Confirmar la eliminación del torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="218"/>
        <source>Ignore transfer limits on local network</source>
        <translation>Ignorar limites de transferencia en la red local</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="165"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="166"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Para controlar qBittorrent, accede a la interfaz Web en http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="167"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>El nombre de usuario del administrador de la interfaz Web es: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="170"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contraseña del administrador de la interfaz Web sigue siendo por defecto: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="171"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Esto es un riesgo de seguridad, por favor considere cambiar su contraseña en las preferencias del programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="343"/>
        <source>Saving torrent progress...</source>
        <translation>Guardando progreso del torrent...</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>Automated RSS Downloader</source>
        <translation>Automatizar descarga de canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable the automated RSS downloader</source>
        <translation>Activar la descarga automatizada de canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="48"/>
        <source>Download rules</source>
        <translation>Reglas de descarga</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="123"/>
        <source>Rule definition</source>
        <translation>Definición de reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="138"/>
        <source>Must contain:</source>
        <translation>Debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="180"/>
        <source>Must not contain:</source>
        <translation>No debe contener:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="129"/>
        <source>Use regular expressions</source>
        <translation>Usar expresiones regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="494"/>
        <source>Import...</source>
        <translation>Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="501"/>
        <source>Export...</source>
        <translation>Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="272"/>
        <source>Assign label:</source>
        <translation>Etiquetar como:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="254"/>
        <source>Episode filter:</source>
        <translation>Filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="291"/>
        <source>Save to a different directory</source>
        <translation>Guardar en una ruta diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Save to:</source>
        <translation>Guardar en:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="338"/>
        <source>Ignore subsequent matches for (0 to disable)</source>
        <comment>... X days</comment>
        <translation>Ignorar coincidencias posteriores a (0 para deshabilitar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="361"/>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="402"/>
        <source>Add Paused:</source>
        <translation>Añadir pausado:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="416"/>
        <source>Use global setting</source>
        <translation>Usar preferencias globales</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="421"/>
        <source>Always add paused</source>
        <translation>Siempre añadir pausado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="426"/>
        <source>Never add paused</source>
        <translation>Nunca añadir pausado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="447"/>
        <source>Apply rule to feeds:</source>
        <translation>Aplicar regla a los canales:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="469"/>
        <source>Matching RSS articles</source>
        <translation>Coincidencias de artículos RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="76"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Filtrar artículos en base al filtro de episodios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="76"/>
        <source>Example: </source>
        <translation>Ejemplo:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>coincidirá con los episodios 2, 5, del 8 al 15, y del 30 en adelante de la temporada uno.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source>Episode filter rules: </source>
        <translation>Reglas del filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada debe ser distinto de cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Episode number is a mandatory non-zero value</source>
        <translation>El número de episodio debe ser distinto de cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Filter must end with semicolon</source>
        <translation>El filtro debe finalizar con punto y coma (;)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Son soportados tres tipos de rango de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Un número: &lt;b&gt;1x25;&lt;/b&gt; coincidirá con el episodio 25 de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Un rango: &lt;b&gt;1x25-40;&lt;/b&gt; coincidirá con los episodios del 25 al 40 de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one</source>
        <translation>Rango infinito: &lt;b&gt;1x25-;&lt;/b&gt; coincidirá con los episodios del 25 en adelante de la temporada uno</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="261"/>
        <source>Last match: </source>
        <translation>Última coincidencia:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="263"/>
        <source> days ago.</source>
        <translation>días atrás.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="265"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="358"/>
        <source>New rule name</source>
        <translation>Nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="358"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor, escriba el nombre de la nueva regla de descarga.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Rule name conflict</source>
        <translation>Conflicto con el nombre de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ya existena una regla con este nombre, por favor, elija otro nombre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Are you sure you want to remove the download rule named %1?</source>
        <translation>¿Está seguro que desea eliminar la regla de descarga llamada %1?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="382"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>¿Está seguro que desea eliminar las reglas de descarga seleccionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar la eliminación de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="399"/>
        <source>Destination directory</source>
        <translation>Ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="407"/>
        <source>Invalid action</source>
        <translation>Acción no válida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="407"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La lista está vacía, no hay nada para exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="411"/>
        <source>Where would you like to save the list?</source>
        <translation>¿Dónde le gustaría guardar la lista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="411"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista de reglas (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="416"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="416"/>
        <source>Failed to create the destination file</source>
        <translation>No se pudo crear el archivo de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="424"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Por favor, seleccione el archivo de reglas de descarga de canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="424"/>
        <source>Rules list</source>
        <translation>Lista de reglas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="428"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="428"/>
        <source>Failed to import the selected rules file</source>
        <translation>No se pudo importar el archivo de reglas seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="439"/>
        <source>Add new rule...</source>
        <translation>Añadir nueva regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="445"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="447"/>
        <source>Rename rule...</source>
        <translation>Renombrar regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>Delete selected rules</source>
        <translation>Eliminar reglas seleccionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="476"/>
        <source>Rule renaming</source>
        <translation>Renombrando regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="476"/>
        <source>Please type the new rule name</source>
        <translation>Por favor, escriba el nombre de la nueva regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="578"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Modo Regex: usar expresiones regulares como en Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="582"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para hacer coincidir cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más caracteres&lt;/li&gt;&lt;li&gt;Los espacios en blanco cuentan como operadores AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="584"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Uso de comodines: se puede usar&lt;ul&gt;&lt;li&gt;? para hacer coincidir cualquier carácter individual&lt;/li&gt;&lt;li&gt;* para hacer coincidir cero o más caracteres&lt;/li&gt;&lt;li&gt;| es usado como operador OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Administración de cookies</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Clave</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are: &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Las claves habituales para las cookies son: &apos;%1&apos;, &apos;%2&apos;
Debe obtener esta información de las preferencias de su navegador Web.</translation>
    </message>
</context>
<context>
    <name>DNSUpdater</name>
    <message>
        <location filename="../core/dnsupdater.cpp" line="192"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>El DNS dinámico se actualizó correctamente.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="196"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error del DNS dinámico: El servicio no está disponible temporalmente, nuevo reintento en 30 minutos.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="205"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error del DNS dinámico: El nombre de host proporcionado no existe en la cuenta especificada.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="210"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error del DNS dinámico: El nombre de usuario/contraseña no es válido.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: qBittorrent ha sido incluido en la Lista Negra por el servicio, por favor, informe de esto en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="221"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error del DNS dinámico: %1 fue rechazado por el servicio, por favor, informe de este error en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="227"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error del DNS dinámico: Su nombre de usuario fue bloqueado debido a excesos.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="248"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error del DNS dinámico: El nombre de dominio proporcionado no válido.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="259"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error del DNS dinámico: El nombre de usuario proporcionado es demasiado corto.</translation>
    </message>
    <message>
        <location filename="../core/dnsupdater.cpp" line="270"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error del DNS dinámico: La contraseña proporcionada demasiado corta.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete &quot;%1&quot; from the transfer list?</source>
        <comment>Are you sure you want to delete &quot;ubuntu-linux-iso&quot; from the transfer list?</comment>
        <translation>¿Seguro que desea eliminar &quot;%1&quot; de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="50"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>¿Seguro que desea eliminar estos %1 torrents de la lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../core/downloadthread.cpp" line="165"/>
        <location filename="../core/downloadthread.cpp" line="169"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="259"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>El nombre de host remoto no se ha encontrado (nombre de host no válido)</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="261"/>
        <source>The operation was canceled</source>
        <translation>La operación fue cancelada</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="263"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remoto cerró la conexión prematuramente, antes de que se recibiera y procesara toda la respuesta</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="265"/>
        <source>The connection to the remote server timed out</source>
        <translation>La conexión con el servidor remoto ha agotado el tiempo de espera</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="267"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Handshake SSL/TLS fallido</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="269"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remoto rechazó la conexión</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="271"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La conexión con el servidor proxy fué rechazada</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="273"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>El servidor proxy cerró la conexión antes de tiempo</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="275"/>
        <source>The proxy host name was not found</source>
        <translation>No se encontró el nombre del servidor proxy</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="277"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La conexión con el servidor proxy ha agotado el tiempo de espera o el proxy no respondió a tiempo a la solicitud enviada</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="279"/>
        <source>The proxy requires authentication in order to honour the request but did not accept any credentials offered</source>
        <translation>El proxy requiere autenticación con el fin de atender la solicitud, pero no aceptó las credenciales que ofreció</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="281"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>El acceso al contenido remoto ha sido rechazado (401)</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="283"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>La operación solicitada en el contenido remoto no está permitida</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="285"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contenido remoto no se encontró en el servidor (404)</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="287"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remoto requiere autenticación para servir el contenido, pero no se aceptaron las credenciales proporcionadas</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="289"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>La API de acceso a la red no puede cumplir con la solicitud debido a que el protocolo es desconocido</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="291"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>La operación solicitada no es válida para este protocolo</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="293"/>
        <source>An unknown network-related error was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con la red</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="295"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con el proxy</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="297"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Se ha detectado un error desconocido relacionado con el contenido remoto</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="299"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Se ha detectado una ruptura en el protocolo</translation>
    </message>
    <message>
        <location filename="../core/downloadthread.cpp" line="301"/>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="27"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="102"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue bloqueado</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="104"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue bloqueado %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="107"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; fue baneado</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Canales RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descargar torrents desde URL o enlace magnet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Only one link per line</source>
        <translation>Solamente un enlace por línea</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Download local torrent</source>
        <translation>Descargar torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo del limite de conexiones por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El número máximo de puestos de subida por torrent debe ser mayor que 0 o estar inhabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Error al guardar las preferencias del programa, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Error al iniciar sesión, imposible conectar a qBittorrent.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>Invalid Username or Password.</source>
        <translation>Nombre de usuario o contraseña inválidos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>Upload Failed!</source>
        <translation>Fallo al subir!</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Original authors</source>
        <translation>Autores originales</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Upload limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Download limit:</source>
        <translation>Límite de bajada:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Upload Torrents</source>
        <translation>Subir Torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Seeding</source>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="83"/>
        <source>Resumed</source>
        <translation>Reanudados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="84"/>
        <source>Paused</source>
        <translation>Pausados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Active</source>
        <translation>Activos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Inactive</source>
        <translation>Inactivos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>The port used for incoming connections must be greater than 1024 and less than 65535.</source>
        <translation>El puerto utilizado para conexiones entrantes debe ser mayor de 1024 y menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Logout</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>¿Seguro que desea eliminar los torrents seleccionados de la lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>The port used for the Web UI must be greater than 1024 and less than 65535.</source>
        <translation>El puerto utilizado para la interfaz Web debe ser mayor de 1024 y menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nombre de usuario de la interfaz Web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>La contraseña de Interfaz de Usuario Web debe ser de al menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Imposible conectar a qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>The following parameters are supported:</source>
        <translation>Están soportados los siguientes parámetros:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Torrent path</source>
        <translation>Ruta del torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Torrent name</source>
        <translation>Nombre del torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent se ha cerrado.</translation>
    </message>
</context>
<context>
    <name>LabelFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Unlabeled (0)</source>
        <translation>Sin etiqueta (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="204"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="250"/>
        <source>All (%1)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="207"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="225"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="253"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="258"/>
        <source>Unlabeled (%1)</source>
        <translation>Sin etiqueta (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="229"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="266"/>
        <source>%1 (%2)</source>
        <comment>label_name (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="317"/>
        <source>Add label...</source>
        <translation>Añadir etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="321"/>
        <source>Remove label</source>
        <translation>Eliminar etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="322"/>
        <source>Remove unused labels</source>
        <translation>Eliminar etiquetas sin utilizar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="324"/>
        <source>Resume torrents</source>
        <translation>Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="325"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="326"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="353"/>
        <source>New Label</source>
        <translation>Nueva etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="353"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="359"/>
        <source>Invalid label name</source>
        <translation>Nombre de etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="359"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Por favor, no utilice caracteres especiales en el nombre de la etiqueta.</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../gui/lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Borrar texto</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="80"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="64"/>
        <source>On Downloads &amp;Done</source>
        <translation>Al Finalizar &amp;Descargas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="90"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="161"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reanudar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="206"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Crear torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="211"/>
        <source>Set Upload Limit...</source>
        <translation>Establecer límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="216"/>
        <source>Set Download Limit...</source>
        <translation>Establecer límite de bajada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="226"/>
        <source>Set Global Download Limit...</source>
        <translation>Límite global de bajada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="231"/>
        <source>Set Global Upload Limit...</source>
        <translation>Límite global de subida...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="236"/>
        <source>Minimum Priority</source>
        <translation>Mínima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="244"/>
        <source>Top Priority</source>
        <translation>Máxima prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Decrease Priority</source>
        <translation>Disminuir prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Increase Priority</source>
        <translation>Incrementar prioridad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="271"/>
        <location filename="../gui/mainwindow.ui" line="274"/>
        <source>Alternative Speed Limits</source>
        <translation>Límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="282"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="285"/>
        <source>Display Top Toolbar</source>
        <translation>Mostrar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="293"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Velocidad en la Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="296"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar Velocidad de Transferencia en la Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="304"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="312"/>
        <source>Search &amp;Engine</source>
        <translation>Motor de Búsqu&amp;eda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="317"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Bl&amp;oquear qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="331"/>
        <source>&amp;Import Existing Torrent...</source>
        <translation>&amp;Importar Torrent Existente...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="334"/>
        <source>Import Torrent...</source>
        <translation>Importar Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="339"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="347"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eanudar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="360"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="371"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Salir de &amp;qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="379"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="387"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="395"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Apagar Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="403"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="418"/>
        <source>&amp;Statistics</source>
        <translation>E&amp;stadísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="423"/>
        <source>Check for Updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="426"/>
        <source>Check for Program Updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="156"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="182"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="352"/>
        <source>P&amp;ause All</source>
        <translation>Pa&amp;usar todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="145"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Añadir Archivo Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="148"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="153"/>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="164"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="177"/>
        <source>Resume</source>
        <translation>Reanudar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="193"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="201"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="221"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="320"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="408"/>
        <location filename="../gui/mainwindow.cpp" line="1361"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1517"/>
        <source>Check for program updates</source>
        <translation>Buscar actualizaciones del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="323"/>
        <source>Lock qBittorrent</source>
        <translation>Bloquear qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="198"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Añadir &amp;Enlace Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si le gusta qBittorrent, por favor realice una donación.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="363"/>
        <location filename="../gui/mainwindow.cpp" line="1545"/>
        <source>Execution Log</source>
        <translation>Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <source>Clear the password</source>
        <translation>Borrar la contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="194"/>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="164"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Establecer Contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="166"/>
        <source>&amp;Clear Password</source>
        <translation>Limpiar C&amp;ontraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="211"/>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="355"/>
        <source>Torrent file association</source>
        <translation>Asociación de archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="356"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no es la aplicación por defecto para abrir archivos torrent o enlaces magnet.
¿Quiere que qBittorrent sea el programa por defecto para gestionar estos archivos?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="387"/>
        <source>Icons Only</source>
        <translation>Solo iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="389"/>
        <source>Text Only</source>
        <translation>Solo texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="391"/>
        <source>Text Alongside Icons</source>
        <translation>Texto al lado de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="393"/>
        <source>Text Under Icons</source>
        <translation>Texto debajo de los iconos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="395"/>
        <source>Follow System Style</source>
        <translation>Usar estilo del sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="475"/>
        <location filename="../gui/mainwindow.cpp" line="502"/>
        <location filename="../gui/mainwindow.cpp" line="803"/>
        <source>UI lock password</source>
        <translation>Contraseña de bloqueo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="475"/>
        <location filename="../gui/mainwindow.cpp" line="502"/>
        <location filename="../gui/mainwindow.cpp" line="803"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor, escriba la contraseña de bloqueo:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="479"/>
        <source>The password should contain at least 3 characters</source>
        <translation>La contraseña debe tener como mínimo 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="484"/>
        <source>Password update</source>
        <translation>Actualizar contraseña</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="484"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contraseña de bloqueo de qBittorrent se ha actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>¿Seguro que desea borrar la contraseña?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="519"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="536"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="547"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <source>Download completion</source>
        <translation>Descarga completada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <source>%1 has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>%1 se ha descargado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="648"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="648"/>
        <source>An I/O error occurred for torrent %1.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent xxx.avi.
 Reason: disk is full.</comment>
        <translation>Se produjo un error de Entrada/Salida (I/O) en el torrent %1.
Razón: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="714"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación de descargas recursivas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="714"/>
        <source>The torrent %1 contains torrent files, do you want to proceed with their download?</source>
        <translation>El torrent %1 contiene archivos torrent, ¿quiere seguir adelante con su descarga?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="715"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="716"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="717"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="739"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite de velocidad de subida global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="755"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite de velocidad de bajada global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="905"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="906"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="907"/>
        <source>&amp;Always Yes</source>
        <translation>S&amp;iempre sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1455"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta el intérprete de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1456"/>
        <source>Python 2.x is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python 2.x es necesario para utilizar el motor de búsqueda pero no parece estar instalado.
¿Desea instalarlo ahora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1501"/>
        <source>Update Available</source>
        <translation>Actualización disponible</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1502"/>
        <source>A new version is available.
Update to version %1?</source>
        <translation>Hay una nueva versión disponible.
¿Desea actualizar a la versión %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1511"/>
        <source>Already Using the Latest Version</source>
        <translation>Ya está utilizando la versión mas reciente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1512"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>No hay actualizaciones disponibles.
Ya está utilizando la versión mas reciente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1516"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1614"/>
        <source>Checking for Updates...</source>
        <translation>Buscando actualizaciones...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1615"/>
        <source>Already checking for program updates in the background</source>
        <translation>Ya se están buscando actualizaciones del programa en segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1682"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1682"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>La instalación de Python no se pudo realizar, la razón: %1.
Por favor, instálelo de forma manual.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="479"/>
        <location filename="../gui/mainwindow.cpp" line="817"/>
        <source>Invalid password</source>
        <translation>Contraseña no válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="731"/>
        <source>URL download error</source>
        <translation>Error descargando de URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="731"/>
        <source>Couldn&apos;t download file at URL: %1, reason: %2.</source>
        <translation>No se pudo descargar el archivo desde la URL: %1, razón: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="817"/>
        <source>The password is invalid</source>
        <translation>La contraseña no es válida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1246"/>
        <location filename="../gui/mainwindow.cpp" line="1253"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. bajada: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1249"/>
        <location filename="../gui/mainwindow.cpp" line="1255"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. subida: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1260"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[B: %1, S: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1361"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="902"/>
        <source>Exiting qBittorrent</source>
        <translation>Cerrando qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="903"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Algunos archivos aún están transfiriéndose.
¿Está seguro de querer cerrar qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1065"/>
        <source>Open Torrent Files</source>
        <translation>Abrir archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1066"/>
        <source>Torrent Files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1122"/>
        <source>Options were saved successfully.</source>
        <translation>Opciones guardadas correctamente.</translation>
    </message>
</context>
<context>
    <name>PeerAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peeraddition.h" line="96"/>
        <source>Invalid IP</source>
        <translation>IP inválida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peeraddition.h" line="97"/>
        <source>The IP you provided is invalid.</source>
        <translation>La IP facilitada no es válida.</translation>
    </message>
</context>
<context>
    <name>PeerListDelegate</name>
    <message>
        <location filename="../gui/properties/peerlistdelegate.h" line="64"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="68"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="69"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="70"/>
        <source>Flags</source>
        <translation>Banderas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Bajada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Bajado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Importancia</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="167"/>
        <source>Add a new peer...</source>
        <translation>Añadir nuevo par...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="178"/>
        <source>Copy selected</source>
        <translation>Copiar seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="181"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de bajada...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="182"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="185"/>
        <source>Ban peer permanently</source>
        <translation>Prohibir este par permanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="198"/>
        <source>Peer addition</source>
        <translation>Añadir par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <source>The peer was added to this torrent.</source>
        <translation>El par se agregó al torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="198"/>
        <source>The peer could not be added to this torrent.</source>
        <translation>El par no se pudo agregar al torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="231"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>¿Estás seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="231"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>¿Seguro que desea prohibir permanentemente los pares seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="232"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="232"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="239"/>
        <source>Manually banning peer %1...</source>
        <translation>Prohibiendo manualmente el par %1...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="262"/>
        <source>Upload rate limiting</source>
        <translation>Limitación de la tasa de Subida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="294"/>
        <source>Download rate limiting</source>
        <translation>Limitación de la tasa de bajada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="485"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interesado(local) y ahogado(par)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="491"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interesado(local) y no ahogado(par)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="500"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interesado(par) y ahogado(local)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="506"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interesado(par) y no ahogado(local)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="514"/>
        <source>optimistic unchoke</source>
        <translation>desahogo optimista</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="521"/>
        <source>peer snubbed</source>
        <translation>par descartado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="528"/>
        <source>incoming connection</source>
        <translation>conexión entrante</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="535"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>no interesado(local) y no ahogado(par)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="542"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>no interesado(par) y no ahogado(local)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="549"/>
        <source>peer from PEX</source>
        <translation>par de PEX</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="556"/>
        <source>peer from DHT</source>
        <translation>par de DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="563"/>
        <source>encrypted traffic</source>
        <translation>trafico cifrado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="570"/>
        <source>encrypted handshake</source>
        <translation>negociación cifrada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="588"/>
        <source>peer from LSD</source>
        <translation>par de LSD</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../gui/options.ui" line="96"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="107"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="118"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="140"/>
        <source>Web UI</source>
        <translation>Interfaz Web</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="151"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="227"/>
        <source>(Requires restart)</source>
        <translation>(Es necesario reiniciar qBittorrent)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="261"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternar colores en la lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="303"/>
        <location filename="../gui/options.ui" line="329"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="313"/>
        <location filename="../gui/options.ui" line="339"/>
        <source>No action</source>
        <translation>Sin acción</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="700"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Añadir la extensión .!qB a los archivos incompletos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="803"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar archivos .torrent en:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1008"/>
        <source>The following parameters are supported:
&lt;ul&gt;
&lt;li&gt;%f: Torrent path&lt;/li&gt;
&lt;li&gt;%n: Torrent name&lt;/li&gt;
&lt;/ul&gt;</source>
        <translation>Están soportados los siguientes parámetros:
&lt;ul&gt;
&lt;li&gt;%f: Ruta del torrent&lt;/li&gt;
&lt;li&gt;%n: Nombre del torrent&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1122"/>
        <source>Connections Limits</source>
        <translation>Límites de conexión</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1275"/>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1556"/>
        <source>Global Rate Limits</source>
        <translation>Limites globales de velocidad</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1671"/>
        <source>Apply rate limit to uTP connections</source>
        <translation>Aplicar límite para conexiones uTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1678"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límite para el exceso de transporte (Overhead)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1691"/>
        <source>Alternative Global Rate Limits</source>
        <translation>Limites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1803"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar el uso de límites alternativos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2009"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar busqueda local de pares para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2021"/>
        <source>Encryption mode:</source>
        <translation>Modo de cifrado:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2029"/>
        <source>Prefer encryption</source>
        <translation>Preferir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2034"/>
        <source>Require encryption</source>
        <translation>Exigir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2039"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2074"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Más información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2117"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de descargas activas:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2137"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de subidas activas:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2157"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents activos:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="536"/>
        <source>When adding a torrent</source>
        <translation>Al añadir un torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="85"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="191"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="552"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar el contenido del Torrent y opciones</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1058"/>
        <source>Port used for incoming connections:</source>
        <translation>Puerto utilizado para conexiones entrantes:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1078"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1128"/>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo de conexiones totales:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1154"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Máximo de conexiones por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1177"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número de puestos de subida por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1574"/>
        <location filename="../gui/options.ui" line="1769"/>
        <source>Upload:</source>
        <translation>Subida:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1607"/>
        <location filename="../gui/options.ui" line="1779"/>
        <source>Download:</source>
        <translation>Bajada:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1600"/>
        <location filename="../gui/options.ui" line="1633"/>
        <location filename="../gui/options.ui" line="1739"/>
        <location filename="../gui/options.ui" line="1762"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="770"/>
        <source>Remove folder</source>
        <translation>Eliminar carpeta</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1847"/>
        <source>to</source>
        <extracomment>time1 to time2</extracomment>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1902"/>
        <source>Every day</source>
        <translation>Todos los días</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1907"/>
        <source>Week days</source>
        <translation>Días laborales</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1912"/>
        <source>Week ends</source>
        <translation>Fines de semana</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1993"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercambiar pares con clientes Bittorrent compatibles (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1317"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1296"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1283"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="20"/>
        <location filename="../gui/options.ui" line="1655"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="277"/>
        <source>Action on double-click</source>
        <translation>Acción a realizar con un doble-click</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="286"/>
        <source>Downloading torrents:</source>
        <translation>Torrents descargando:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="308"/>
        <location filename="../gui/options.ui" line="334"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="321"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="353"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="366"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar pantalla de bienvenida al iniciar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="376"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar qBittorrent en el area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Cerrar qBittorrent al area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>Estilo del icono del area de notificación:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="429"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromo (tema oscuro)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromo (tema claro)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="199"/>
        <source>User Interface Language:</source>
        <translation>Idioma de la interfaz:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="255"/>
        <source>Transfer List</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="359"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent cuando arranque Windows</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="383"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmación al salir mientras haya torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="393"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostrar qBittorrent en el área de notificación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="452"/>
        <source>File association</source>
        <translation>Asociación de archivos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar qBittorrent para los archivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar qBittorrent para los enlaces magnet</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="478"/>
        <source>Power Management</source>
        <translation>Administración de energía</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="484"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhabilitar la suspensión del equipo cuando queden torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="545"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciar las descargas de forma automática</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="561"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Traer el diálogo del torrent al frente</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="583"/>
        <source>Hard Disk</source>
        <translation>Disco duro</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="589"/>
        <source>Save files to location:</source>
        <translation>Guardar los archivos en:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="637"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Añadir la etiqueta del torrent a la ruta donde se guarda</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="647"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar espacio en el disco para todos los archivos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="654"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantener torrents incompletos en:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="707"/>
        <source>Automatically add torrents from:</source>
        <translation>Añadir automáticamente los torrents de:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="760"/>
        <source>Add folder...</source>
        <translation>Agregar carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="852"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar archivos .torrent de descargas finalizadas a:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="908"/>
        <source>Email notification upon download completion</source>
        <translation>Notificarme por correo electrónico de la finalización de las descargas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="922"/>
        <source>Destination email:</source>
        <translation>Dirección de correo electrónico:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="932"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="981"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requiere una conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="993"/>
        <source>Run an external program on torrent completion</source>
        <translation>Ejecutar un programa externo al completarse el torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1050"/>
        <source>Listening Port</source>
        <translation>Puerto de escucha</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1100"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar reenvío de puertos UPnP / NAT-PMP de mi router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1110"/>
        <source>Use different port on each startup</source>
        <translation>Usar un puerto diferente en cada inicio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1236"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Máximo global de puestos de subida:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1371"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Sino, el servidor proxy se utilizará solamente para las conexiones al tracker</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1374"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para las conexiones a los pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1381"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Deshabilitar conexiones no soportadas por los proxis</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1450"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: La contraseña se guarda sin cifrar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1463"/>
        <source>IP Filtering</source>
        <translation>Filtrado IP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1504"/>
        <source>Reload the filter</source>
        <translation>Actualizar el filtro</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1520"/>
        <source>Apply to trackers</source>
        <translation>Aplicar a los trackers</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1661"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation>Habilitar gestión de ancho de banda (uTP)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1820"/>
        <source>from</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Desde las</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1894"/>
        <source>When:</source>
        <translation>Cuándo:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1977"/>
        <source>Privacy</source>
        <translation>Privacidad</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1983"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (red descentralizada) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1996"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercambio de pares (PeX) para encontrar más pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2006"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar pares en su red local</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2064"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilitar cuando se use un proxy o un VPN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2067"/>
        <source>Enable anonymous mode</source>
        <translation>Activar modo anónimo</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2216"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>No contar torrents lentos en estos límites</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2237"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sembrar torrents hasta que su ratio sea</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2266"/>
        <source>then</source>
        <translation>luego</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2277"/>
        <source>Pause them</source>
        <translation>Pausarlos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2282"/>
        <source>Remove them</source>
        <translation>Eliminarlos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2380"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP para redirigir el puerto de mi router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2390"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS en lugar de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2433"/>
        <source>Import SSL Certificate</source>
        <translation>Importar certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2486"/>
        <source>Import SSL Key</source>
        <translation>Importar clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2421"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2474"/>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2508"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Información sobre los certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2553"/>
        <source>Bypass authentication for localhost</source>
        <translation>Eludir la autenticación para localhost</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2577"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar mi nombre de dominio dinámico</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2589"/>
        <source>Service:</source>
        <translation>Servicio:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2612"/>
        <source>Register</source>
        <translation>Registro</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2621"/>
        <source>Domain name:</source>
        <translation>Nombre de dominio:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1291"/>
        <source>(None)</source>
        <translation>(Ninguno)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="129"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1306"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1343"/>
        <location filename="../gui/options.ui" line="2345"/>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="942"/>
        <location filename="../gui/options.ui" line="1394"/>
        <location filename="../gui/options.ui" line="2521"/>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="954"/>
        <location filename="../gui/options.ui" line="1408"/>
        <location filename="../gui/options.ui" line="2560"/>
        <location filename="../gui/options.ui" line="2635"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="964"/>
        <location filename="../gui/options.ui" line="1428"/>
        <location filename="../gui/options.ui" line="2567"/>
        <location filename="../gui/options.ui" line="2649"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2102"/>
        <source>Torrent Queueing</source>
        <translation>Torrents en cola</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2226"/>
        <source>Share Ratio Limiting</source>
        <translation>Limite de ratio de compartición</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2331"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Habilitar interfaz Web (Control remoto)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1301"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1475"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta del filtro (.dat, .p2p, .p2b):</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../gui/previewselect.cpp" line="51"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="52"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="53"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="80"/>
        <location filename="../gui/previewselect.cpp" line="117"/>
        <source>Preview impossible</source>
        <translation>Imposible previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="80"/>
        <location filename="../gui/previewselect.cpp" line="117"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Lo siento, no se puede previsualizar este archivo</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.h" line="117"/>
        <source>Not downloaded</source>
        <translation>No descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.h" line="126"/>
        <location filename="../gui/properties/proplistdelegate.h" line="168"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.h" line="120"/>
        <location filename="../gui/properties/proplistdelegate.h" line="169"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.h" line="114"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.h" line="123"/>
        <location filename="../gui/properties/proplistdelegate.h" line="170"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="45"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="54"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="58"/>
        <source>HTTP Sources</source>
        <translation>Fuentes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="62"/>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="292"/>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="134"/>
        <source>Availability:</source>
        <translation>Disponibilidad:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="77"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="184"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="196"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tiempo activo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="228"/>
        <source>ETA:</source>
        <translation>Tiempo restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="324"/>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="356"/>
        <source>Seeds:</source>
        <translation>Semillas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="388"/>
        <source>Download Speed:</source>
        <translation>Velocidad de bajada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="420"/>
        <source>Upload Speed:</source>
        <translation>Velocidad de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="452"/>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="484"/>
        <source>Download Limit:</source>
        <translation>Límite de bajada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="516"/>
        <source>Upload Limit:</source>
        <translation>Límite de subida:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="548"/>
        <source>Wasted:</source>
        <translation>Desperdiciado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="260"/>
        <source>Connections:</source>
        <translation>Conexiones:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="679"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="959"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1144"/>
        <source>Torrent content:</source>
        <translation>Contenido del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1111"/>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1118"/>
        <source>Select None</source>
        <translation>Seleccionar ninguno</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1201"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1196"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="580"/>
        <source>Share Ratio:</source>
        <translation>Ratio de compartición:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="612"/>
        <source>Reannounce In:</source>
        <translation>Anunciar en:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="644"/>
        <source>Last Seen Complete:</source>
        <translation>Ultima vez visto completo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="691"/>
        <source>Total Size:</source>
        <translation>Tamaño total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="723"/>
        <source>Pieces:</source>
        <translation>Piezas:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="755"/>
        <source>Created By:</source>
        <translation>Creado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="787"/>
        <source>Added On:</source>
        <translation>Añadido el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="819"/>
        <source>Completed On:</source>
        <translation>Completado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="851"/>
        <source>Created On:</source>
        <translation>Creado el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="883"/>
        <source>Torrent Hash:</source>
        <translation>Hash del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="918"/>
        <source>Save Path:</source>
        <translation>Ruta de destino:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1191"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1183"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1186"/>
        <source>Do not download</source>
        <translation>No descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="372"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="373"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="392"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="394"/>
        <source>/s</source>
        <comment>/second (i.e. per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="376"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Sembrado durante %1</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="379"/>
        <source>%1 max</source>
        <comment>e.g. 10 max</comment>
        <translation>%1 max</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="389"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="390"/>
        <source>(%1 total)</source>
        <comment>e.g. (10 total)</comment>
        <translation>(%1 en total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="393"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="395"/>
        <source>(%1/s avg.)</source>
        <comment>e.g. (100KiB/s avg.)</comment>
        <translation>(%1/s prom.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="397"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="402"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tienes %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="511"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="585"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="511"/>
        <source>This file does not exist yet.</source>
        <translation>Este archivo todavía no existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="585"/>
        <source>This folder does not exist yet.</source>
        <translation>Esta carpeta todavía no existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="603"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="604"/>
        <source>Open Containing Folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="605"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="610"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="656"/>
        <source>New Web seed</source>
        <translation>Nueva semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="662"/>
        <source>Remove Web seed</source>
        <translation>Eliminar semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="664"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="665"/>
        <source>Edit Web seed URL</source>
        <translation>Editar URL de la semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="690"/>
        <source>Rename the file</source>
        <translation>Renombrar archivo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="691"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="695"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="726"/>
        <source>The file could not be renamed</source>
        <translation>No se puede renombrar el archivo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="696"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nombre introducido contiene caracteres prohibidos, por favor elija otro.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="727"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="765"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nombre ya está en uso. Por favor, use un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="764"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no se pudo renombrar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="872"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="84"/>
        <source>Filter files...</source>
        <translation>Filtrar archivos...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="370"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="371"/>
        <source>session</source>
        <translation>en esta sesión</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="810"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nueva semilla URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="811"/>
        <source>New URL seed:</source>
        <translation>Nueva semilla URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="817"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="873"/>
        <source>This URL seed is already in the list.</source>
        <translation>Esta semilla URL ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="865"/>
        <source>Web seed editing</source>
        <translation>Editando semilla Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="866"/>
        <source>Web seed URL:</source>
        <translation>URL de la semilla Web:</translation>
    </message>
</context>
<context>
    <name>QBtSession</name>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="134"/>
        <source>Peer ID: </source>
        <translation>ID del Par:</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="235"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="241"/>
        <source>%1 reached the maximum ratio you set.</source>
        <translation>%1 alcanzó el ratio máximo establecido.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="236"/>
        <source>Removing torrent %1...</source>
        <translation>Quitando torrent %1...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="242"/>
        <source>Pausing torrent %1...</source>
        <translation>Pausando torrent %1...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="409"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="412"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="417"/>
        <source>HTTP User-Agent is %1</source>
        <translation>El Gestor de Usuario HTTP es %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="444"/>
        <source>Anonymous mode [ON]</source>
        <translation>Modo Anónimo [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="446"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Modo Anónimo [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="529"/>
        <source>PeX support [ON]</source>
        <translation>Soporte PeX [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="531"/>
        <source>PeX support [OFF]</source>
        <translation>Soporte PeX [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="534"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Es necesario reiniciar para cambiar el soporte PeX</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="539"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Buscar pares locales [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="542"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Buscar pares locales [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="554"/>
        <source>Encryption support [ON]</source>
        <translation>Soporte para cifrado [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="559"/>
        <source>Encryption support [FORCED]</source>
        <translation>Soporte para cifrado [Forzado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="564"/>
        <source>Encryption support [OFF]</source>
        <translation>Soporte para cifrado [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="623"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Tracker integrado [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="625"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error al iniciar el tracker integrado!</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="628"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Tracker integrado [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="770"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias y del disco.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="772"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; Fue eliminado de la lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="869"/>
        <source>Couldn&apos;t parse this Magnet URI: &apos;%1&apos;</source>
        <translation>No se pudo analizar este enlace magnet: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="874"/>
        <source>&apos;%1&apos; is not a valid magnet URI.</source>
        <translation>&apos;%1&apos; no es un enlace magnet válido.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="893"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1051"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1053"/>
        <source>&apos;%1&apos; is already in download list.</source>
        <comment>e.g: &apos;xxx.avi&apos; is already in download list.</comment>
        <translation>&apos;%1&apos; ya está en la lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="976"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1175"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1180"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; añadido a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1025"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1030"/>
        <source>Unable to decode torrent file: &apos;%1&apos;</source>
        <comment>e.g: Unable to decode torrent file: &apos;/home/y/xxx.torrent&apos;</comment>
        <translation>Incapaz de decodificar el archivo torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1033"/>
        <source>This file is either corrupted or this isn&apos;t a torrent.</source>
        <translation>El archivo está corrupto o no es un archivo torrent.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1068"/>
        <source>Error: The torrent %1 does not contain any file.</source>
        <translation>Error: El torrent %1 no contiene ningún archivo.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1173"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1178"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;/home/y/xxx.torrent&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; continuado. (continuación rápida)</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1338"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>El tracker &apos;%1&apos; se añadió al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1362"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>La semilla URL &apos;%1&apos; se añadió al torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1535"/>
        <source>DHT support [ON]</source>
        <translation>Soporte para DHT [Activado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1540"/>
        <source>DHT support [OFF]. Reason: %1</source>
        <translation>Soporte para DHT [Desactivado]. Razón: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1548"/>
        <source>DHT support [OFF]</source>
        <translation>Soporte para DHT [Desactivado]</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1852"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent está intentando escuchar en cualquier puerto de la interfaz : %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1856"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent falló tratando de escuchar en cualquier interfaz, Puerto: %1. Razón: %2</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1864"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfaz de red definida no es válida: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1877"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está intentando escuchar en la interfaz %1 puerto: %2</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1881"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent no encontró una  %1 dirección local en la que escuchar</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="1989"/>
        <source>Recursive download of file %1 embedded in torrent %2</source>
        <comment>Recursive download of test.torrent embedded in torrent test2</comment>
        <translation>Descarga recursiva del archivo %1 inscrustado en torrent %2</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2028"/>
        <source>Torrent name: %1</source>
        <translation>Nombre del torrent: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2029"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño del torrent: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2030"/>
        <source>Save path: %1</source>
        <translation>Guardar en: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2031"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt se descargó en %1.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2032"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gracias por utilizar qBittorrent.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2035"/>
        <source>[qBittorrent] %1 has finished downloading</source>
        <translation>[qBittorrent] %1 ha terminado de descargarse</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2172"/>
        <source>Unable to decode %1 torrent file.</source>
        <translation>No se puede decodificar el torrent %1.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2380"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>No se puede mover el torrent: &apos;%1&apos;. Razón: %2</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2385"/>
        <source>Attempting to move torrent: &apos;%1&apos; to path: &apos;%2&apos;.</source>
        <translation>Intentando mover el torrent: &apos;%1&apos; a la ruta: &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2448"/>
        <source>An I/O error occurred, &apos;%1&apos; paused.</source>
        <translation>Ocurrió un error de Entrada/Salida (I/O), &apos;%1&apos; pausado.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2449"/>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2603"/>
        <source>Reason: %1</source>
        <translation>Razón: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2540"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Falló el mapeo del puerto, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2545"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Puerto mapeado correctamente, mensaje: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2559"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>por el filtro IP.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2562"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>por el filtro de puertos.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2565"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>por restricciones del modo mixto i2p.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2568"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>por tener un puerto bajo.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2571"/>
        <source>because Î¼TP is disabled.</source>
        <comment>this peer was blocked because Î¼TP is disabled.</comment>
        <translation>porque μTP está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2574"/>
        <source>because TCP is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>porque TCP está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2598"/>
        <source>File sizes mismatch for torrent %1, pausing it.</source>
        <translation>El tamaño de archivo no coincide con el torrent %1, pausandolo.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2602"/>
        <source>Fast resume data was rejected for torrent %1, checking again...</source>
        <translation>Continuación rápida rechazada para el torrent: %1, Verificando de nuevo...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2609"/>
        <source>URL seed lookup failed for url: %1, message: %2</source>
        <translation>Falló la búsqueda de la semilla URL: %1, mensaje: %2</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2624"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está escuchando en la interfaz %1 puerto: %2/%3</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2651"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation>qBittorrent falló al escuchar en la interfaz %1 puerto: %2/%3. Razón: %4</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2684"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externa: %1</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="2814"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, por favor espere...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="3034"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas fueron aplicadas.</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/qbtsession.cpp" line="3040"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>No se ha podido analizar el filtro IP proporcionado</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="110"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Su dirección IP ha sido bloqueada debido a demasiados intentos fallados de autenticación.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="345"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Error: &apos;%1&apos; no es un archivo torrent valido.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="353"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Error de Entrada/Salida (I/O): No se puede crear un archivo temporal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="124"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciado</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="135"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 es un parámetro de la línea de comandos desconocido.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="147"/>
        <location filename="../app/main.cpp" line="160"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 debe ser el único parámetro de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="170"/>
        <source>%1 must specify the correct port (1 to 65535).</source>
        <translation>%1 debe especificar el puerto correcto (entre 1 y 65535).</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="186"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>No puedes usar %1: qBittorrent ya se está ejecutando para este usuario.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="363"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="376"/>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="378"/>
        <source>Displays program version</source>
        <translation>Muestra la versión del programa</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="380"/>
        <source>Displays this help message</source>
        <translation>Muestra este mensaje de ayuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="382"/>
        <source>Changes the Web UI port (current: %1)</source>
        <translation>Cambia el puerto de la interfaz Web (actual: %1)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="385"/>
        <source>Disable splash screen</source>
        <translation>Desactivar pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="387"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Ejecutar en modo servicio (segundo plano)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="389"/>
        <source>Downloads the torrents passed by the user</source>
        <translation>Descarga los torrents pasados por el usuario</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="408"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Ejecuta la aplicación con la opción -h para obtener información sobre los parámetros de la línea de comandos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="410"/>
        <source>Bad command line</source>
        <translation>Parámetros de la línea de comandos incorrectos</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="416"/>
        <source>Bad command line: </source>
        <translation>Parámetros de la línea de comandos incorrectos:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="429"/>
        <source>Legal Notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="430"/>
        <location filename="../app/main.cpp" line="440"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent es un programa para compartir archivos. Cuando se descarga un torrent, los datos del mismo se pondrán a disposición de los demás usuarios por medio de las subidas. Cualquier contenido que usted comparta, lo hace bajo su propia responsabilidad.

No se le volverá a notificar sobre esto.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="431"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pulse la tecla %1 para aceptar y continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="441"/>
        <source>Legal notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="442"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="443"/>
        <source>I Agree</source>
        <translation>Estoy de acuerdo</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../gui/rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Nueva subscripción</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="47"/>
        <location filename="../gui/rss/rss.ui" line="199"/>
        <location filename="../gui/rss/rss.ui" line="202"/>
        <source>Mark items read</source>
        <translation>Marcar como leídos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Actualizar todo</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>Descargador RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Configuración...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="124"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(double-click to download)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrents:&lt;/span&gt; &lt;span style=&quot; font-style:italic;&quot;&gt;(doble-click para descargar)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="162"/>
        <location filename="../gui/rss/rss.ui" line="165"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="170"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="173"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="178"/>
        <location filename="../gui/rss/rss.ui" line="181"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="186"/>
        <source>New subscription...</source>
        <translation>Nueva suscripción...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="191"/>
        <location filename="../gui/rss/rss.ui" line="194"/>
        <source>Update all feeds</source>
        <translation>Actualizar todos los canales</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="207"/>
        <source>Download torrent</source>
        <translation>Descargar torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="212"/>
        <source>Open news URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="217"/>
        <source>Copy feed URL</source>
        <translation>Copiar URL del canal</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="222"/>
        <source>New folder...</source>
        <translation>Nueva carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="227"/>
        <source>Manage cookies...</source>
        <translation>Administrar cookies...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar canales RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="204"/>
        <source>Stream URL:</source>
        <translation>URL del canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="204"/>
        <source>Please type a RSS stream URL</source>
        <translation>Por favor escribe una URL de un Canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="214"/>
        <source>This RSS feed is already in the list.</source>
        <translation>Esta fuente de RSS ya está en la lista.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="241"/>
        <location filename="../gui/rss/rss_imp.cpp" line="248"/>
        <source>Are you sure? -- qBittorrent</source>
        <translation>¿Estás seguro? -- qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="242"/>
        <location filename="../gui/rss/rss_imp.cpp" line="249"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="242"/>
        <location filename="../gui/rss/rss_imp.cpp" line="249"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="159"/>
        <source>Please choose a folder name</source>
        <translation>Por favor elija un nombre para la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="159"/>
        <source>Folder name:</source>
        <translation>Nombre de la carpeta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="159"/>
        <source>New folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="241"/>
        <source>Are you sure you want to delete these elements from the list?</source>
        <translation>¿Seguro que desea eliminar estos elementos de la lista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="248"/>
        <source>Are you sure you want to delete this element from the list?</source>
        <translation>¿Seguro que desea eliminar este elemento de la lista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="386"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor, elija un nuevo nombre para el canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="386"/>
        <source>New feed name:</source>
        <translation>Nombre del nuevo canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="390"/>
        <source>Name already in use</source>
        <translation>Ese nombre ya está en uso</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="390"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Ese nombre ya está siendo usado por otro elemento, por favor, elija otro.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="568"/>
        <source>Date: </source>
        <translation>Fecha:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="570"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="647"/>
        <source>Unread</source>
        <translation>No leídos</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../gui/rss/rssfeed.cpp" line="370"/>
        <source>Automatically downloading %1 torrent from %2 RSS feed...</source>
        <translation>Descargarndo automáticamente el torrent %1 desde el canal RSS %2...</translation>
    </message>
</context>
<context>
    <name>RssParser</name>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="458"/>
        <source>Failed to open downloaded RSS file.</source>
        <translation>Fallo al abrir el archivo descargado del RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="495"/>
        <source>Invalid RSS feed at %1.</source>
        <translation>Canal RSS inválido en %1.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Ajustes del lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Intervalo de actualización de canales RSS:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artículos por canal:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../core/scannedfoldersmodel.cpp" line="97"/>
        <source>Watched Folder</source>
        <translation>Carpeta vigilada</translation>
    </message>
    <message>
        <location filename="../core/scannedfoldersmodel.cpp" line="98"/>
        <source>Download here</source>
        <translation>Descargar aquí</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="52"/>
        <source>All categories</source>
        <translation>Todas las categorías</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>Movies</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>TV shows</source>
        <translation>Programas de TV</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="60"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="173"/>
        <location filename="../searchengine/searchengine.cpp" line="192"/>
        <location filename="../searchengine/searchengine.cpp" line="193"/>
        <location filename="../searchengine/searchengine.cpp" line="440"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="204"/>
        <source>Empty search pattern</source>
        <translation>Patrón de búsqueda vacío</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="204"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor escriba primero un patrón de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="232"/>
        <location filename="../searchengine/searchengine.cpp" line="301"/>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="280"/>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="282"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="418"/>
        <source>Search Engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="418"/>
        <location filename="../searchengine/searchengine.cpp" line="433"/>
        <source>Search has finished</source>
        <translation>La búsqueda ha terminado</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="424"/>
        <source>An error occurred during search...</source>
        <translation>Ocurrió un error durante la búsqueda...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="422"/>
        <location filename="../searchengine/searchengine.cpp" line="428"/>
        <source>Search aborted</source>
        <translation>Búsqueda abortada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="113"/>
        <source>All enabled</source>
        <translation>Todos los habilitados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="114"/>
        <source>All engines</source>
        <translation>Todos los motores</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="117"/>
        <location filename="../searchengine/searchengine.cpp" line="162"/>
        <source>Multiple...</source>
        <translation>Múltiples...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="431"/>
        <source>Search returned no results</source>
        <translation>La búsqueda no devolvió resultados</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="439"/>
        <source>Results</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../searchengine/searchlistdelegate.h" line="60"/>
        <location filename="../searchengine/searchlistdelegate.h" line="64"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="55"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="56"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="57"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="58"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="59"/>
        <source>Search engine</source>
        <translation>Motor de búsqueda</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="40"/>
        <source>Exit confirmation</source>
        <translation>Confirmar salida</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="41"/>
        <source>Exit now</source>
        <translation>Salir ahora</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="44"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmar al cerrar</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="45"/>
        <source>Shutdown now</source>
        <translation>Apagar ahora</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="99"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation>qBittorrent será cerrado en %1 segundos, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="102"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation>El equipo se apagará en %1 segundos, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="105"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation>El equipo se suspenderá en %1 segundos, a menos que lo cancele...</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/shutdownconfirm.cpp" line="108"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation>El equipo hibernará en %1 segundos, a menos que lo cancele...</translation>
    </message>
</context>
<context>
    <name>Smtp</name>
    <message>
        <location filename="../core/smtp.cpp" line="479"/>
        <source>Email Notification Error:</source>
        <translation>Error en la notificación por E-mail:</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="78"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadísticas del usuario</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Total de pares conectados:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Ratio global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Total descargado:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Total subido:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Desperdiciado (esta sesión):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadísticas de la caché</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache Hits:</source>
        <translation>Uso de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Tamaño total de los buffers:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendimiento</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Trabajos de Entrada/Salida (I/O) en cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga de la caché de escritura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue (ms):</source>
        <translation>Tiempo promedio en cola (ms):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga de la caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamaño total de cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="243"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="61"/>
        <location filename="../gui/statusbar.cpp" line="173"/>
        <source>Connection status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="61"/>
        <location filename="../gui/statusbar.cpp" line="173"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hay conexiones directas. Esto puede indicar problemas en la configuración de red.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="75"/>
        <location filename="../gui/statusbar.cpp" line="180"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="143"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>Es necesario reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="153"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent ha sido actualizado y debe ser reiniciado para que los cambios sean efectivos.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="165"/>
        <location filename="../gui/statusbar.cpp" line="170"/>
        <source>Connection Status:</source>
        <translation>Estado de la conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="165"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fuera de línea. Esto normalmente significa que qBittorrent no puede escuchar el puerto seleccionado para las conexiones entrantes.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="170"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="205"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Click para cambiar a los límites de velocidad alternativos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="201"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Click para cambiar a los límites de velocidad normales</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="215"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Cambio de límites en modo manual. El programador está deshabilitado.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="223"/>
        <source>Global Download Speed Limit</source>
        <translation>Máxima velocidad global de descarga</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="249"/>
        <source>Global Upload Speed Limit</source>
        <translation>Máxima velocidad global de subida</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="111"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="114"/>
        <source>Downloading (0)</source>
        <translation>Descargando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="117"/>
        <source>Seeding (0)</source>
        <translation>Sembrando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="120"/>
        <source>Completed (0)</source>
        <translation>Completados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="123"/>
        <source>Resumed (0)</source>
        <translation>Reanudados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="126"/>
        <source>Paused (0)</source>
        <translation>Pausados (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="129"/>
        <source>Active (0)</source>
        <translation>Activos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="132"/>
        <source>Inactive (0)</source>
        <translation>Inactivos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="148"/>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="149"/>
        <source>Downloading (%1)</source>
        <translation>Descargando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="150"/>
        <source>Seeding (%1)</source>
        <translation>Sembrando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="151"/>
        <source>Completed (%1)</source>
        <translation>Completados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="152"/>
        <source>Paused (%1)</source>
        <translation>Pausados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="153"/>
        <source>Resumed (%1)</source>
        <translation>Reanudados (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="154"/>
        <source>Active (%1)</source>
        <translation>Activos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="155"/>
        <source>Inactive (%1)</source>
        <translation>Inactivos (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="54"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="54"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="55"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="55"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="75"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccione una carpeta para agregar al torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="88"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccione un archivo para agregar al torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="108"/>
        <source>No input path set</source>
        <translation>No se ha establecido la ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="108"/>
        <source>Please type an input path first</source>
        <translation>Por favor escriba primero una ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="118"/>
        <source>Select destination torrent file</source>
        <translation>Seleccione el torrent de destino</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="118"/>
        <source>Torrent Files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="145"/>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="159"/>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="171"/>
        <source>Torrent creation</source>
        <translation>Crear nuevo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="145"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>La creación del torrent no ha fallado, razón: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="159"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>El torrent creado no es válido. No se añadirá a la lista de descargas.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/torrentcreatordlg.cpp" line="171"/>
        <source>Torrent was created successfully:</source>
        <translation>El torrent se creó correctamente:</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importar torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Este asistente le ayudará a compartir con qBittorrent, un torrent ya descargado.</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Archivo torrent para importar:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Ubicación del contenido:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Saltar la fase de comprobación de datos y empezar a sembrar de inmediato</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="67"/>
        <source>Torrent file to import</source>
        <translation>Archivo torrent para importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="67"/>
        <source>Torrent files</source>
        <translation>Archivos torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="90"/>
        <source>%1 Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>%1 archivos</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="92"/>
        <source>Please provide the location of %1</source>
        <comment>%1 is a file name</comment>
        <translation>Por favor, indique la ubicación de %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="125"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Por favor, elija la ubicación del torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="228"/>
        <source>Invalid torrent file</source>
        <translation>Archivo torrent no válido</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="228"/>
        <source>This is not a valid torrent file.</source>
        <translation>Esto no es un archivo torrent válido.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="422"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="423"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="424"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="425"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="426"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Semillas</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="427"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="428"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Bajada</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="429"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Subida</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="430"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="431"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tiempo Restante</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="432"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="433"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Añadido</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="434"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="435"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="436"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite Bajada</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="437"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite Subida</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="438"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="439"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="440"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Desc. Sesión</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="441"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Sub. Sesión</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="442"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="443"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tiempo Activo</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="444"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Ruta Destino</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="445"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="446"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límite de ratio</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="447"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Visto Completo</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="448"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última Actividad</translation>
    </message>
    <message>
        <location filename="../core/qtlibtorrent/torrentmodel.cpp" line="449"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamaño Total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="424"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="427"/>
        <source>Trackerless (0)</source>
        <translation>Sin tracker (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="430"/>
        <source>Error (0)</source>
        <translation>Error (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="433"/>
        <source>Warning (0)</source>
        <translation>Advertencia (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="476"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="533"/>
        <source>Trackerless (%1)</source>
        <translation>Sin tracker (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="482"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="528"/>
        <source>%1 (%2)</source>
        <comment>openbittorrent.com (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="558"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="590"/>
        <source>Error (%1)</source>
        <translation>Error (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="571"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="605"/>
        <source>Warning (%1)</source>
        <translation>Advertencia (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="625"/>
        <source>Couldn&apos;t decode favicon for URL `%1`. Trying to download favicon in PNG format.</source>
        <translation>No se puede decodificar el favicon de la URL `%1`. Intentando descargar el favicon en formato PNG.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="630"/>
        <source>Couldn&apos;t decode favicon for URL `%1`.</source>
        <translation>No se puede decodificar el favicon de la URL `%1`.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="644"/>
        <source>Couldn&apos;t download favicon for URL `%1`. Reason: `%2`</source>
        <translation>No se puede descargar el favicon de la URL `%1`. Razón: `%2`</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="651"/>
        <source>Resume torrents</source>
        <translation>Reanudar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="652"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="653"/>
        <source>Delete torrents</source>
        <translation>Eliminar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="688"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="703"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="64"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="65"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="66"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="67"/>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="201"/>
        <location filename="../gui/properties/trackerlist.cpp" line="275"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="202"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="223"/>
        <source>This torrent is private</source>
        <translation>Este torrent es privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="279"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="283"/>
        <source>Not working</source>
        <translation>No funciona</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="286"/>
        <source>Not contacted yet</source>
        <translation>Todavía no contactado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="372"/>
        <source>Tracker URL:</source>
        <translation>URL del tracker:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="372"/>
        <source>Tracker editing</source>
        <translation>Editando tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="378"/>
        <location filename="../gui/properties/trackerlist.cpp" line="391"/>
        <source>Tracker editing failed</source>
        <translation>Falló la edición del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="378"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>La URL del tracker es inválida.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="391"/>
        <source>The tracker URL already exists.</source>
        <translation>La URL del tracker ya existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="450"/>
        <source>Add a new tracker...</source>
        <translation>Añadir nuevo tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="456"/>
        <source>Copy tracker URL</source>
        <translation>Copiar URL del tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="457"/>
        <source>Edit selected tracker URL</source>
        <translation>Editar el tracker seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="465"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forzar recomunicación con los trackers seleccionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="468"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forzar recomunicación con todos los trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="455"/>
        <source>Remove tracker</source>
        <translation>Eliminar tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo para añadir trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers a añadir (uno por línea):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Lista de URL compatible con μTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="79"/>
        <source>I/O Error</source>
        <translation>Error de Entrada/Salida (I/O)</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="79"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error al intentar abrir el archivo descargado.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="124"/>
        <source>No change</source>
        <translation>Sin cambios</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="124"/>
        <source>No additional trackers were found.</source>
        <translation>No se encontró ningún tracker adicional.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="133"/>
        <source>Download error</source>
        <translation>Error de descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.h" line="133"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La lista de trackers no pudo ser descargada. Razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="95"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="98"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Descargando metadatos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="104"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Reservando espacio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="131"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="118"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>En cola</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="111"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="107"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="101"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="114"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="122"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="125"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>En cola para su verificación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="128"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Comprobando datos de continuación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="134"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="137"/>
        <source>Missing Files</source>
        <translation>Faltan archivos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="151"/>
        <source>/s</source>
        <comment>/second (.i.e per second)</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="159"/>
        <source>KiB/s</source>
        <comment>KiB/second (.i.e per second)</comment>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="167"/>
        <source>Seeded for %1</source>
        <comment>e.g. Seeded for 3m10s</comment>
        <translation>Sembrado durante %1</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="230"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>hace %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="785"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="793"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="801"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="587"/>
        <source>Column visibility</source>
        <translation>Visibilidad de columnas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="257"/>
        <source>Choose save path</source>
        <translation>Seleccione una ruta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="506"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límite de velocidad de bajada del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="539"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límite de velocidad de subida del torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>Recheck confirmation</source>
        <translation>Confirmación de comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>¿Esta seguro que desea comprobar los torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="659"/>
        <source>New Label</source>
        <translation>Nueva etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="659"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="665"/>
        <source>Invalid label name</source>
        <translation>Nombre de la etiqueta no válido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="665"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Por favor, no utilice caracteres especiales para el nombre de la etiqueta.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="693"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="693"/>
        <source>New name:</source>
        <translation>Nuevo nombre:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="734"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reanudar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="736"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forzar reanudación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="738"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="740"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="742"/>
        <source>Preview file...</source>
        <translation>Previsualizar archivo...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="744"/>
        <source>Limit share ratio...</source>
        <translation>Límitar ratio de compartición...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="746"/>
        <source>Limit upload rate...</source>
        <translation>Tasa límite de subida...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="748"/>
        <source>Limit download rate...</source>
        <translation>Tasa límite de bajada...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="750"/>
        <source>Open destination folder</source>
        <translation>Abrir carpeta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="752"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="754"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="756"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover al principio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="758"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover al final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="760"/>
        <source>Set location...</source>
        <translation>Establecer destino...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="766"/>
        <source>Copy name</source>
        <translation>Copiar nombre</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="913"/>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="762"/>
        <source>Force recheck</source>
        <translation>Forzar verificación de archivo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>Copy magnet link</source>
        <translation>Copiar enlace magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="768"/>
        <source>Super seeding mode</source>
        <translation>Modo supersiembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="771"/>
        <source>Rename...</source>
        <translation>Renombrar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="773"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orden secuencial</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="776"/>
        <source>Download first and last piece first</source>
        <translation>Descargar antes primeras y últimas partes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="872"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nueva...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Borrar etiqueta</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites de ratio de subida/bajada</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Usar límite de ratio global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Sin límites de ratio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Establecer límite de ratio en</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="77"/>
        <source>The Web UI is listening on port %1</source>
        <translation>La interfaz Web está escuchando en el puerto %1</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="79"/>
        <source>Web UI Error - Unable to bind Web UI to port %1</source>
        <translation>Error de la interfaz de Usuario Web - No se puede enlazar al puerto %1</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="55"/>
        <source>An advanced BitTorrent client programmed in &lt;nobr&gt;C++&lt;/nobr&gt;, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un cliente BitTorrent avanzado programado en &lt;nobr&gt;C++&lt;/nobr&gt;, basado en el toolkit Qt y en libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="57"/>
        <source>Copyright %1 2006-2015 The qBittorrent project</source>
        <translation>Copyright %1 2006-2015 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="59"/>
        <source>Home Page: </source>
        <translation>Página Web:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="61"/>
        <source>Bug Tracker: </source>
        <translation>Bug Tracker: </translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="63"/>
        <source>Forum: </source>
        <translation>Foro: </translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="66"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent en Freenode</translation>
    </message>
</context>
<context>
    <name>addPeerDialog</name>
    <message>
        <location filename="../gui/properties/peer.ui" line="20"/>
        <source>Peer addition</source>
        <translation>Añadir par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peer.ui" line="36"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peer.ui" line="59"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autenticación del tracker</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Usuario:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="154"/>
        <source>Log in</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmar borrado - qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recordar siempre esta elección</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Eliminar también los archivos del disco duro</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="308"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Herramienta de creación de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Creación de un nuevo archivo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="60"/>
        <source>Add file</source>
        <translation>Nuevo archivo</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="67"/>
        <source>Add folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Archivo o carpeta a añadir al torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>Semillas Web URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="98"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Puedes separar los grupos de trackers con una linea vacía.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Tamaño de la pieza:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="165"/>
        <source>16 KiB</source>
        <translation type="unfinished">512 KiB {16 ?}</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="170"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="175"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="180"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="185"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="190"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="195"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="200"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="205"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="210"/>
        <source>8 MiB</source>
        <translation type="unfinished">4 MiB {8 ?}</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="215"/>
        <source>16 MiB</source>
        <translation type="unfinished">4 MiB {16 ?}</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="223"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="248"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privado (no se distribuirá por la red DHT si se marca)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="255"/>
        <source>Start seeding after creation</source>
        <translation>Comenzar la siembra después de la creación</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="265"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar los límites de ratio para este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="301"/>
        <source>Create and save...</source>
        <translation>Crear y guardar...</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreator/createtorrent.ui" line="272"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Añadir enlace torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="58"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Solo uno por línea (pueden ser enlaces HTTP, enlaces magnet o info-hashes)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="80"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="87"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descargar de URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>No URL entered</source>
        <translation>No se ha introducido ninguna URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>Please type at least one URL.</source>
        <translation>Por favor introduce al menos una URL.</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Motores de búsqueda instalados:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="65"/>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="83"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Puedes obtener nuevos motores de búsqueda aquí: &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="98"/>
        <source>Install a new one</source>
        <translation>Instalar uno nuevo</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="105"/>
        <source>Check for updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="112"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="129"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="178"/>
        <source>Uninstall warning</source>
        <translation>Advertencia de desinstalación</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="180"/>
        <source>Uninstall success</source>
        <translation>Desinstalación correcta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="345"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>El enlace no parece contener un plugin de búsqueda.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="360"/>
        <source>Select search plugins</source>
        <translation>Seleccione los plugins de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="241"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="266"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="271"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="281"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="284"/>
        <source>Search plugin install</source>
        <translation>Instalar plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="121"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="192"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="304"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="124"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="158"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="195"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="307"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="241"/>
        <source>A more recent version of %1 search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Una versión más reciente del plugin de motor de búsqueda %1 ya está instalada.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="361"/>
        <source>qBittorrent search plugin</source>
        <translation>Plugin de búsqueda de qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="413"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="468"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="475"/>
        <source>Search plugin update</source>
        <translation>Actualización del plugin de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="447"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="468"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Lo siento, el servidor de actualizaciones no está disponible temporalmente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="413"/>
        <source>All your plugins are already up to date.</source>
        <translation>Todos tus plugins ya están actualizados.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="266"/>
        <source>%1 search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 no pudo ser actualizado, se mantendrá la versión antigua.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="271"/>
        <source>%1 search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 no pudo ser instalado.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="180"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Todos los plugins seleccionados fueron instalados correctamente</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="178"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Algunos plugins no pudieron ser desinstalados porque están incluidos en qBittorrent. Solamente pueden ser desinstalados los que han sido añadidos por ti.
En su lugar, esos plugins fueron deshabilitados.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="281"/>
        <source>%1 search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 fue actualizado correctamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="284"/>
        <source>%1 search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El plugin de motor de búsqueda %1 fue instalado correctamente.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="345"/>
        <source>Invalid link</source>
        <translation>Enlace inválido</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="475"/>
        <source>Sorry, %1 search plugin installation failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Lo sentimos, la instalación del plugin de búsqueda %1 ha fallado.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="337"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="346"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nuevo plugin de motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="338"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="347"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Información del problema</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../core/fs_utils.cpp" line="475"/>
        <location filename="../core/fs_utils.cpp" line="478"/>
        <location filename="../core/fs_utils.cpp" line="510"/>
        <location filename="../core/fs_utils.cpp" line="522"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../core/misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="310"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="420"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="424"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="298"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="236"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>Todas las descargas se han completado. qBittorrent apagará el equipo ahora.</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="413"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../core/misc.cpp" line="416"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="378"/>
        <source>Working</source>
        <translation>Trabajando</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="382"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="384"/>
        <source>Not working</source>
        <translation>No funciona</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="384"/>
        <source>Not contacted yet</source>
        <translation>Aún no contactado</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../gui/options_imp.cpp" line="1174"/>
        <location filename="../gui/options_imp.cpp" line="1176"/>
        <source>Choose export directory</source>
        <translation>Selecciona una ruta de exportación</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1212"/>
        <location filename="../gui/options_imp.cpp" line="1214"/>
        <location filename="../gui/options_imp.cpp" line="1225"/>
        <location filename="../gui/options_imp.cpp" line="1227"/>
        <source>Choose a save directory</source>
        <translation>Seleccione una ruta para guardar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1128"/>
        <source>Add directory to scan</source>
        <translation>Añadir una ruta para escanear</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1135"/>
        <source>Folder is already being watched.</source>
        <translation>Esta carpeta ya está en seleccionada para escanear.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1138"/>
        <source>Folder does not exist.</source>
        <translation>La carpeta no existe.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1141"/>
        <source>Folder is not readable.</source>
        <translation>La carpeta no es legible.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1151"/>
        <source>Failure</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1151"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>No se puede escanear esta carpeta &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1198"/>
        <location filename="../gui/options_imp.cpp" line="1200"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1198"/>
        <location filename="../gui/options_imp.cpp" line="1200"/>
        <source>Choose an IP filter file</source>
        <translation>Seleccione un archivo de filtro IP</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1266"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1277"/>
        <source>SSL Key</source>
        <translation>Clave SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1308"/>
        <source>Parsing error</source>
        <translation>Error de análisis</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1308"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No se ha podido analizar el filtro IP proporcionado</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1310"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1310"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro IP analizado correctamente: %1 reglas fueron aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1396"/>
        <source>Invalid key</source>
        <translation>Clave no válida</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1396"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta no es una clave SSL válida.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1411"/>
        <source>Invalid certificate</source>
        <translation>Certificado no válido</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1411"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este no es un Certificado SSL válido.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1420"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Los tiempos de inicio y finalización no pueden ser iguales.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1423"/>
        <source>Time Error</source>
        <translation>Error de tiempo</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Fuente del plugin</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Fuente del plugin de búsqueda:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Enlace web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Previsualizar selección</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="38"/>
        <source>File preview</source>
        <translation>Previsualizar archivo</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="54"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Los siguientes archivos pueden previzualizarse, por favor seleccione uno de ellos:</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="89"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="34"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="57"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="81"/>
        <source>Stopped</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="113"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="123"/>
        <source>Go to description page</source>
        <translation>Ir a la página de descripción</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="143"/>
        <source>Search engines...</source>
        <translation>Motores de búsqueda...</translation>
    </message>
</context>
</TS>
