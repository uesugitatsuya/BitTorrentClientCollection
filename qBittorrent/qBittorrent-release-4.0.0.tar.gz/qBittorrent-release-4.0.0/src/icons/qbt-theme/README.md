qBittorrent Theme Icons
------------------------------------------
Initial `qbt-theme` icons created by Bert Verhelst (<verhelstbert@gmail.com>). 

Icons are based on the `Font-Awesome` icon-set: [link](http://fontawesome.io/icons/). 

If you need to add an icon that qBittorrent does not already use, you can take an icon from the SVG fork of `Font-Awesome`: [link](https://github.com/encharm/Font-Awesome-SVG-PNG).
