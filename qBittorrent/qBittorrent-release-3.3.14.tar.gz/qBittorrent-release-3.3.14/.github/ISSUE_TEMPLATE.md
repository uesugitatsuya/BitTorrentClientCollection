**Please provide the following information**

### qBittorrent version and Operating System:

### If on linux, libtorrent and Qt version:

### What is the problem:

### What is the expected behavior:

### Steps to reproduce:

### Extra info(if any):

