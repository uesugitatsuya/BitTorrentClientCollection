<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="id">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Tentang qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="83"/>
        <source>About</source>
        <translation>Tentang</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <source>Author</source>
        <translation>Pengembang</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="216"/>
        <location filename="../gui/about.ui" line="293"/>
        <source>Name:</source>
        <translation>Nama:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="240"/>
        <location filename="../gui/about.ui" line="281"/>
        <source>Country:</source>
        <translation>Negara:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="228"/>
        <location filename="../gui/about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>Surel:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="262"/>
        <source>Greece</source>
        <translation>Yunani</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Pengelola saat ini</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="354"/>
        <source>Original author</source>
        <translation>Pengembang asli</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="412"/>
        <source>Libraries</source>
        <translation>Pustaka</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="424"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Versi qBittorrent dibangun dengan menggunakan pustaka berikut:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="184"/>
        <source>France</source>
        <translation>Perancis</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="382"/>
        <source>Translation</source>
        <translation>Terjemahan</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="399"/>
        <source>License</source>
        <translation>Lisensi</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Terima Kasih</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Simpan sebagai</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="53"/>
        <source>Browse...</source>
        <translation>Telusuri...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="62"/>
        <source>Set as default save path</source>
        <translation>Tetapkan sebagai jalur baku penyimpanan</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="72"/>
        <source>Never show again</source>
        <translation>Jangan pernah tampilkan lagi</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Torrent settings</source>
        <translation>Pengaturan torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="95"/>
        <source>Start torrent</source>
        <translation>Jalankan torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="126"/>
        <source>Skip hash check</source>
        <translation>Lewati pengecekan hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="136"/>
        <source>Torrent Information</source>
        <translation>Informasi Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Size:</source>
        <translation>Ukuran:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="158"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="184"/>
        <source>Date:</source>
        <translation>Tanggal:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="198"/>
        <source>Info Hash:</source>
        <translation>Info Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="289"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="294"/>
        <source>High</source>
        <translation>Tinggi</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="299"/>
        <source>Maximum</source>
        <translation>Maksimum</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="304"/>
        <source>Do not download</source>
        <translation>Jangan unduh</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="165"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="636"/>
        <source>I/O Error</source>
        <translation>Galat I/O</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="165"/>
        <source>The torrent file does not exist.</source>
        <translation>Berkas torrent tidak ada.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="173"/>
        <source>Invalid torrent</source>
        <translation>Torrent tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="173"/>
        <source>Failed to load the torrent: %1</source>
        <translation>Gagal memuat torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="185"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <source>Already in download list</source>
        <translation>Telah ada di dalam daftar unduh</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="333"/>
        <source>Free disk space: %1</source>
        <translation>Ruang bebas diska: 1%</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="662"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Tidak Tersedia</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="663"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Tidak Tersedia</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="671"/>
        <source>Not available</source>
        <translation>Tidak tersedia</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="202"/>
        <source>Invalid magnet link</source>
        <translation>Tautan magnet tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="185"/>
        <source>Torrent is already in download list. Trackers were merged.</source>
        <translation>Torrent telah ada di dalam daftar unduh. Pelacak digabungkan.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="188"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="216"/>
        <source>Cannot add torrent</source>
        <translation>Tidak bisa menambahkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="188"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>Tidak bisa menambahkan torrent ini. Sepertinya sudah ditambahkan.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="202"/>
        <source>This magnet link was not recognized</source>
        <translation>Tautan magnet ini tidak dikenali</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <source>Magnet link is already in download list. Trackers were merged.</source>
        <translation>Tautan magnet telah ada di dalam daftar unduh. Pelacak digabungkan.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="216"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>Tidak bisa menambahkan torrent ini. Sepertinya sedang ditambahkan.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="225"/>
        <source>Magnet link</source>
        <translation>Tautan magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="232"/>
        <source>Retrieving metadata...</source>
        <translation>Mengambil metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="331"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Tidak Tersedia</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="362"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="370"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="372"/>
        <source>Choose save path</source>
        <translation>Pilih jalur penyimpanan</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="421"/>
        <source>Rename the file</source>
        <translation>Ubah nama berkas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="422"/>
        <source>New name:</source>
        <translation>Nama baru:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="426"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="451"/>
        <source>The file could not be renamed</source>
        <translation>Berkas tidak bisa diubah namanya</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="427"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Nama berkas ini mengandung karakter yang dilarang, mohon pilih karakter yang berbeda.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="452"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="485"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Nama ini telah digunakan dalam folder ini. Mohon gunakan nama yang berbeda.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="484"/>
        <source>The folder could not be renamed</source>
        <translation>Folder tidak bisa diubah namanya</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="541"/>
        <source>Rename...</source>
        <translation>Ubah nama...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="545"/>
        <source>Priority</source>
        <translation>Prioritas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="637"/>
        <source>Invalid metadata</source>
        <translation>Metadata tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="644"/>
        <source>Parsing metadata...</source>
        <translation>Mengurai metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="648"/>
        <source>Metadata retrieval complete</source>
        <translation>Pengambilan metadata komplet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="708"/>
        <source>Download Error</source>
        <translation>Galat Unduh</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.h" line="219"/>
        <source>Disk write cache size</source>
        <translation>Ukuran tembolok penulisan diska</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="201"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="239"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Port keluar (Min) [0: Nonaktif]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="244"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Port keluar (Max) [0: Nonaktif]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="247"/>
        <source>Recheck torrents on completion</source>
        <translation>Periksa ulang torrent saat selesai</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="253"/>
        <source>Transfer list refresh interval</source>
        <translation>Selang penyegaran daftar transfer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="252"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Setting</source>
        <translation>Pengaturan</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Nilai</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="199"/>
        <source> (auto)</source>
        <translation> (otomatis)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="224"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="225"/>
        <source>Disk cache expiry interval</source>
        <translation>Selang kedaluwarsa tembolok diska</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="228"/>
        <source>Enable OS cache</source>
        <translation>Aktifkan tembolok OS</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="233"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation> m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="256"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Singkap negara rekanan (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="259"/>
        <source>Resolve peer host names</source>
        <translation>Singkap nama hos rekanan</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="264"/>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation>Jumlah maksimum koneksi terbuka-setengah [0: Nonaktif]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="267"/>
        <source>Strict super seeding</source>
        <translation>Pembibitan super ketat</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="287"/>
        <source>Network Interface (requires restart)</source>
        <translation>Antarmuka Jaringan (wajib memulai ulang)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="290"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Mendengarkan alamat IPv6 (wajib memulai ulang)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="315"/>
        <source>Confirm torrent recheck</source>
        <translation>Konfirmasi pemeriksaan ulang torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="318"/>
        <source>Exchange trackers with other peers</source>
        <translation>Bertukar pelacak dengan rekanan lainnya</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="321"/>
        <source>Always announce to all trackers</source>
        <translation>Selalu umumkan ke semua pelacak</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="269"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Antarmuka apapun</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="234"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Selang penyimpanan data perlanjutan</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="293"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Alamat IP untuk melapor ke pelacak (wajib memulai ulang)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="296"/>
        <source>Display program on-screen notifications</source>
        <translation>Tampilkan notifikasi program pada layar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="299"/>
        <source>Enable embedded tracker</source>
        <translation>Aktifkan pelacak tertanam</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="304"/>
        <source>Embedded tracker port</source>
        <translation>Port pelacak tertanam</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="307"/>
        <source>Check for software updates</source>
        <translation>Periksa pemutakhiran program</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="311"/>
        <source>Use system icon theme</source>
        <translation>Gunakan tema ikon sistem</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="105"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 dimulai</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="262"/>
        <source>Information</source>
        <translation>Informasi</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="263"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Untuk mengendalikan qBittorent, akses Web UI di http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="264"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Nama pengguna administrator Web UI adalah: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="267"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Sandi administrator Web UI masih bawaan: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="268"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Ini adalah resiko keamanan, mohon pertimbangkan untuk mengubah sandi Anda dari preferensi program.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="442"/>
        <source>Saving torrent progress...</source>
        <translation>Menyimpan kemajuan torrent...</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="208"/>
        <source>Save to:</source>
        <translation>Simpan ke:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Pengunduh RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable Automated RSS Downloader</source>
        <translation>Aktifkan Pengunduh RSS Otomatis</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="48"/>
        <source>Download Rules</source>
        <translation>Aturan Unduhan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="88"/>
        <source>Rule Definition</source>
        <translation>Definisi Aturan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="94"/>
        <source>Use Regular Expressions</source>
        <translation>Gunakan Ekpresi Reguler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="103"/>
        <source>Must Contain:</source>
        <translation>Harus Memuat:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="110"/>
        <source>Must Not Contain:</source>
        <translation>Tidak Boleh Memuat:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="117"/>
        <source>Episode Filter:</source>
        <translation>Penyaring Episode:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="180"/>
        <source>Assign Label:</source>
        <translation>Tetapkan Label:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="196"/>
        <source>Save to a Different Directory</source>
        <translation>Simpan ke Direktori Berbeda</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="236"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Abaikan Kecocokan Berturut-turut untuk (0 untuk Nonaktif)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="246"/>
        <source> days</source>
        <translation>hari</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="276"/>
        <source>Add Paused:</source>
        <translation>Tambah Jeda:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="284"/>
        <source>Use global settings</source>
        <translation>Gunakan pengaturan global</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="289"/>
        <source>Always</source>
        <translation>Selalu</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="294"/>
        <source>Never</source>
        <translation>Jangan Pernah</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="315"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Terapkan Aturan ke Umpan:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="337"/>
        <source>Matching RSS Articles</source>
        <translation>Artikel RSS yang Cocok</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>&amp;Import...</source>
        <translation>&amp;Impor...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="369"/>
        <source>&amp;Export...</source>
        <translation>&amp;Ekspor...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Artikel yang cocok berdasarkan penyaring episode.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Example: </source>
        <translation>Contoh:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>akan cocok 2, 5, 8 sampai 15, 30 dan episode seterusnya dari musim pertama</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Episode filter rules: </source>
        <translation>Aturan penyaring episode:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Nomor musim wajib bernilai bukan nol</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Episode number is a mandatory non-zero value</source>
        <translation>Nomor episode wajib bernilai bukan nol</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Filter must end with semicolon</source>
        <translation>Penyaring harus diakhiri dengan titik koma</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Tiga jenis rentang untuk episode yang didukung:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Nomor tunggal: &lt;b&gt;1x25;&lt;/ b&gt; cocok dengan episode 25 dari musim pertama</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Rentang normal: &lt;b&gt;1x25-40;&lt;/b&gt; cocok dengan episode 25 sampai 40 dari musim pertama</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="85"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one</source>
        <translation>Rentang tidak terbatas: &lt;b&gt;1x25-;&lt;/b&gt; cocok dengan episode 25 dan seterusnya dari musim pertama</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="266"/>
        <source>Last Match: %1 days ago</source>
        <translation>Cocok Terakhir: %1 hari yang lalu</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="268"/>
        <source>Last Match: Unknown</source>
        <translation>Cocok Terakhir: Tidak Diketahui</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>New rule name</source>
        <translation>Nama aturan baru</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Mohon ketik nama dari aturan unduh baru.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="365"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="483"/>
        <source>Rule name conflict</source>
        <translation>Nama aturan konflik</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="365"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="483"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Aturan dengan nama ini telah ada, mohon pilih nama lain.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Apakah Anda yakin ingin membuang aturan unduhan bernama &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="385"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Apakah Anda yakin ingin menghapus aturan unduh yang dipilih?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <source>Rule deletion confirmation</source>
        <translation>Konfirmasi penghapusan aturan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="402"/>
        <source>Destination directory</source>
        <translation>Direktori tujuan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="410"/>
        <source>Invalid action</source>
        <translation>Tindakan tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="410"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Daftar ini kosong, tidak ada yang bisa diekspor.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="414"/>
        <source>Where would you like to save the list?</source>
        <translation>Di mana Anda ingin menyimpan daftar?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="414"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Daftar aturan (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>I/O Error</source>
        <translation>Galat I/O</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>Failed to create the destination file</source>
        <translation>Gagal membuat berkas tujuan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Mohon arahkan ke berkas aturan unduh RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>Rules list</source>
        <translation>Daftar aturan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <source>Import Error</source>
        <translation>Galat Impor</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <source>Failed to import the selected rules file</source>
        <translation>Gagal untuk mengimpor berkas aturan yang dipilih</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="442"/>
        <source>Add new rule...</source>
        <translation>Tambah aturan baru...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>Delete rule</source>
        <translation>Hapus aturan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="450"/>
        <source>Rename rule...</source>
        <translation>Ubah nama aturan...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="452"/>
        <source>Delete selected rules</source>
        <translation>Hapus aturan yang dipilih</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Rule renaming</source>
        <translation>Menamai ulang aturan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Please type the new rule name</source>
        <translation>Mohon ketik nama aturan baru</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="581"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Mode regex: gunakan ekspresi reguler mirip Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="585"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Mode wildcard: Anda dapat menggunakan&lt;ul&gt;&lt;li&gt;? untuk mencocokkan karakter tunggal apapun&lt;/li&gt;&lt;li&gt;* untuk mencocokkan nol atau lebih karakter apapun&lt;/li&gt;&lt;li&gt;Spasi dihitung sebagai operator AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="587"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Mode wildcard: Anda dapat menggunakan&lt;ul&gt;&lt;li&gt;? untuk mencocokkan karakter tunggal apapun&lt;/li&gt;&lt;li&gt;* untuk mencocokkan nol atau lebih karakter apapun&lt;/li&gt;&lt;li&gt;| digunakan sebagai operator OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="173"/>
        <source>Peer ID: </source>
        <translation>ID Rekanan:</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="316"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>User-Agent HTTP adalah &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="343"/>
        <source>Anonymous mode [ON]</source>
        <translation>Mode anonim [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="345"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Mode anonim [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="535"/>
        <source>PeX support [ON]</source>
        <translation>Dukungan PeX [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="537"/>
        <source>PeX support [OFF]</source>
        <translation>Dukungan PeX [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="539"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Wajib memulai ulang untuk menjungkit dukungan PeX</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="544"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Dukungan Penemuan Rekanan Lokal [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="548"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Dukungan Penemuan Rekanan Lokal [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="561"/>
        <source>Encryption support [ON]</source>
        <translation>Dukungan enkripsi [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="566"/>
        <source>Encryption support [FORCED]</source>
        <translation>Dukungan enkripsi [DIPAKSA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="571"/>
        <source>Encryption support [OFF]</source>
        <translation>Dukungan enkripsi [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="649"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Pelacak Tertanam [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="651"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Gagal memulai pelacak tertanam!</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="654"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Pelacak Tertanam [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="692"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removing...</source>
        <translation>&apos;%1&apos; telah mencapai rasio maksimum yang Anda tetapkan. Membuang...</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="698"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Pausing...</source>
        <translation>&apos;%1&apos; telah mencapai rasio maksimum yang Anda tetapkan. Menangguhkan...</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1175"/>
        <source>Error: Could not create torrent export directory: &apos;%1&apos;</source>
        <translation>Galat: Tidak bisa membuat direktori ekspor torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1203"/>
        <source>Error: could not export torrent &apos;%1&apos;, maybe it has not metadata yet.</source>
        <translation>Galat: tidak bisa mengekspor torrent &apos;%1&apos;, mungkin belum memiliki metadata.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1430"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Status jaringan sistem berubah menjadi %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1430"/>
        <source>ONLINE</source>
        <translation>DARING</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1430"/>
        <source>OFFLINE</source>
        <translation>LURING</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1440"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>Konfigurasi jaringan dari %1 telah berubah, menyegarkan jalinan sesi</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1724"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Tidak bisa mengawakode &apos;%1&apos; berkas torrent.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1830"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Mengunduh rekursif berkas &apos;%1&apos; yang tertanam di dalam torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2141"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Tidak bisa menyimpan &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2246"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>karena %1 dinonaktifkan.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2249"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>karena %1 dinonaktifkan.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2267"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Pencarian bibit URL gagal untuk URL: &apos;%1&apos;, pesan: %2</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="811"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; telah dibuang dari daftar transfer dan diska.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="813"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; telah dibuang dari daftar transfer.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="972"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Mengunduh &apos;%1&apos;, mohon tunggu...</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1183"/>
        <source>Torrent Export: torrent is invalid, skipping...</source>
        <translation>Ekspor Torrent: torrent tidak valid, lewati...</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1276"/>
        <source>DHT support [ON]</source>
        <translation>Dukungan DHT [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1281"/>
        <source>DHT support [OFF]. Reason: %1</source>
        <translation>Dukungan DHT [MATI]. Alasan: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1289"/>
        <source>DHT support [OFF]</source>
        <translation>Dukungan DHT [MATI]</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="165"/>
        <location filename="../core/bittorrent/session.cpp" line="1510"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent sedang mencoba mendengarkan semua port antarmuka: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1514"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent gagal mendengarkan semua port antarmuka: %1. Alasan: %2</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1463"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Antarmuka jaringan yang dijabarkan tidak valid: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="169"/>
        <location filename="../core/bittorrent/session.cpp" line="1521"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent sedang mencoba mendengarkan port antarmuka %1: %2</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1487"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent tidak menemukan alamat lokal %1 untuk didengarkan</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1635"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Pelacak &apos;%1&apos; telah ditambahkan ke torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1645"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Pelacak &apos;%1&apos; telah dihapus dari torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1660"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Bibit URL &apos;%1&apos; telah ditambahkan ke torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1666"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>Bibit URL &apos;%1&apos; telah dihapus dari torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1946"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Tidak bisa melanjutkan torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1969"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Berhasil mengurai penyaring IP yang diberikan: %1 aturan diterapkan.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="1975"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Galat: Gagal mengurai penyaring IP yang diberikan.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2103"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Tidak bisa menambahkan torrent. Alasan: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2124"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; dilanjutkan. (lanjut cepat)</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2155"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; ditambahkan ke daftar unduh.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2210"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Sebuah galat I/O telah terjadi, &apos;%1&apos; ditangguhkan. %2</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2218"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Pemetaan port gagal, pesan: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2224"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Pemetaan port sukses, pesan: %1</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2234"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>disebabkan oleh penyaring IP.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2237"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>disebabkan oleh penyaring port.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2240"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>disebabkan oleh pembatasan mode campuran i2p.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2243"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>karena memiliki port yang rendah.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2281"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent berhasil mendengarkan port antarmuka %1: %2/%3</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2307"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation>qBittorrent gagal mendengarkan port antarmuka %1: %2/%3. Alasan: %4</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/session.cpp" line="2316"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP eksternal: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../core/bittorrent/torrenthandle.cpp" line="1313"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Tidak bisa memindahkan torrent: &apos;%1&apos;. Alasan: %2</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/torrenthandle.cpp" line="1454"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>Ukuran berkas tidak sama untuk torrent &apos;%1&apos;, torrent ditangguhkan.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/torrenthandle.cpp" line="1460"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Data lanjut cepat ditolak untuk torrent &apos;%1&apos;. Alasan: %2. Memeriksa lagi...</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Pengelolaan Kuki</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Kunci</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Nilai</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are: &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Kunci umum untuk kuki adalah: &apos;%1&apos;, &apos;%2&apos;.
Anda seharusnya mendapatkan informasi ini dari preferensi peramban Web Anda.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Apakah Anda yakin ingin menghapus &apos;%1&apos; dari daftar transfer?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="50"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Apakah Anda yakin ingin menghapus %1 torrent ini dari daftar transfer?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>White: Missing pieces</source>
        <translation>Putih: Bagian hilang</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Green: Partial pieces</source>
        <translation>Hijau: Bagian parsial</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Blue: Completed pieces</source>
        <translation>Biru: Bagian komplet</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="27"/>
        <source>General</source>
        <translation>Umum</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>IP yang diblokir</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="101"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; telah diblokir %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="103"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; telah dicekal</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Umpan RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>Belum dibaca</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="65"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="159"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="267"/>
        <source>I/O Error: Could not open ip filter file in read mode.</source>
        <translation>Galat I/O: Tidak bisa membuka berkas penyaring ip dalam mode baca-saja.</translation>
    </message>
    <message>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="278"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="290"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="311"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="320"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="330"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="340"/>
        <location filename="../core/bittorrent/private/filterparserthread.cpp" line="360"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Galat Mengurai: Berkas penyaring bukan berkas P2B PeerGuardian yang valid.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="101"/>
        <location filename="../core/net/private/geoipdatabase.cpp" line="131"/>
        <source>Unsupported database file size.</source>
        <translation>Ukuran berkas basis data tidak didukung.</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Galat metadata: entri &apos;%1&apos; tidak ditemukan.</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Galat metadata: tipe entri &apos;%1&apos; tidak valid.</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="246"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versi basis data tidak didukung: %1.%2</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="253"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versi IP tidak didukung: %1</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="260"/>
        <source>Unsupported record size: %1</source>
        <translation>Ukuran perekaman tidak didukung: %1</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="273"/>
        <source>Invalid database type: %1</source>
        <translation>Tipe basis data tidak valid: %1</translation>
    </message>
    <message>
        <location filename="../core/net/private/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Basis data rusak: bagian data tidak ditemukan.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>File</source>
        <translation>Berkas</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Edit</source>
        <translation>Sunting</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Help</source>
        <translation>Bantuan</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Unduh Torrent dari URL mereka atau tautan Magnet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Only one link per line</source>
        <translation>Hanya satu tautan per baris</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Download local torrent</source>
        <translation>Unduh torrent lokal</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Download</source>
        <translation>Unduh</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Batas laju unggah global harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>Batas laju unduh global harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Batas laju unggah alternatif harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>Batas laju unduh alternatif harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Unduhan aktif maksimum harus lebih besar dari -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Unggahan aktif maksimum harus lebih besar dari -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Torrent aktif maksimum harus lebih besar dari -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Jumlah maksimum batas koneksi harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Jumlah maksimum batas koneksi per torrent harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Jumlah maksimum batas slot unggah per torrent harus lebih besar dari 0 atau nonaktif.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Tidak bisa menyimpan preferensi program, qBittorrent mungkin tidak terjangkau.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>Language</source>
        <translation>Bahasa</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>Port yang digunakan untuk koneksi masuk harus antara 1 dan 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>Port yang digunakan untuk Web UI harus antara 1 dan 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Tidak bisa masuk, qBittorrent mungkin tidak terjangkau.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>Invalid Username or Password.</source>
        <translation>Nama Pengguna atau Sandi tidak valid.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Password</source>
        <translation>Sandi</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Login</source>
        <translation>Masuk</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>Upload Failed!</source>
        <translation>Gagal Mengunggah!</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Original authors</source>
        <translation>Pengembang asli</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Upload limit:</source>
        <translation>Batas unggah:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Download limit:</source>
        <translation>Batas unduh:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Apply</source>
        <translation>Terapkan</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Add</source>
        <translation>Tambah</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Upload Torrents</source>
        <translation>Unggah Torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>All</source>
        <translation>Semua</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Downloading</source>
        <translation>Mengunduh</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Seeding</source>
        <translation>Membibit</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Completed</source>
        <translation>Komplet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="83"/>
        <source>Resumed</source>
        <translation>Dilanjutkan</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="84"/>
        <source>Paused</source>
        <translation>Ditangguhkan</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Active</source>
        <translation>Aktif</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Inactive</source>
        <translation>Tidak aktif</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Terunduh</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Logout</source>
        <translation>Keluar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Apakah Anda yakin ingin menghapus torrent yang dipilih dari daftar transfer?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Panjang nama pengguna Web UI minimal harus 3 karakter.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>Panjang sandi Web UI minimal harus 3 karakter.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Save</source>
        <translation>Simpan</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Klien qBittorrent tidak terjangkau</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>HTTP Server</source>
        <translation>Server HTTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>The following parameters are supported:</source>
        <translation>Parameter berikut didukung:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Torrent path</source>
        <translation>Jalur torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Torrent name</source>
        <translation>Nama torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent telah dimatikan.</translation>
    </message>
</context>
<context>
    <name>LabelFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Semua (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Unlabeled (0)</source>
        <translation>Tidak berlabel (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="214"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="260"/>
        <source>All (%1)</source>
        <comment>this is for the label filter</comment>
        <translation>Semua (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="217"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="235"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="263"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="268"/>
        <source>Unlabeled (%1)</source>
        <translation>Tidak berlabel (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="239"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="276"/>
        <source>%1 (%2)</source>
        <comment>label_name (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="330"/>
        <source>Add label...</source>
        <translation>Tambah label...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="334"/>
        <source>Remove label</source>
        <translation>Buang label</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="335"/>
        <source>Remove unused labels</source>
        <translation>Buang label yang tidak digunakan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="337"/>
        <source>Resume torrents</source>
        <translation>Lanjutkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="338"/>
        <source>Pause torrents</source>
        <translation>Tangguhkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="339"/>
        <source>Delete torrents</source>
        <translation>Hapus torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>New Label</source>
        <translation>Label Baru</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Invalid label name</source>
        <translation>Nama label tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Mohon tidak menggunakan karakter spesial apapun di nama label.</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../gui/lineedit/src/lineedit.cpp" line="30"/>
        <source>Clear the text</source>
        <translation>Kosongkan teks</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Salin</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Kosongkan</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="37"/>
        <source>&amp;Edit</source>
        <translation>&amp;Sunting</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="60"/>
        <source>&amp;Tools</source>
        <translation>&amp;Perkakas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="80"/>
        <source>&amp;File</source>
        <translation>&amp;Berkas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="50"/>
        <source>&amp;Help</source>
        <translation>B&amp;antuan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="64"/>
        <source>On Downloads &amp;Done</source>
        <translation>Saat Unduhan &amp;Selesai</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="90"/>
        <source>&amp;View</source>
        <translation>&amp;Tampilan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="161"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opsi...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>&amp;Resume</source>
        <translation>&amp;Lanjutkan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="206"/>
        <source>Torrent &amp;Creator</source>
        <translation>Pem&amp;buat Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="211"/>
        <source>Set Upload Limit...</source>
        <translation>Tetapkan Batas Unggah...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="216"/>
        <source>Set Download Limit...</source>
        <translation>Tetapkan Batas Unduh...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="226"/>
        <source>Set Global Download Limit...</source>
        <translation>Tetapkan Batas Unduh Global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="231"/>
        <source>Set Global Upload Limit...</source>
        <translation>Tetapkan Batas Unggah Global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="236"/>
        <source>Minimum Priority</source>
        <translation>Prioritas Minimum</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="244"/>
        <source>Top Priority</source>
        <translation>Prioritas Utama</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Decrease Priority</source>
        <translation>Turunkan Prioritas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Increase Priority</source>
        <translation>Naikkan Prioritas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="271"/>
        <location filename="../gui/mainwindow.ui" line="274"/>
        <source>Alternative Speed Limits</source>
        <translation>Batas Kecepatan Alternatif</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="282"/>
        <source>&amp;Top Toolbar</source>
        <translation>Bilah Ala&amp;t Atas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="285"/>
        <source>Display Top Toolbar</source>
        <translation>Tampilkan Bilah Alat Atas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="293"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>Ke&amp;cepatan di Bilah Judul</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="296"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Tampilkan Kecepatan Transfer di Bilah Judul</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="304"/>
        <source>&amp;RSS Reader</source>
        <translation>Pembaca &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="312"/>
        <source>Search &amp;Engine</source>
        <translation>M&amp;esin Pencari</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="317"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>K&amp;unci qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="331"/>
        <source>&amp;Import Existing Torrent...</source>
        <translation>&amp;Impor Torrent Yang Ada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="334"/>
        <source>Import Torrent...</source>
        <translation>Impor Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="339"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nasi!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="347"/>
        <source>R&amp;esume All</source>
        <translation>Lanjutkan S&amp;emua</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="360"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="371"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Keluar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="379"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspensi Sistem</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="387"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernasi Sistem</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="395"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Matikan Sistem</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="403"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Nonaktif</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="418"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Statistik</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="423"/>
        <source>Check for Updates</source>
        <translation>Periksa Pemutakhiran</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="426"/>
        <source>Check for Program Updates</source>
        <translation>Periksa Pemutakhiran Program</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>&amp;About</source>
        <translation>Tent&amp;ang</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="156"/>
        <source>Exit</source>
        <translation>Keluar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="182"/>
        <source>&amp;Pause</source>
        <translation>Tang&amp;guhkan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Delete</source>
        <translation>&amp;Hapus</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="352"/>
        <source>P&amp;ause All</source>
        <translation>Jed&amp;a Semua</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="145"/>
        <source>&amp;Add Torrent File...</source>
        <translation>T&amp;ambah Berkas Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="148"/>
        <source>Open</source>
        <translation>Buka</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="153"/>
        <source>E&amp;xit</source>
        <translation>&amp;Keluar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="164"/>
        <source>Options</source>
        <translation>Opsi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="177"/>
        <source>Resume</source>
        <translation>Lanjutkan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>Pause</source>
        <translation>Tangguhkan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="193"/>
        <source>Delete</source>
        <translation>Hapus</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="201"/>
        <source>Open URL</source>
        <translation>Buka URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="221"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentasi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="320"/>
        <source>Lock</source>
        <translation>Kunci</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="408"/>
        <location filename="../gui/mainwindow.cpp" line="1293"/>
        <source>Show</source>
        <translation>Tampilkan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1480"/>
        <source>Check for program updates</source>
        <translation>Periksa pemutakhiran program</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="323"/>
        <source>Lock qBittorrent</source>
        <translation>Kunci qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="198"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Tambah &amp;Tautan Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Jika Anda suka qBittorrent, mohon menyumbang!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="363"/>
        <location filename="../gui/mainwindow.cpp" line="1508"/>
        <source>Execution Log</source>
        <translation>Log Eksekusi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="478"/>
        <source>Clear the password</source>
        <translation>Kosongkan sandi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="187"/>
        <source>Filter torrent list...</source>
        <translation>Saring daftar torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="158"/>
        <source>&amp;Set Password</source>
        <translation>Tetapkan &amp;Kata Sandi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="160"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Kosongkan Kata Sandi</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="205"/>
        <source>Transfers</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="343"/>
        <source>Torrent file association</source>
        <translation>Asosiasi berkas torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="344"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent bukan aplikasi baku untuk membuka berkas torrent atau tautan magnet.
Apakah Anda ingin mengasosiasikan qBittorrent dengan berkas torrent atau tautan magnet?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="375"/>
        <source>Icons Only</source>
        <translation>Hanya Ikon</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="377"/>
        <source>Text Only</source>
        <translation>Hanya Teks</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="379"/>
        <source>Text Alongside Icons</source>
        <translation>Teks di Samping Ikon</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="381"/>
        <source>Text Under Icons</source>
        <translation>Teks di Bawah Ikon</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="383"/>
        <source>Follow System Style</source>
        <translation>Ikuti Gaya Sistem</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <location filename="../gui/mainwindow.cpp" line="792"/>
        <source>UI lock password</source>
        <translation>Sandi kunci UI</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <location filename="../gui/mainwindow.cpp" line="792"/>
        <source>Please type the UI lock password:</source>
        <translation>Mohon ketik sandi kunci UI:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="467"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Panjang sandi minimal harus 3 karakter</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="472"/>
        <source>Password update</source>
        <translation>Sandi diperbarui</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="472"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>Sandi kunci UI telah berhasil diperbarui</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="478"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Apakah Anda yakin ingin mengosongkan sandi?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="530"/>
        <source>Search</source>
        <translation>Cari</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="541"/>
        <source>Transfers (%1)</source>
        <translation>Transfer (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="632"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="632"/>
        <source>Failed to add torrent: %1</source>
        <translation>Gagal menambahkan torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <source>Download completion</source>
        <translation>Keselesaian unduhan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="644"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Galat I/O</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="705"/>
        <source>Recursive download confirmation</source>
        <translation>Konfirmasi unduh rekursif</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="706"/>
        <source>Yes</source>
        <translation>Ya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="707"/>
        <source>No</source>
        <translation>Tidak</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="708"/>
        <source>Never</source>
        <translation>Jangan Pernah</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="728"/>
        <source>Global Upload Speed Limit</source>
        <translation>Batas Kecepatan Unggah Global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="744"/>
        <source>Global Download Speed Limit</source>
        <translation>Batas Kecepatan Unduh Global</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="894"/>
        <source>&amp;No</source>
        <translation>&amp;Tidak</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="895"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="896"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Selalu Ya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1379"/>
        <source>Python found in %1</source>
        <translation>Python ditemukan di %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1394"/>
        <source>Old Python Interpreter</source>
        <translation>Interpreter Python Usang</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1464"/>
        <source>qBittorrent Update Available</source>
        <translation>Tersedia Pemutakhiran qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1474"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Telah Menggunakan qBittorrent Versi Terbaru</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1404"/>
        <source>Undetermined Python version</source>
        <translation>Versi Python tidak diketahui</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; telah selesai diunduh.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="644"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Sebuah galat I/O telah terjadi pada torrent &apos;%1&apos;.
Alasan: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="705"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrent &apos;%1&apos; memuat berkas torrent, apakah Anda ingin melanjutkan dengan mengunduh mereka?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Tidak bisa mengunduh berkas pada URL &apos;%1&apos;, alasan: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1394"/>
        <source>Your Python version %1 is outdated. Please upgrade to latest version for search engines to work. Minimum requirement: 2.7.0/3.3.0.</source>
        <translation>Python versi %1 Anda sudah usang. Mohon mutakhirkan ke versi terakhir agar mesin pencari bisa bekerja. Kebutuhan minimum: 2.7.0/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1404"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>Tidak bisa menentukan versi Python Anda (%1), Mesin pencari dinonfungsikan.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1415"/>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Missing Python Interpreter</source>
        <translation>Kehilangan Interpreter Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1416"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python dibutuhkan untuk dapat menggunakan mesin pencari tetapi sepertinya belum dipasang.
Apakah Anda ingin memasangnya sekarang?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python dibutuhkan untuk dapat menggunakan mesin pencari tetapi sepertinya belum dipasang.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1465"/>
        <source>A new version is available.
Update to version %1?</source>
        <translation>Versi baru tersedia.
Mutakhirkan ke versi %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1475"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Pemutakhiran tidak tersedia.
Anda telah menggunakan versi terbaru.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1479"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Periksa Pemutakhiran</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1577"/>
        <source>Checking for Updates...</source>
        <translation>Memeriksa Pemutakhiran...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1578"/>
        <source>Already checking for program updates in the background</source>
        <translation>Sudah memeriksa pemutakhiran program di latar belakang</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1593"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python ditemukan di &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1646"/>
        <source>Download error</source>
        <translation>Galat unduh</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1646"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python tidak bisa diunduh, alasan: %1.
Mohon pasang secara manual.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="467"/>
        <location filename="../gui/mainwindow.cpp" line="806"/>
        <source>Invalid password</source>
        <translation>Sandi tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="508"/>
        <location filename="../gui/mainwindow.cpp" line="520"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>URL download error</source>
        <translation>Galat unduh URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="806"/>
        <source>The password is invalid</source>
        <translation>Sandi tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1188"/>
        <location filename="../gui/mainwindow.cpp" line="1195"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Kecepatan DL: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1191"/>
        <location filename="../gui/mainwindow.cpp" line="1197"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Kecepatan UL: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1202"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1, U: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1293"/>
        <source>Hide</source>
        <translation>Sembunyikan</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="891"/>
        <source>Exiting qBittorrent</source>
        <translation>Keluar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="892"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Beberapa sedang dalam proses transfer.
Apakah Anda yakin ingin qBittorrent keluar?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1033"/>
        <source>Open Torrent Files</source>
        <translation>Buka Berkas Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1034"/>
        <source>Torrent Files</source>
        <translation>Berkas Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1069"/>
        <source>Options were saved successfully.</source>
        <translation>Opsi telah disimpan dengan sukses.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="200"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>DNS dinamis Anda telah berhasil diperbarui.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="204"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Galat DNS Dinamis: Layanan ini sementara tidak tersedia, akan dicoba ulang dalam 30 menit.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="213"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Galat DNS Dinamis: nama hos yang diberikan tidak ada di dalam akun yang disebutkan.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="218"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Galat DNS Dinamis: nama pengguna/sandi tidak valid.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="223"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Galat DNS Dinamis: qBittorrent terdaftar hitam oleh layanan, mohon laporkan kutu di http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Galat DNS Dinamis: %1 dikembalikan oleh layanan, mohon laporkan kutu di http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="235"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Galat DNS Dinamis: Nama pengguna Anda telah diblokir karena penyalahgunaan.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="256"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Galat DNS Dinamis: nama domain yang diberikan tidak valid.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="267"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Galat DNS Dinamis: nama pengguna yang diberikan terlalu pendek.</translation>
    </message>
    <message>
        <location filename="../core/net/dnsupdater.cpp" line="278"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Galat DNS Dinamis: kata sandi yang diberikan terlalu pendek.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="104"/>
        <source>I/O Error</source>
        <translation>Galat I/O</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="117"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>Ukuran berkas adalah %1. Melebihi batas unduh %2.</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="186"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Pengalihan tidak terduga ke URI magnet.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="104"/>
        <location filename="../core/net/geoipmanager.cpp" line="432"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Basis data GeoIP dimuat. Tipe: %1. Durasi bangun: %2.</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="108"/>
        <location filename="../core/net/geoipmanager.cpp" line="453"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>Tidak bisa memuat basis data GeoIP. Alasan: %1</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="141"/>
        <location filename="../core/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>T/A</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="142"/>
        <source>Asia/Pacific Region</source>
        <translation>Kawasan Asia/Pasifik</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="143"/>
        <source>Europe</source>
        <translation>Eropa</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andora</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Uni Emirat Arab</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afganistan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua dan Barbuda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="151"/>
        <source>Netherlands Antilles</source>
        <translation>Antillen Belanda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="152"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="153"/>
        <source>Antarctica</source>
        <translation>Antartika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="154"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="155"/>
        <source>American Samoa</source>
        <translation>Samoa Amerika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="156"/>
        <source>Austria</source>
        <translation>Austria</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="157"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="158"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>Azerbaijan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnia dan Herzegovina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Belgia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="169"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="170"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei Darussalam</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="171"/>
        <source>Bolivia</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="172"/>
        <source>Brazil</source>
        <translation>Brazil</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="173"/>
        <source>Bahamas</source>
        <translation>Bahama</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="174"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="175"/>
        <source>Bouvet Island</source>
        <translation>Pulau Bouvet</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="176"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="177"/>
        <source>Belarus</source>
        <translation>Belarusia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="178"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="179"/>
        <source>Canada</source>
        <translation>Kanada</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="180"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Kepulauan Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="181"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Republik Demokratik Kongo</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="182"/>
        <source>Central African Republic</source>
        <translation>Republik Afrika Tengah</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="183"/>
        <source>Congo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="184"/>
        <source>Switzerland</source>
        <translation>Swiss</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="185"/>
        <source>Cote D&apos;Ivoire</source>
        <translation>Pantai Gading</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="186"/>
        <source>Cook Islands</source>
        <translation>Kepulauan Cook</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="187"/>
        <source>Chile</source>
        <translation>Chili</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="188"/>
        <source>Cameroon</source>
        <translation>Kamerun</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="189"/>
        <source>China</source>
        <translation>Cina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="190"/>
        <source>Colombia</source>
        <translation>Kolombia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="191"/>
        <source>Costa Rica</source>
        <translation>Kosta Rika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="192"/>
        <source>Cuba</source>
        <translation>Kuba</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="193"/>
        <source>Cape Verde</source>
        <translation>Tanjung Verde</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="194"/>
        <source>Christmas Island</source>
        <translation>Pulau Natal</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="195"/>
        <source>Cyprus</source>
        <translation>Siprus</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="196"/>
        <source>Czech Republic</source>
        <translation>Republik Ceko</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="197"/>
        <source>Germany</source>
        <translation>Jerman</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="198"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="199"/>
        <source>Denmark</source>
        <translation>Denmark</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="200"/>
        <source>Dominica</source>
        <translation>Dominika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="201"/>
        <source>Dominican Republic</source>
        <translation>Republik Dominika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="202"/>
        <source>Algeria</source>
        <translation>Aljazair</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="203"/>
        <source>Ecuador</source>
        <translation>Ekuador</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="204"/>
        <source>Estonia</source>
        <translation>Estonia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="205"/>
        <source>Egypt</source>
        <translation>Mesir</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="206"/>
        <source>Western Sahara</source>
        <translation>Sahara Barat</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="207"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="208"/>
        <source>Spain</source>
        <translation>Spanyol</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="209"/>
        <source>Ethiopia</source>
        <translation>Etiopia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="210"/>
        <source>Finland</source>
        <translation>Finlandia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="211"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="212"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Kepulauan Falkland (Malvina)</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="213"/>
        <source>Micronesia, Federated States of</source>
        <translation>Federasi Mikronesia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="214"/>
        <source>Faroe Islands</source>
        <translation>Kepulauan Faroe</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="215"/>
        <source>France</source>
        <translation>Perancis</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="216"/>
        <source>France, Metropolitan</source>
        <translation>Perancis Metropolitan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="217"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="218"/>
        <source>United Kingdom</source>
        <translation>Britania Raya</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="219"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="220"/>
        <source>Georgia</source>
        <translation>Georgia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="221"/>
        <source>French Guiana</source>
        <translation>Guyana Perancis</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="222"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="223"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="224"/>
        <source>Greenland</source>
        <translation>Greenland</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="225"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="226"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="227"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="228"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Khatulistiwa</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="229"/>
        <source>Greece</source>
        <translation>Yunani</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="230"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Georgia Selatan dan Kepulauan Sandwich Selatan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="231"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="232"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="233"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="234"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="235"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="236"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Pulau Heard dan Kepulauan McDonald</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="237"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="238"/>
        <source>Croatia</source>
        <translation>Kroasia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="239"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="240"/>
        <source>Hungary</source>
        <translation>Hongaria</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="241"/>
        <source>Indonesia</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="242"/>
        <source>Ireland</source>
        <translation>Irlandia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="243"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="244"/>
        <source>India</source>
        <translation>India</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="245"/>
        <source>British Indian Ocean Territory</source>
        <translation>Wilayah Samudra Hindia Britania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="246"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="247"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Republik Islam Iran</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="248"/>
        <source>Iceland</source>
        <translation>Islandia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="249"/>
        <source>Italy</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="250"/>
        <source>Jamaica</source>
        <translation>Jamaika</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="251"/>
        <source>Jordan</source>
        <translation>Yordania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="252"/>
        <source>Japan</source>
        <translation>Jepang</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="253"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="254"/>
        <source>Kyrgyzstan</source>
        <translation>Kirgizstan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="255"/>
        <source>Cambodia</source>
        <translation>Kamboja</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="256"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="257"/>
        <source>Comoros</source>
        <translation>Komoro</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="258"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint Kitts dan Nevis</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="259"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Korea Utara</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="260"/>
        <source>Korea, Republic of</source>
        <translation>Korea Selatan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="261"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="262"/>
        <source>Cayman Islands</source>
        <translation>Kepulauan Cayman</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="263"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="264"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Republik Demokratik Rakyat Laos</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="265"/>
        <source>Lebanon</source>
        <translation>Lebanon</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="266"/>
        <source>Saint Lucia</source>
        <translation>Saint Lucia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="267"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="268"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="269"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="270"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="271"/>
        <source>Lithuania</source>
        <translation>Lituania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="272"/>
        <source>Luxembourg</source>
        <translation>Luksemburg</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="273"/>
        <source>Latvia</source>
        <translation>Latvia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="274"/>
        <source>Libyan Arab Jamahiriya</source>
        <translation>Libya</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="275"/>
        <source>Morocco</source>
        <translation>Maroko</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="276"/>
        <source>Monaco</source>
        <translation>Monako</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="277"/>
        <source>Moldova, Republic of</source>
        <translation>Moldova</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="278"/>
        <source>Madagascar</source>
        <translation>Madagaskar</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="279"/>
        <source>Marshall Islands</source>
        <translation>Kepulauan Marshall</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="280"/>
        <source>Macedonia</source>
        <translation>Makedonia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="281"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="282"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="283"/>
        <source>Mongolia</source>
        <translation>Mongolia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="284"/>
        <source>Macau</source>
        <translation>Makau</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="285"/>
        <source>Northern Mariana Islands</source>
        <translation>Kepulauan Mariana Utara</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="286"/>
        <source>Martinique</source>
        <translation>Martinik</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="287"/>
        <source>Mauritania</source>
        <translation>Mauritania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="288"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="289"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="290"/>
        <source>Mauritius</source>
        <translation>Mauritius</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="291"/>
        <source>Maldives</source>
        <translation>Maladewa</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="292"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="293"/>
        <source>Mexico</source>
        <translation>Meksiko</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="294"/>
        <source>Malaysia</source>
        <translation>Malaysia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="295"/>
        <source>Mozambique</source>
        <translation>Mozambik</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="296"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="297"/>
        <source>New Caledonia</source>
        <translation>Kaledonia Baru</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="298"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="299"/>
        <source>Norfolk Island</source>
        <translation>Pulau Norfolk</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="300"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="301"/>
        <source>Nicaragua</source>
        <translation>Nikaragua</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="302"/>
        <source>Netherlands</source>
        <translation>Belanda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="303"/>
        <source>Norway</source>
        <translation>Norwegia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="304"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="305"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="306"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="307"/>
        <source>New Zealand</source>
        <translation>Selandia Baru</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="308"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="309"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="310"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="311"/>
        <source>French Polynesia</source>
        <translation>Polinesia Perancis</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="312"/>
        <source>Papua New Guinea</source>
        <translation>Papua Nugini</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="313"/>
        <source>Philippines</source>
        <translation>Filipina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="314"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="315"/>
        <source>Poland</source>
        <translation>Polandia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="316"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint Pierre dan Miquelon</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="317"/>
        <source>Pitcairn Islands</source>
        <translation>Kepulauan Pitcairn</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="318"/>
        <source>Puerto Rico</source>
        <translation>Puerto Riko</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="319"/>
        <source>Palestinian Territory</source>
        <translation>Palestina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="320"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="321"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="322"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="323"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="324"/>
        <source>Reunion</source>
        <translation>Reunion</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="325"/>
        <source>Romania</source>
        <translation>Rumania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="326"/>
        <source>Russian Federation</source>
        <translation>Rusia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="327"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="328"/>
        <source>Saudi Arabia</source>
        <translation>Arab Saudi</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="329"/>
        <source>Solomon Islands</source>
        <translation>Kepulauan Solomon</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="330"/>
        <source>Seychelles</source>
        <translation>Seiselensa</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="331"/>
        <source>Sudan</source>
        <translation>Sudan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="332"/>
        <source>Sweden</source>
        <translation>Swedia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="333"/>
        <source>Singapore</source>
        <translation>Singapura</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="334"/>
        <source>Saint Helena</source>
        <translation>Saint Helena</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="335"/>
        <source>Slovenia</source>
        <translation>Slovenia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="336"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard dan Jan Mayen</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="337"/>
        <source>Slovakia</source>
        <translation>Slowakia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="338"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="339"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="340"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="341"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="342"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="343"/>
        <source>Sao Tome and Principe</source>
        <translation>Sao Tome dan Principe</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="344"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="345"/>
        <source>Syrian Arab Republic</source>
        <translation>Suriah</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="346"/>
        <source>Swaziland</source>
        <translation>Swaziland</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="347"/>
        <source>Turks and Caicos Islands</source>
        <translation>Kepulauan Turks dan Caicos</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="348"/>
        <source>Chad</source>
        <translation>Chad</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="349"/>
        <source>French Southern Territories</source>
        <translation>Daratan Selatan dan Antarktika Perancis</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="350"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="351"/>
        <source>Thailand</source>
        <translation>Thailand</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="352"/>
        <source>Tajikistan</source>
        <translation>Tajikistan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="353"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="354"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="355"/>
        <source>Tunisia</source>
        <translation>Tunisia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="356"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="357"/>
        <source>Timor-Leste</source>
        <translation>Timor-Leste</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="358"/>
        <source>Turkey</source>
        <translation>Turki</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="359"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad dan Tobago</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="360"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="361"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="362"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzania</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="363"/>
        <source>Ukraine</source>
        <translation>Ukraina</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="364"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="365"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Kepulauan Terluar Kecil Amerika Serikat</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="366"/>
        <source>United States</source>
        <translation>Amerika Serikat</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="367"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="368"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="369"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Vatikan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="370"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Saint Vincent dan Grenadine</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="371"/>
        <source>Venezuela</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="372"/>
        <source>Virgin Islands, British</source>
        <translation>Kepulauan Virgin, Inggris</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="373"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Kepulauan Virgin, Amerika Serikat</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="374"/>
        <source>Vietnam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="375"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="376"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis dan Futuna</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="377"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="378"/>
        <source>Yemen</source>
        <translation>Yaman</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="379"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="380"/>
        <source>Serbia</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="381"/>
        <source>South Africa</source>
        <translation>Afrika Selatan</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="382"/>
        <source>Zambia</source>
        <translation>Zambia</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="383"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="384"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="385"/>
        <source>Anonymous Proxy</source>
        <translation>Proksi Anonim</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="386"/>
        <source>Satellite Provider</source>
        <translation>Penyedia Satelit</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="387"/>
        <source>Other</source>
        <translation>Lainnya</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="388"/>
        <source>Aland Islands</source>
        <translation>Kepulauan Aland</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="389"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="390"/>
        <source>Isle of Man</source>
        <translation>Pulau Man</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="391"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="392"/>
        <source>Saint Barthelemy</source>
        <translation>Saint Barthelemy</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="393"/>
        <source>Saint Martin</source>
        <translation>Saint Martin</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="421"/>
        <source>Could not uncompress GeoIP database file.</source>
        <translation>Tidak bisa mengurai berkas basis data GeoIP.</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="442"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>Tidak bisa menyimpan berkas basis data GeoIP yang diunduh.</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="445"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Berhasil memperbarui basis data GeoIP.</translation>
    </message>
    <message>
        <location filename="../core/net/geoipmanager.cpp" line="460"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>Tidak bisa mengunduh berkas basis data GeoIP. Alasan: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../core/net/portforwarder.cpp" line="110"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Dukungan UPnP / NAT-PMP [NYALA]</translation>
    </message>
    <message>
        <location filename="../core/net/portforwarder.cpp" line="119"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Dukungan UPnP / NAT-PMP [MATI]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../core/net/smtp.cpp" line="501"/>
        <source>Email Notification Error:</source>
        <translation>Galat Notifikasi Surel:</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="68"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="69"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="70"/>
        <source>Flags</source>
        <translation>Bendera</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Connection</source>
        <translation>Koneksi</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klien</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Kemajuan</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Kecepatan Unduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Kecepatan Unggah</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Terunduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Terunggah</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevansi</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="166"/>
        <source>Add a new peer...</source>
        <translation>Tambah rekanan baru...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="172"/>
        <source>Copy selected</source>
        <translation>Salin yang dipilih</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="174"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="212"/>
        <source>Ban peer permanently</source>
        <translation>Cekal rekanan secara permanen</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="186"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Secara manual menambahkan rekanan &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="190"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>Rekanan &apos;%1&apos; tidak bisa ditambahkan ke torrent ini.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="223"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Secara manual mencekal rekanan &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="194"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <source>Peer addition</source>
        <translation>Tambahan rekanan</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="194"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Beberapa rekanan tidak bisa ditambahkan. Periksa Log untuk detail lebih lanjut.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <source>The peers were added to this torrent.</source>
        <translation>Rekanan telah ditambahkan ke torrent ini.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="212"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Apakah Anda yakin ingin mencekal secara permanen rekanan yang dipilih?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="213"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ya</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="213"/>
        <source>&amp;No</source>
        <translation>&amp;Tidak</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="388"/>
        <source>interested(local) and choked(peer)</source>
        <translation>tertarik(lokal) dan choked(rekanan)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="394"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>tertarik(lokal) dan unchoked(rekanan)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="403"/>
        <source>interested(peer) and choked(local)</source>
        <translation>tertarik(rekanan) dan choked(lokal)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="409"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>tertarik(rekanan) dan unchoked(lokal)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="417"/>
        <source>optimistic unchoke</source>
        <translation>unchoke optimistis</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="424"/>
        <source>peer snubbed</source>
        <translation>penolakan rekanan</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="431"/>
        <source>incoming connection</source>
        <translation>koneksi masuk</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="438"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>tidak tertarik(lokal) dan unchoked(rekanan)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="445"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>tidak tertarik(rekanan) dan unchoked(lokal)</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="452"/>
        <source>peer from PEX</source>
        <translation>rekanan dari PEX</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="459"/>
        <source>peer from DHT</source>
        <translation>rekanan dari DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="466"/>
        <source>encrypted traffic</source>
        <translation>lalu lintas terenkripsi</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="473"/>
        <source>encrypted handshake</source>
        <translation>handshake terenkripsi</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="488"/>
        <source>peer from LSD</source>
        <translation>rekanan dari LSD</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="58"/>
        <source>No peer entered</source>
        <translation>Tidak ada rekanan yang dimasukkan</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="59"/>
        <source>Please type at least one peer.</source>
        <translation>Mohon ketik paling tidak satu rekanan.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="69"/>
        <source>Invalid peer</source>
        <translation>Rekanan tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="70"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>Rekanan &apos;%1&apos; tidak valid.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>White: Unavailable pieces</source>
        <translation>Putih: Bagian tidak ada</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>Blue: Available pieces</source>
        <translation>Biru: Bagian yang ada</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../gui/options.ui" line="69"/>
        <source>Downloads</source>
        <translation>Unduhan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="80"/>
        <source>Connection</source>
        <translation>Koneksi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="91"/>
        <source>Speed</source>
        <translation>Kecepatan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="113"/>
        <source>Web UI</source>
        <translation>Web UI</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="124"/>
        <source>Advanced</source>
        <translation>Tingkat Lanjut</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="209"/>
        <source>(Requires restart)</source>
        <translation>(Wajib memulai ulang)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Gunakan warna baris belang</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="295"/>
        <location filename="../gui/options.ui" line="321"/>
        <source>Start / Stop Torrent</source>
        <translation>Jalankan / Hentikan Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="305"/>
        <location filename="../gui/options.ui" line="331"/>
        <source>No action</source>
        <translation>Tidak ada tindakan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="701"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Imbuh ekstensi .!qb untuk berkas yang belum komplet</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="804"/>
        <source>Copy .torrent files to:</source>
        <translation>Salin berkas .torrent ke:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1121"/>
        <source>Connections Limits</source>
        <translation>Batas Koneksi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1274"/>
        <source>Proxy Server</source>
        <translation>Server Proksi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1577"/>
        <source>Global Rate Limits</source>
        <translation>Batas Laju Global</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1879"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Terapkan batas laju untuk overhead transpor</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1672"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Jadwalkan penggunaan batas laju alternatif</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1684"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Dari:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1708"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Ke:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1993"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Aktifkan Penemuan Rekanan Lokal untuk menemukan lebih banyak rekanan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2005"/>
        <source>Encryption mode:</source>
        <translation>Mode enkripsi:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2013"/>
        <source>Prefer encryption</source>
        <translation>Enkripsi Opsional</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2018"/>
        <source>Require encryption</source>
        <translation>Enkripsi Wajib</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2023"/>
        <source>Disable encryption</source>
        <translation>Enkripsi Nonaktif</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2058"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Informasi Lebih Banyak&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2101"/>
        <source>Maximum active downloads:</source>
        <translation>Unduhan aktif maksimum:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2121"/>
        <source>Maximum active uploads:</source>
        <translation>Unggahan aktif maksimum:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2141"/>
        <source>Maximum active torrents:</source>
        <translation>Torrent aktif maksimum:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="537"/>
        <source>When adding a torrent</source>
        <translation>Ketika menambahkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="58"/>
        <source>Behavior</source>
        <translation>Perilaku</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="173"/>
        <source>Language</source>
        <translation>Bahasa</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="553"/>
        <source>Display torrent content and some options</source>
        <translation>Tampilkan isi torrent dan beberapa opsi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="994"/>
        <source>Run external program on torrent completion</source>
        <translation>Jalankan program eksternal saat torrent selesai diunduh</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1057"/>
        <source>Port used for incoming connections:</source>
        <translation>Port yang digunakan untuk koneksi masuk:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1077"/>
        <source>Random</source>
        <translation>Acak</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1127"/>
        <source>Global maximum number of connections:</source>
        <translation>Jumlah maksimum koneksi global:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1153"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Jumlah maksimum koneksi per torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1176"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Jumlah maksimum slot unggah per torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1599"/>
        <location filename="../gui/options.ui" line="1790"/>
        <source>Upload:</source>
        <translation>Unggah:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1643"/>
        <location filename="../gui/options.ui" line="1797"/>
        <source>Download:</source>
        <translation>Unduh:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1606"/>
        <location filename="../gui/options.ui" line="1629"/>
        <location filename="../gui/options.ui" line="1836"/>
        <location filename="../gui/options.ui" line="1843"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="771"/>
        <source>Remove folder</source>
        <translation>Buang folder</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1749"/>
        <source>Every day</source>
        <translation>Setiap hari</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1977"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Pertukaran rekanan dengan aplikasi Bittorrent yang kompatibel (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1316"/>
        <source>Host:</source>
        <translation>Hos:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1295"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1282"/>
        <source>Type:</source>
        <translation>Jenis:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="14"/>
        <source>Options</source>
        <translation>Opsi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Tindakan klik ganda</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="278"/>
        <source>Downloading torrents:</source>
        <translation>Mengunduh torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="300"/>
        <location filename="../gui/options.ui" line="326"/>
        <source>Open destination folder</source>
        <translation>Buka folder tujuan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="313"/>
        <source>Completed torrents:</source>
        <translation>Torrent komplet:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="345"/>
        <source>Desktop</source>
        <translation>Destop</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="358"/>
        <source>Show splash screen on start up</source>
        <translation>Tampilkan layar sambutan saat memulai</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="368"/>
        <source>Start qBittorrent minimized</source>
        <translation>Mulai qBittorrent diminimalkan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="394"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimalkan qBittorrent ke area notifikasi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="404"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Tutup qBittorrent ke area notifikasi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="413"/>
        <source>Tray icon style:</source>
        <translation>Gaya ikon baki:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="421"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="426"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monokrom (Tema gelap)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="431"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monokrom (Tema cerah)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="181"/>
        <source>User Interface Language:</source>
        <translation>Bahasa Antarmuka Pengguna</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="237"/>
        <source>Transfer List</source>
        <translation>Daftar Transfer</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="243"/>
        <source>Confirm when deleting torrents</source>
        <translation>Konfirmasi ketika menghapus torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="351"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Mulai qBittorrent saat memulai Windows</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="375"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Konfirmasi saat keluar ketika torrent sedang aktif</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="385"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Tampilkan qBittorrent di area notifikasi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="444"/>
        <source>File association</source>
        <translation>Asosiasi berkas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="450"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Gunakan qBittorrent untuk berkas .torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="457"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Gunakan qBittorrent untuk tautan magnet</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="470"/>
        <source>Power Management</source>
        <translation>Pengelolaan Daya</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="476"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Cegah sistem tidur ketika torrent sedang aktif</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="546"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Jangan mulai mengunduh secara otomatis</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="562"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Tampilkan dialog torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="584"/>
        <source>Hard Disk</source>
        <translation>Diska</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="590"/>
        <source>Save files to location:</source>
        <translation>Simpan berkas ke lokasi:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="638"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Tambahkan label torrent ke jalur penyimpanan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="648"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pra-alokasi ruang diska untuk semua berkas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="655"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Simpan torrent yang belum komplet di:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="708"/>
        <source>Automatically add torrents from:</source>
        <translation>Secara otomatis menambahkan torrent dari:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="761"/>
        <source>Add folder...</source>
        <translation>Tambah folder...</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="853"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Salin berkas .torrent yang telah selesai diunduh ke:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="909"/>
        <source>Email notification upon download completion</source>
        <translation>Notifikasi surel saat selesai mengunduh</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="923"/>
        <source>Destination email:</source>
        <translation>Surel tujuan:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="933"/>
        <source>SMTP server:</source>
        <translation>Server SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="982"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Server ini membutuhkan koneksi aman (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1049"/>
        <source>Listening Port</source>
        <translation>Port yang Didengar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1099"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Gunakan penerusan port UPnP / NAT-PMP dari router saya</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1109"/>
        <source>Use different port on each startup</source>
        <translation>Gunakan port yang berbeda setiap kali memulai</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1235"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Jumlah maksimum slot unggah global:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1370"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Jika tidak, server proksi hanya digunakan untuk koneksi pelacak</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1373"/>
        <source>Use proxy for peer connections</source>
        <translation>Gunakan proksi untuk koneksi rekanan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1380"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Nonaktifkan koneksi yang tidak didukung oleh proksi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1393"/>
        <source>Use proxy only for torrents</source>
        <translation>Gunakan proksi hanya untuk torrent saja</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1390"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Umpan RSS, mesin pencari, pemutakhiran perangkat lunak atau hal yang lain selain pengunduhan torrent atau yang terkait (seperti pertukaran rekanan) akan menggunakan sambungan langsung.</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1462"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: Sandi disimpan tanpa enkripsi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1475"/>
        <source>IP Filtering</source>
        <translation>Penyaringan IP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1516"/>
        <source>Reload the filter</source>
        <translation>Muat ulang penyaring</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1532"/>
        <source>Apply to trackers</source>
        <translation>Terapkan ke pelacak</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1872"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Terapkan batas laju untuk rekanan pada LAN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1735"/>
        <source>When:</source>
        <translation>Kapan:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1754"/>
        <source>Weekdays</source>
        <translation>Hari kerja</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1759"/>
        <source>Weekends</source>
        <translation>Akhir pekan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1866"/>
        <source>Rate Limits Settings</source>
        <translation>Pengaturan Batas Laju</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1886"/>
        <source>Enable µTP protocol</source>
        <translation>Aktifkan protokol µTP</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1893"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Terapkan batas lagu protokol µTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1961"/>
        <source>Privacy</source>
        <translation>Privasi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1967"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Aktifkan DHT (jaringan desentralisasi) untuk menemukan lebih banyak rekanan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1980"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Aktifkan Pertukaran Rekanan (PeX) untuk menemukan lebih banyak rekanan</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1990"/>
        <source>Look for peers on your local network</source>
        <translation>Temukan rekanan di jaringan lokal Anda</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2048"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Aktifkan ketika menggunakan proksi atau koneksi VPN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2051"/>
        <source>Enable anonymous mode</source>
        <translation>Aktifkan mode anonim</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2200"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Jangan hitung torrent lambat pada batas ini</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2221"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Bibit torrent sampai rasio mereka tercapai</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2250"/>
        <source>then</source>
        <translation>lalu</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2261"/>
        <source>Pause them</source>
        <translation>Tangguhkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2266"/>
        <source>Remove them</source>
        <translation>Buang torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2285"/>
        <source>Automatically add these trackers to new downloads:</source>
        <translation>Secara otomatis menambahkan pelacak ini ke unduhan baru:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2404"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Gunakan UPnP / NAT-PMP untuk meneruskan port dari router saya</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2414"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Gunakan HTTPS daripada HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2457"/>
        <source>Import SSL Certificate</source>
        <translation>Impor sertifikat SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2510"/>
        <source>Import SSL Key</source>
        <translation>Impor kunci SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2445"/>
        <source>Certificate:</source>
        <translation>Sertifikat:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1666"/>
        <source>Alternative Rate Limits</source>
        <translation>Batas Laju Alternatif</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2498"/>
        <source>Key:</source>
        <translation>Kunci:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2532"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Informasi tentang sertifikat&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2577"/>
        <source>Bypass authentication for localhost</source>
        <translation>Lewati otentikasi untuk localhost</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2601"/>
        <source>Update my dynamic domain name</source>
        <translation>Perbarui nama domain dinamis saya</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2613"/>
        <source>Service:</source>
        <translation>Layanan:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2636"/>
        <source>Register</source>
        <translation>Daftar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2645"/>
        <source>Domain name:</source>
        <translation>Nama domain:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1290"/>
        <source>(None)</source>
        <translation>(Tak ada)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="102"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1305"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1342"/>
        <location filename="../gui/options.ui" line="2369"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="943"/>
        <location filename="../gui/options.ui" line="1406"/>
        <location filename="../gui/options.ui" line="2545"/>
        <source>Authentication</source>
        <translation>Otentikasi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="955"/>
        <location filename="../gui/options.ui" line="1420"/>
        <location filename="../gui/options.ui" line="2584"/>
        <location filename="../gui/options.ui" line="2659"/>
        <source>Username:</source>
        <translation>Nama pengguna:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="965"/>
        <location filename="../gui/options.ui" line="1440"/>
        <location filename="../gui/options.ui" line="2591"/>
        <location filename="../gui/options.ui" line="2673"/>
        <source>Password:</source>
        <translation>Sandi:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2086"/>
        <source>Torrent Queueing</source>
        <translation>Pengantrean Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2210"/>
        <source>Share Ratio Limiting</source>
        <translation>Pembatasan Rasio Berbagi</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2355"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Aktifkan Antarmuka Pengguna Web (Pengendali jauh)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1300"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1487"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Jalur penyaring (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../core/preferences.cpp" line="79"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>Mendeteksi kerusakan berkas ketika program keluar. Menggunakan berkas cadangan untuk kembali ke pengaturan sebelumnya.</translation>
    </message>
    <message>
        <location filename="../core/preferences.cpp" line="174"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Sebuah galat akses terjadi ketika mencoba untuk menyimpan berkas konfigurasi.</translation>
    </message>
    <message>
        <location filename="../core/preferences.cpp" line="176"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Sebuah galat format terjadi ketika mencoba untuk menyimpan berkas konfigurasi.</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../gui/previewselect.cpp" line="54"/>
        <source>Name</source>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="55"/>
        <source>Size</source>
        <translation>Ukuran</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="56"/>
        <source>Progress</source>
        <translation>Kemajuan</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Preview impossible</source>
        <translation>Mustahil pratinjau</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Maaf, kami tidak bisa meninjau berkas ini</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="106"/>
        <source>Not downloaded</source>
        <translation>Tidak diunduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="162"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="109"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="163"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Tinggi</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="103"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Campuran</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="112"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="164"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Maksimum</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="46"/>
        <source>General</source>
        <translation>Umum</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>Trackers</source>
        <translation>Pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="55"/>
        <source>Peers</source>
        <translation>Rekanan</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>HTTP Sources</source>
        <translation>Sumber HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="63"/>
        <source>Content</source>
        <translation>Isi</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Speed</source>
        <translation>Kecepatan</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="336"/>
        <source>Downloaded:</source>
        <translation>Terunduh:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="113"/>
        <source>Availability:</source>
        <translation>Ketersediaan:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="84"/>
        <source>Progress:</source>
        <translation>Kemajuan:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="160"/>
        <source>Transfer</source>
        <translation>Transfer</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="552"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Lama Aktif:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="581"/>
        <source>ETA:</source>
        <translation>ETA:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="510"/>
        <source>Uploaded:</source>
        <translation>Terunggah:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="439"/>
        <source>Seeds:</source>
        <translation>Bibit:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="455"/>
        <source>Download Speed:</source>
        <translation>Kecepatan Unduh:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="191"/>
        <source>Upload Speed:</source>
        <translation>Kecepatan Unggah:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="220"/>
        <source>Peers:</source>
        <translation>Rekanan:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="278"/>
        <source>Download Limit:</source>
        <translation>Batas Unduh:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="352"/>
        <source>Upload Limit:</source>
        <translation>Batas Unggah:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="597"/>
        <source>Wasted:</source>
        <translation>Terbuang:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="236"/>
        <source>Connections:</source>
        <translation>Koneksi:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="610"/>
        <source>Information</source>
        <translation>Informasi</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="869"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1054"/>
        <source>Torrent content:</source>
        <translation>Isi torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1021"/>
        <source>Select All</source>
        <translation>Pilih Semua</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1028"/>
        <source>Select None</source>
        <translation>Pilih Nihil</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1107"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1102"/>
        <source>High</source>
        <translation>Tinggi</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="294"/>
        <source>Share Ratio:</source>
        <translation>Rasio Berbagi:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="410"/>
        <source>Reannounce In:</source>
        <translation>Umumkan Ulang Dalam:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="368"/>
        <source>Last Seen Complete:</source>
        <translation>Komplet Terlihat Terakhir:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="628"/>
        <source>Total Size:</source>
        <translation>Total Ukuran:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="657"/>
        <source>Pieces:</source>
        <translation>Bagian:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="686"/>
        <source>Created By:</source>
        <translation>Dibuat Oleh:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="715"/>
        <source>Added On:</source>
        <translation>Ditambahkan Pada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="744"/>
        <source>Completed On:</source>
        <translation>Komplet Pada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="773"/>
        <source>Created On:</source>
        <translation>Dibuat Pada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="802"/>
        <source>Torrent Hash:</source>
        <translation>Hash Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="834"/>
        <source>Save Path:</source>
        <translation>Jalur Simpan:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1097"/>
        <source>Maximum</source>
        <translation>Maksimum</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1089"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1092"/>
        <source>Do not download</source>
        <translation>Jangan mengunduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="428"/>
        <source>Never</source>
        <translation>Jangan Pernah</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="435"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (memiliki %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="380"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="383"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 sesi ini)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="392"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (dibibit selama %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="399"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 maks)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="412"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="416"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="420"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="424"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 rerata.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="565"/>
        <source>Open</source>
        <translation>Buka</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="566"/>
        <source>Open Containing Folder</source>
        <translation>Buka Folder yang Memuat</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="567"/>
        <source>Rename...</source>
        <translation>Ubah nama...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="572"/>
        <source>Priority</source>
        <translation>Prioritas</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="618"/>
        <source>New Web seed</source>
        <translation>Bibit Web baru</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="624"/>
        <source>Remove Web seed</source>
        <translation>Buang bibit Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="626"/>
        <source>Copy Web seed URL</source>
        <translation>Salin URL bibit Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="627"/>
        <source>Edit Web seed URL</source>
        <translation>Sunting URL bibit Web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="652"/>
        <source>Rename the file</source>
        <translation>Ubah nama berkas</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="653"/>
        <source>New name:</source>
        <translation>Nama baru:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="657"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="688"/>
        <source>The file could not be renamed</source>
        <translation>Berkas tidak bisa diubah namanya</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="658"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Nama berkas ini mengandung karakter yang dilarang, mohon pilih karakter yang berbeda.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="689"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="727"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Nama ini telah digunakan dalam folder ini. Mohon gunakan nama yang berbeda.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="726"/>
        <source>The folder could not be renamed</source>
        <translation>Folder tidak bisa diubah namanya</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="829"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="81"/>
        <source>Filter files...</source>
        <translation>Saring berkas...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="772"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Bibit URL baru</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="773"/>
        <source>New URL seed:</source>
        <translation>Bibit URL baru:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="779"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="830"/>
        <source>This URL seed is already in the list.</source>
        <translation>Bibit URL ini telah ada di dalam daftar.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="822"/>
        <source>Web seed editing</source>
        <translation>Penyuntingan bibit web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="823"/>
        <source>Web seed URL:</source>
        <translation>URL bibit web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="110"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Alamat IP Anda telah dicekal setelah terlalu banyak percobaan otentikasi yang gagal.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="340"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Galat: &apos;%1&apos; bukan berkas torrent yang valid.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="345"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Galat: Tidak bisa menambahkan torrent ke sesi.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="354"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Galat I/O: Tidak bisa membuat berkas sementara.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="140"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 adalah parameter baris perintah yang tidak dikenal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="152"/>
        <location filename="../app/main.cpp" line="165"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 harus sebagai parameter baris perintah tunggal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="175"/>
        <source>%1 must specify the correct port (1 to 65535).</source>
        <translation>%1 harus menetapkan port yang benar (1 to 65535).</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="199"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Anda tidak bisa menggunakan %1: qBittorrent telah berjalan untuk pengguna ini.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="384"/>
        <source>Usage:</source>
        <translation>Penggunaan:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="397"/>
        <source>Options:</source>
        <translation>Opsi:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Displays program version</source>
        <translation>Tampilkan versi program</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Displays this help message</source>
        <translation>Tampilkan pesan bantuan ini</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="403"/>
        <source>Changes the Web UI port (current: %1)</source>
        <translation>Ubah port Web UI (saat ini: %1)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="406"/>
        <source>Disable splash screen</source>
        <translation>Nonaktifkan layar sambutan</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="408"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Jalankan dalam mode daemon (latar)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="410"/>
        <source>Downloads the torrents passed by the user</source>
        <translation>Unduh torrent yang diberikan oleh pengguna</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Help</source>
        <translation>Bantuan</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="429"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Jalankan aplikasi dengan opsi -h untuk membaca tentang parameter baris perintah.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="431"/>
        <source>Bad command line</source>
        <translation>Baris perintah buruk</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="437"/>
        <source>Bad command line: </source>
        <translation>Baris perintah buruk:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="450"/>
        <source>Legal Notice</source>
        <translation>Catatan Hukum</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="451"/>
        <location filename="../app/main.cpp" line="461"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent adalah program berbagi berkas. Ketika Anda menjalankan sebuah torrent, datanya akan tersedia untuk orang lain dalam konteks pengunggahan. Konten apapun yang Anda bagi adalah sepenuhnya tanggung jawab Anda.

Tidak ada pemberitahuan lebih lanjut yang akan dikeluarkan.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="452"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Tekan tombol %1 untuk menerima dan melanjutkan...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="462"/>
        <source>Legal notice</source>
        <translation>Catatan hukum</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="463"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="464"/>
        <source>I Agree</source>
        <translation>Saya Setuju</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="122"/>
        <source>Torrent name: %1</source>
        <translation>Nama torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="123"/>
        <source>Torrent size: %1</source>
        <translation>Ukuran torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="124"/>
        <source>Save path: %1</source>
        <translation>Jalur simpan: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="125"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent telah diunduh di %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="128"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Terima kasih telah menggunakan qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="134"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; telah selesai mengunduh</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="204"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Nama hos jauh tidak ditemukan (nama hos tidak valid)</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="206"/>
        <source>The operation was canceled</source>
        <translation>Operasi telah dibatalkan</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="208"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Server jauh menutup sambungan secara prematur, sebelum semua balasan diterima dan diproses</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="210"/>
        <source>The connection to the remote server timed out</source>
        <translation>Sambungan ke server jauh kehabisan waktu</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="212"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Jabat-tangan SSL/TLS gagal</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="214"/>
        <source>The remote server refused the connection</source>
        <translation>Server jauh menolak sambungan</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="216"/>
        <source>The connection to the proxy server was refused</source>
        <translation>Sambungan ke server proksi telah ditolak</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="218"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Server proksi menutup sambungan secara prematur</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="220"/>
        <source>The proxy host name was not found</source>
        <translation>Nama hos proksi tidak ditemukan</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="222"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Sambungan ke proksi kehabisan waktu atau proksi tidak membalas pada waktu permintaan dikirim</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="224"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>Proksi membutuhkan otentikasi dalam rangka menghormati permintaan tetapi tidak menerima kredensial apapun yang ditawarkan</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="226"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Akses ke konten jauh ditolak (401)</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="228"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Permintaan operasi pada konten jauh tidak diizinkan</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="230"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Konten jauh tidak ditemukan di server (404)</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="232"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Server jauh membutuhkan otentikasi untuk menyediakan konten tetapi kredensial yang diberikan tidak diterima</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="234"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>API Akses Jaringan tidak bisa menghormati permintaan karena protokol tidak dikenal</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="236"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Operasi yang diminta tidak valid untuk protokol ini</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="238"/>
        <source>An unknown network-related error was detected</source>
        <translation>Sebuah galat tidak dikenal terkait jaringan telah terdeteksi</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="240"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Sebuah galat tidak dikenal terkait proksi telah terdeteksi</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="242"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Sebuah galat tidak dikenal terkait konten jauh telah terdeteksi</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="244"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Sebuah gangguan dalam protokol telah terdeteksi</translation>
    </message>
    <message>
        <location filename="../core/net/downloadhandler.cpp" line="246"/>
        <source>Unknown error</source>
        <translation>Galat tidak dikenal</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="50"/>
        <location filename="../app/upgrade.h" line="63"/>
        <source>Upgrade</source>
        <translation>Tingkatkan</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="53"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Anda memutakhirkan dari versi lama yang memiliki proses penyimpanan yang berbeda. Anda harus meningkatkannya ke sistem penyimpanan baru. Anda tidak akan bisa menggunakan versi yang lebih lama dari v3.3.0 lagi. Lanjutkan? [y/t]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="62"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Anda memutakhirkan dari versi lama yang memiliki proses penyimpanan yang berbeda. Anda harus meningkatkannya ke sistem penyimpanan baru. Jika Anda melanjutkan, Anda tidak akan bisa menggunakan versi yang lebih lama dari v3.3.0 lagi.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="121"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>Tidak bisa migrasi torrent dengan hash: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="124"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>Tidak bisa migrasi torrent. Nama berkas lanjutcepat tidak valid: %1</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../gui/rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Cari</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Langganan baru</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="47"/>
        <location filename="../gui/rss/rss.ui" line="195"/>
        <location filename="../gui/rss/rss.ui" line="198"/>
        <source>Mark items read</source>
        <translation>Tandai item sudah dibaca</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Perbarui semua</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>Pengunduh RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Pengaturan...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="124"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrent: (klik dua kali untuk mengunduh)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="158"/>
        <location filename="../gui/rss/rss.ui" line="161"/>
        <source>Delete</source>
        <translation>Hapus</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="166"/>
        <source>Rename...</source>
        <translation>Ubah nama...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="169"/>
        <source>Rename</source>
        <translation>Ubah nama</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="174"/>
        <location filename="../gui/rss/rss.ui" line="177"/>
        <source>Update</source>
        <translation>Perbarui</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="182"/>
        <source>New subscription...</source>
        <translation>Langganan baru...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="187"/>
        <location filename="../gui/rss/rss.ui" line="190"/>
        <source>Update all feeds</source>
        <translation>Perbarui semua umpan</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="203"/>
        <source>Download torrent</source>
        <translation>Unduh torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="208"/>
        <source>Open news URL</source>
        <translation>Buka URL berita</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="213"/>
        <source>Copy feed URL</source>
        <translation>Salin URL umpan</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="218"/>
        <source>New folder...</source>
        <translation>Folder baru...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="223"/>
        <source>Manage cookies...</source>
        <translation>Kelola kuki...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Segarkan strim RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="218"/>
        <source>Stream URL:</source>
        <translation>URL Strim:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="218"/>
        <source>Please type a RSS stream URL</source>
        <translation>Mohon ketik URL strim RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="228"/>
        <source>This RSS feed is already in the list.</source>
        <translation>Umpan RSS ini telah ada di dalam daftar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Please choose a folder name</source>
        <translation>Mohon pilih nama folder</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Folder name:</source>
        <translation>Nama folder:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>New folder</source>
        <translation>Folder baru</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="254"/>
        <source>Deletion confirmation</source>
        <translation>Konfirmasi penghapusan</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="255"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Apakah Anda yakin ingin menghapus umpan RSS yang dipilih?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="406"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Mohon pilih nama baru untuk umpan RSS ini</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="406"/>
        <source>New feed name:</source>
        <translation>Nama umpan baru:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="410"/>
        <source>Name already in use</source>
        <translation>Nama telah digunakan</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="410"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Nama ini telah digunakan oleh item lainnya, mohon pilih yang lain.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="580"/>
        <source>Date: </source>
        <translation>Tanggal: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="582"/>
        <source>Author: </source>
        <translation>Penulis: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="659"/>
        <source>Unread</source>
        <translation>Belum dibaca</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../gui/rss/rssfeed.cpp" line="368"/>
        <source>Automatic download of &apos;%1&apos; from &apos;%2&apos; RSS feed failed because it doesn&apos;t contain a torrent or a magnet link...</source>
        <translation>Pengunduhan otomatis &apos;%1&apos; dari &apos;%2&apos; umpan RSS gagal karena tidak mengandung tautan torrent atau magnet...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rssfeed.cpp" line="373"/>
        <source>Automatically downloading &apos;%1&apos; torrent from &apos;%2&apos; RSS feed...</source>
        <translation>Secara otomatis mengunduh &apos;%1&apos; torrent dari &apos;%2&apos; umpan RSS...</translation>
    </message>
</context>
<context>
    <name>RssParser</name>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="464"/>
        <source>Failed to open downloaded RSS file.</source>
        <translation>Gagal membuka berkas RSS yang diunduh.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="501"/>
        <source>Invalid RSS feed at &apos;%1&apos;.</source>
        <translation>Umpan RSS tidak valid pada &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Pengaturan Pembaca RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Selang penyegaran umpan RSS:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>menit</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Jumlah maksimum artikel per umpan:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../core/scanfoldersmodel.cpp" line="157"/>
        <source>Watched Folder</source>
        <translation>Folder Dimonitor</translation>
    </message>
    <message>
        <location filename="../core/scanfoldersmodel.cpp" line="160"/>
        <source>Download here</source>
        <translation>Unduh di sini</translation>
    </message>
    <message>
        <location filename="../core/scanfoldersmodel.cpp" line="163"/>
        <source>Download path</source>
        <translation>Jalur unduhan</translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>All categories</source>
        <translation>Semua kategori</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Movies</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>TV shows</source>
        <translation>Acara Tv</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Games</source>
        <translation>Permainan</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Software</source>
        <translation>Perangkat lunak</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="60"/>
        <source>Pictures</source>
        <translation>Gambar</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="61"/>
        <source>Books</source>
        <translation>Buku</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="190"/>
        <location filename="../searchengine/searchengine.cpp" line="220"/>
        <location filename="../searchengine/searchengine.cpp" line="479"/>
        <source>Search</source>
        <translation>Cari</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="203"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Mohon pasang Python untuk menggunakan Mesin Pencari.</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="233"/>
        <source>Empty search pattern</source>
        <translation>Pola pencarian kosong</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="233"/>
        <source>Please type a search pattern first</source>
        <translation>Mohon ketik pola pencarian telebih dahulu</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="313"/>
        <source>Searching...</source>
        <translation>Mencari...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="316"/>
        <source>Stop</source>
        <translation>Hentikan</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="203"/>
        <location filename="../searchengine/searchengine.cpp" line="453"/>
        <source>Search Engine</source>
        <translation>Mesin Pencari</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="453"/>
        <location filename="../searchengine/searchengine.cpp" line="474"/>
        <source>Search has finished</source>
        <translation>Pencarian telah selesai</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="463"/>
        <source>An error occurred during search...</source>
        <translation>Sebuah galat terjadi saat pencarian...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="461"/>
        <location filename="../searchengine/searchengine.cpp" line="468"/>
        <source>Search aborted</source>
        <translation>Pencarian dibatalkan</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="118"/>
        <source>All enabled</source>
        <translation>Semua diaktifkan</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="119"/>
        <source>All engines</source>
        <translation>Semua mesin</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="122"/>
        <location filename="../searchengine/searchengine.cpp" line="177"/>
        <source>Multiple...</source>
        <translation>Banyak...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="262"/>
        <location filename="../searchengine/searchengine.cpp" line="334"/>
        <source>Results &lt;i&gt;(%1)&lt;/i&gt;:</source>
        <comment>i.e: Search results</comment>
        <translation>Hasil &lt;i&gt;(%1)&lt;/i&gt;:</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="472"/>
        <source>Search returned no results</source>
        <translation>Pencarian tidak menghasilkan apa-apa</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="561"/>
        <source>Stopped</source>
        <translation>Dihentikan</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../searchengine/searchlistdelegate.h" line="60"/>
        <location filename="../searchengine/searchlistdelegate.h" line="64"/>
        <source>Unknown</source>
        <translation>Tidak diketahui</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="66"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="67"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Ukuran</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="68"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Pembibit</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="69"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leecher</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="70"/>
        <source>Search engine</source>
        <translation>Mesin pencari</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="45"/>
        <source>Exit confirmation</source>
        <translation>Konfirmasi keluar</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="46"/>
        <source>Exit now</source>
        <translation>Keluar sekarang</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="49"/>
        <source>Shutdown confirmation</source>
        <translation>Konfirmasi matikan</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="50"/>
        <source>Shutdown now</source>
        <translation>Matikan sekarang</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="109"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation>qBittorrent akan keluar sekarang kecuali Anda batalkan dalam %1 detik berikutnya.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="112"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation>Komputer akan dimatikan sekarang kecuali Anda batalkan dalam %1 detik berikutnya.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="115"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation>Komputer akan masuk ke mode tidur sekarang kecuali Anda batalkan dalam %1 detik berikutnya.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="118"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation>Komputer akan masuk ke mode hibernasi sekarang kecuali Anda batalkan dalam %1 detik berikutnya.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="78"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="47"/>
        <source>Total Upload</source>
        <translation>Total Unggah</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="48"/>
        <source>Total Download</source>
        <translation>Total Unduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Payload Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Payload Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Overhead Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Overhead Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>DHT Upload</source>
        <translation>Unggahan DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>DHT Download</source>
        <translation>Unduhan DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>Tracker Upload</source>
        <translation>Unggahan Pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>Tracker Download</source>
        <translation>Unduhan Pelacak</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Periode:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 Menit</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 Menit</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 Menit</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 Jam</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="103"/>
        <source>Select Graphs</source>
        <translation>Pilih Grafik</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="79"/>
        <source>Total Upload</source>
        <translation>Total Unggah</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Download</source>
        <translation>Total Unduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Payload Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Overhead Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>DHT Upload</source>
        <translation>Unggahan DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Download</source>
        <translation>Unduhan DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Tracker Upload</source>
        <translation>Unggahan Pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Download</source>
        <translation>Unduhan Pelacak</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Statistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Statistik pengguna:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Total koneksi rekanan:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Rasio global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Unduhan sepanjang waktu:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Unggahan sepanjang waktu:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Total terbuang (sesi ini):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Statistik tembolok</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache Hits:</source>
        <translation>Mengena tembolok terbaca:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Total ukuran bufer:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Statistik performa</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Pekerjaan I/O yang diantrekan:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Lewahbeban penulisan tembolok:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue (ms):</source>
        <translation>Rata-rata waktu dalam antrean (ms):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Lewahbeban pembacaan tembolok:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Total ukuran yang diantrekan:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="243"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>Connection status:</source>
        <translation>Status koneksi:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Tidak ada koneksi langsung. Ini mungkin menunjukkan masalah konfigurasi jaringan.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="73"/>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 jalinan</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="141"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>qBittorrent perlu dimulai ulang</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="151"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent telah dimutakhirkan dan perlu dimulai ulang agar perubahan menjadi efektif.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Connection Status:</source>
        <translation>Status Koneksi:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Luring. Ini biasanya berarti bahwa qBittorent gagal mendengarkan port yang dipilih untuk koneksi masuk.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Online</source>
        <translation>Daring</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="203"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Klik untuk beralih ke batas kecepatan alternatif</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="199"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Klik untuk beralih ke batas kecepatan reguler</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="212"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Ubah manual mode batas laju. Penjadwalan dinonaktifkan.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="219"/>
        <source>Global Download Speed Limit</source>
        <translation>Batas Kecepatan Unduh Global</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Batas Kecepatan Unggah Global</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="117"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Semua (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="120"/>
        <source>Downloading (0)</source>
        <translation>Mengunduh (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="123"/>
        <source>Seeding (0)</source>
        <translation>Membibit (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="126"/>
        <source>Completed (0)</source>
        <translation>Komplet (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="129"/>
        <source>Resumed (0)</source>
        <translation>Dilanjutkan (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="132"/>
        <source>Paused (0)</source>
        <translation>Ditangguhkan (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="135"/>
        <source>Active (0)</source>
        <translation>Aktif (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="138"/>
        <source>Inactive (0)</source>
        <translation>Tidak aktif (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="141"/>
        <source>Errored (0)</source>
        <translation>Galat (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>All (%1)</source>
        <translation>Semua (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="159"/>
        <source>Downloading (%1)</source>
        <translation>Mengunduh (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="160"/>
        <source>Seeding (%1)</source>
        <translation>Membibit (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Completed (%1)</source>
        <translation>Komplet (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="162"/>
        <source>Paused (%1)</source>
        <translation>Ditangguhkan (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="163"/>
        <source>Resumed (%1)</source>
        <translation>Dilanjutkan (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="164"/>
        <source>Active (%1)</source>
        <translation>Aktif (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>Inactive (%1)</source>
        <translation>Tidak aktif (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Errored (%1)</source>
        <translation>Galat (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="56"/>
        <source>Name</source>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="56"/>
        <source>Size</source>
        <translation>Ukuran</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="57"/>
        <source>Progress</source>
        <translation>Kemajuan</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="57"/>
        <source>Priority</source>
        <translation>Prioritas</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="78"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Pilih folder untuk ditambahkan ke torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="92"/>
        <source>Select a file to add to the torrent</source>
        <translation>Pilih berkas untuk ditambahkan ke torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>No input path set</source>
        <translation>Tidak ada jalur masukan yang ditetapkan</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>Please type an input path first</source>
        <translation>Mohon ketik jalur masukan terlebih dahulu</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Select destination torrent file</source>
        <translation>Pilih tujuan berkas torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Berkas Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully: %1</source>
        <comment>%1 is the path of the torrent</comment>
        <translation>Torrent berhasil dibuat: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Pembuatan torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>Pembuatan torrent tidak berhasil, alasan: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>Berkas torrent yang dibuat tidak valid. Torrent tidak akan ditambahkan ke daftar unduh.</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Impor Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Penuntun ini akan membantu Anda berbagi melalui qBittorrent sebuah torrent yang telah diunduh.</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Berkas torrent untuk diimpor:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Lokasi konten:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Lewati tahapan pemeriksaan data dan mulai membibit sesegera mungkin</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Impor</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent file to import</source>
        <translation>Berkas torrent untuk diimpor</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent files</source>
        <translation>Berkas torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="89"/>
        <source>&apos;%1&apos; Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>&apos;%1&apos; Berkas</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="91"/>
        <source>Please provide the location of &apos;%1&apos;</source>
        <comment>%1 is a file name</comment>
        <translation>Mohon berikan lokasi dari &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="124"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Mohon arahkan ke lokasi torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>Invalid torrent file</source>
        <translation>Berkas torrent tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>This is not a valid torrent file.</source>
        <translation>Ini bukan berkas torrent yang valid.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Ukuran</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Selesai</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Bibit</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Rekanan</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Kecepatan Unduh</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Kecepatan Unggah</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Rasio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>ETA</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Ditambahkan Pada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Komplet Pada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Tracker</source>
        <translation>Pelacak</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Batas Unduh</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Batas Unggah</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Terunduh</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Diunggah</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Sesi Unduh</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Sesi Unggah</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Sisa</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Lama Aktif</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Jalur simpan</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Komplet</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Batas Rasio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Komplet Terlihat Terakhir</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Aktivitas Terakhir</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Total Ukuran</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="428"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Semua (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="431"/>
        <source>Trackerless (0)</source>
        <translation>Nirpelacak (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="434"/>
        <source>Error (0)</source>
        <translation>Galat (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="437"/>
        <source>Warning (0)</source>
        <translation>Peringatan (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="478"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="535"/>
        <source>Trackerless (%1)</source>
        <translation>Nirpelacak (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="484"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="530"/>
        <source>%1 (%2)</source>
        <comment>openbittorrent.com (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="560"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="592"/>
        <source>Error (%1)</source>
        <translation>Galat (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="573"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="607"/>
        <source>Warning (%1)</source>
        <translation>Peringatan (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="635"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;. Trying to download favicon in PNG format.</source>
        <translation>Tidak bisa mengawakode favicon untuk URL &apos;%1&apos;. Mencoba mengunduh favicon dalam format PNG.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="640"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;.</source>
        <translation>Tidak bisa mengawakode favicon untuk URL &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="654"/>
        <source>Couldn&apos;t download favicon for URL &apos;%1&apos;. Reason: %2</source>
        <translation>Tidak bisa mengunduh favicon untuk URL &apos;%1&apos;. Alasan: %2</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="663"/>
        <source>Resume torrents</source>
        <translation>Lanjutkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="664"/>
        <source>Pause torrents</source>
        <translation>Tangguhkan torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="665"/>
        <source>Delete torrents</source>
        <translation>Hapus torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="699"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="713"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Semua (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="69"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="70"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="71"/>
        <source>Peers</source>
        <translation>Rekanan</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="72"/>
        <source>Message</source>
        <translation>Pesan</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="217"/>
        <location filename="../gui/properties/trackerlist.cpp" line="286"/>
        <source>Working</source>
        <translation>Bekerja</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="218"/>
        <source>Disabled</source>
        <translation>Nonaktif</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="239"/>
        <source>This torrent is private</source>
        <translation>Torrent ini privat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="290"/>
        <source>Updating...</source>
        <translation>Memperbarui...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="294"/>
        <source>Not working</source>
        <translation>Tidak bekerja</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="298"/>
        <source>Not contacted yet</source>
        <translation>Belum dihubungi</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker URL:</source>
        <translation>URL pelacak:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker editing</source>
        <translation>Penyuntingan pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>Tracker editing failed</source>
        <translation>Penyuntingan pelacak gagal</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>URL pelacak yang dimasukkan tidak valid.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>The tracker URL already exists.</source>
        <translation>URL pelacak sudah ada.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="448"/>
        <source>Add a new tracker...</source>
        <translation>Tambah pelacak baru...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="454"/>
        <source>Copy tracker URL</source>
        <translation>Salin URL pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="455"/>
        <source>Edit selected tracker URL</source>
        <translation>Sunting URL pelacak yang dipilih</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="460"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Paksa umumkan ulang ke pelacak yang dipilih</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="462"/>
        <source>Force reannounce to all trackers</source>
        <translation>Paksa umumkan ulang ke semua pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="453"/>
        <source>Remove tracker</source>
        <translation>Buang pelacak</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Dialog penambahan pelacak</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Daftar pelacak untuk ditambahkan (satu per baris):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Daftar URL yang kompatibel dengan µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>I/O Error</source>
        <translation>Galat I/O</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Galat ketika mencoba membuka berkas yang diunduh.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No change</source>
        <translation>Tidak berubah</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No additional trackers were found.</source>
        <translation>Tidak ada pelacak tambahan yang ditemukan.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>Download error</source>
        <translation>Galat unduh</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Daftar pelacak tidak bisa diunduh, alasan: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="97"/>
        <source>Downloading</source>
        <translation>Mengunduh</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="103"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Mengunduh metadata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="109"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Mengalokasikan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="133"/>
        <source>Paused</source>
        <translation>Ditangguhkan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="120"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Diantrekan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="113"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Membibit</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="100"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Terhenti</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="106"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Mengunduh</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="116"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Membibit</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="124"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Memeriksa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>Diantrekan untuk diperiksa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="130"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Memeriksa data kelanjutan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="136"/>
        <source>Completed</source>
        <translation>Komplet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="139"/>
        <source>Missing Files</source>
        <translation>Berkas Hilang</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="142"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="172"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (dibibit selama %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 yang lalu</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="792"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="800"/>
        <source>Labels</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="808"/>
        <source>Trackers</source>
        <translation>Pelacak</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="511"/>
        <source>Column visibility</source>
        <translation>Keterlihatan kolom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="763"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="252"/>
        <source>Choose save path</source>
        <translation>Pilih jalur penyimpanan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="439"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Pembatasan Kecepatan Unduh Torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="468"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Pembatasan Kecepatan Unggah Torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Recheck confirmation</source>
        <translation>Komfirmasi pemeriksaan ulang</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Apakah Anda yakin ingin memeriksa ulang torrent yang dipilih?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>New Label</source>
        <translation>Label Baru</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Invalid label name</source>
        <translation>Nama label tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Mohon tidak menggunakan karakter spesial apapun di nama label.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>Rename</source>
        <translation>Ubah nama</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>New name:</source>
        <translation>Nama baru:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="629"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Lanjutkan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="633"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Paksa Lanjutkan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="631"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Tangguhkan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="635"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Hapus</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="637"/>
        <source>Preview file...</source>
        <translation>Pratinjau berkas...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="639"/>
        <source>Limit share ratio...</source>
        <translation>Batasi rasio berbagi...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="641"/>
        <source>Limit upload rate...</source>
        <translation>Batasi rasio unggah...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="643"/>
        <source>Limit download rate...</source>
        <translation>Batasi laju unduh...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="645"/>
        <source>Open destination folder</source>
        <translation>Buka folder tujuan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="647"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Pindahkan ke atas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="649"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Pindahkan ke bawah</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="651"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Pindahkan ke puncak</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="653"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Pindahkan ke dasar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="655"/>
        <source>Set location...</source>
        <translation>Tetapkan lokasi...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="661"/>
        <source>Copy name</source>
        <translation>Salin nama</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="813"/>
        <source>Priority</source>
        <translation>Prioritas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="657"/>
        <source>Force recheck</source>
        <translation>Paksa periksa ulang</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="659"/>
        <source>Copy magnet link</source>
        <translation>Salin tautan magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="663"/>
        <source>Super seeding mode</source>
        <translation>Mode membibit super</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="666"/>
        <source>Rename...</source>
        <translation>Ubah nama...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="668"/>
        <source>Download in sequential order</source>
        <translation>Unduh berurutan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="671"/>
        <source>Download first and last piece first</source>
        <translation>Unduh bagian pertama dan akhir terlebih dahulu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Baru...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="765"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Setel ulang</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Pembatasan Rasio Unggah/Unduh Torrent</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Gunakan batas rasio global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Tetapkan tanpa batas rasio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Tetapkan batas rasio ke</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="84"/>
        <source>The Web UI is listening on port %1</source>
        <translation>Web UI sedang mendengarkan port %1</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI Error - Unable to bind Web UI to port %1</source>
        <translation>Galat Web UI - Tidak bisa mengaitkan Web UI ke port %1</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="55"/>
        <source>An advanced BitTorrent client programmed in &lt;nobr&gt;C++&lt;/nobr&gt;, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Klien BitTorrent tingkat lanjut yang diprogram menggunakan &lt;nobr&gt;C++&lt;/nobr&gt;, berbasis toolkit Qt dan libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="57"/>
        <source>Copyright %1 2006-2015 The qBittorrent project</source>
        <translation>Hak Cipta %1 2006-2015 Proyek qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="59"/>
        <source>Home Page: </source>
        <translation>Halaman Beranda:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="61"/>
        <source>Bug Tracker: </source>
        <translation>Pelacak Kutu:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="63"/>
        <source>Forum: </source>
        <translation>Forum: </translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="66"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent di Freenode</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Tambah Rekanan</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one per line):</source>
        <translation>Daftar rekanan untuk ditambahkan (satu per baris):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Otentikasi pelacak</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Pelacak:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Masuk</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Nama pengguna:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Sandi:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="154"/>
        <source>Log in</source>
        <translation>Masuk</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Konfirmasi penghapusan - qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Ingat pilihan</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Juga hapus berkas pada diska</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="308"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Perkakas Pembuatan Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Pembuatan berkas torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="60"/>
        <source>Add file</source>
        <translation>Tambah berkas</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="67"/>
        <source>Add folder</source>
        <translation>Tambah folder</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Berkas atau folder untuk ditambahkan ke torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>URL pelacak:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>Url bibit web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="98"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Anda dapat memisahkan tingkatan / pengelompokan pelacak dengan sebuah baris kosong.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Ukuran bagian:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="165"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="170"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="175"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="180"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="185"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="190"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="195"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="200"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="205"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="210"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="215"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="223"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="248"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privat (tidak akan disebarluaskan di jaringan DHT jika diaktifkan)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="255"/>
        <source>Start seeding after creation</source>
        <translation>Mulai bibit setelah dibuat</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Abaikan batas rasio berbagi untuk torrent ini</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="301"/>
        <source>Create and save...</source>
        <translation>Buat dan simpan...</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Progress:</source>
        <translation>Kemajuan:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Tambah tautan torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="58"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Satu per baris (Tautan HTTP, Magnet dan info hash didukung)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="80"/>
        <source>Download</source>
        <translation>Unduh</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="87"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Unduh dari url</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>No URL entered</source>
        <translation>Tidak ada URL dimasukkan</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>Please type at least one URL.</source>
        <translation>Mohon ketik paling tidak satu URL.</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Pengaya pencarian</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Mesin pencari terpasang:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Version</source>
        <translation>Versi</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="65"/>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Enabled</source>
        <translation>Diaktifkan</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="83"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Anda bisa mendapatkan mesin pencari baru di sini: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="98"/>
        <source>Install a new one</source>
        <translation>Pasang satu yang baru</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="105"/>
        <source>Check for updates</source>
        <translation>Periksa pemutakhiran</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="112"/>
        <source>Close</source>
        <translation>Tutup</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="129"/>
        <source>Uninstall</source>
        <translation>Bongkar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="203"/>
        <source>Uninstall warning</source>
        <translation>Peringatan pembongkaran</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="205"/>
        <source>Uninstall success</source>
        <translation>Berhasil dibongkar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="264"/>
        <source>Invalid plugin</source>
        <translation>Plugin tidak valid</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="264"/>
        <source>The search engine plugin is invalid, please contact the author.</source>
        <translation>Plugin mesin pencari tidak valid, silahkan hubungi pengembang.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="270"/>
        <source>A more recent version of &apos;%1&apos; search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Versi yang lebih baru dari pengaya mesin pencari &apos;%1&apos; telah dipasang.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="295"/>
        <source>&apos;%1&apos; search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pengaya mesin pencarian &apos;%1&apos; tidak bisa dimutakhirkan, tetap pada versi lama.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <source>&apos;%1&apos; search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pengaya mesin pencarian &apos;%1&apos; tidak bisa dipasang.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="310"/>
        <source>&apos;%1&apos; search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pengaya mesin pencarian &apos;%1&apos; telah berhasil dimutakhirkan.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="313"/>
        <source>&apos;%1&apos; search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Pengaya mesin pencarian &apos;%1&apos; telah berhasil dipasang.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="381"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Tautan sepertinya tidak mengarah ke pengaya mesin pencarian.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="396"/>
        <source>Select search plugins</source>
        <translation>Pilih pengaya pencarian</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="517"/>
        <source>Sorry, &apos;%1&apos; search plugin installation failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Maaf, pemasangan pengaya pencarian &apos;%1&apos; gagal.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="270"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="295"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="310"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="313"/>
        <source>Search plugin install</source>
        <translation>Pemasangan pengaya pencarian</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="146"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="217"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="333"/>
        <source>Yes</source>
        <translation>Ya</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="149"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="183"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="220"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="336"/>
        <source>No</source>
        <translation>Tidak</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="397"/>
        <source>qBittorrent search plugin</source>
        <translation>Pengaya pencarian qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="448"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="489"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="510"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="517"/>
        <source>Search plugin update</source>
        <translation>Pemutakhiran pengaya pencarian</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="489"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="510"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Maaf, server pemutakhiran sementara tidak tersedia.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="448"/>
        <source>All your plugins are already up to date.</source>
        <translation>Semua pengaya Anda telah dimutakhirkan.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="205"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Semua pengaya yang dipilih telah berhasil dibuang.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="203"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Beberapa pengaya tidak bisa dibuang karena mereka disertakan qBittorrent secara bawaan. Hanya yang Anda tambahkan sendiri yang bisa Anda buang.
Pengaya tersebut dinonfungsikan.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="381"/>
        <source>Invalid link</source>
        <translation>Tautan tidak valid</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="373"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="382"/>
        <source>New search engine plugin URL</source>
        <translation>URL pengaya mesin pencarian baru</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="374"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="383"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Info tumbukan</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../core/utils/fs.cpp" line="444"/>
        <location filename="../core/utils/fs.cpp" line="451"/>
        <location filename="../core/utils/fs.cpp" line="461"/>
        <location filename="../core/utils/fs.cpp" line="494"/>
        <location filename="../core/utils/fs.cpp" line="506"/>
        <source>Downloads</source>
        <translation>Unduhan</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../core/utils/misc.cpp" line="82"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="83"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="84"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="85"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="86"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="283"/>
        <source>Python not detected</source>
        <translation>Python tidak terdeteksi</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="311"/>
        <source>Python version: %1</source>
        <translation>Versi Python: %1</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="338"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="426"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1j %2m</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="430"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1h %2j</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="326"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Tidak diketahui</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="206"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent akan mematikan komputer sekarang karena semua unduhan telah komplet.</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="419"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1m</translation>
    </message>
    <message>
        <location filename="../core/utils/misc.cpp" line="422"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="388"/>
        <source>Working</source>
        <translation>Bekerja</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="386"/>
        <source>Updating...</source>
        <translation>Memperbarui...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="390"/>
        <source>Not working</source>
        <translation>Tidak bekerja</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="384"/>
        <source>Not contacted yet</source>
        <translation>Belum dihubungi</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../gui/options_imp.cpp" line="1249"/>
        <location filename="../gui/options_imp.cpp" line="1251"/>
        <source>Choose export directory</source>
        <translation>Pilih direktori ekspor</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1289"/>
        <location filename="../gui/options_imp.cpp" line="1291"/>
        <location filename="../gui/options_imp.cpp" line="1302"/>
        <location filename="../gui/options_imp.cpp" line="1304"/>
        <source>Choose a save directory</source>
        <translation>Pilih direktori simpan</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1202"/>
        <source>Add directory to scan</source>
        <translation>Tambah direktori untuk dipindai</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="185"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parameter yang didukung (sensitif besar kecil huruf):</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="186"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nama torrent</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="187"/>
        <source>%L: Label</source>
        <translation>%L: Label</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="188"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Jalur konten (sama dengan jalur root untuk torrent multi-berkas)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="189"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Jalur root (jalur subdirektori torrent pertama)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="190"/>
        <source>%D: Save path</source>
        <translation>%D: Jalur simpan</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="191"/>
        <source>%C: Number of files</source>
        <translation>%C: Jumlah berkas</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="192"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Ukuran torrent (bita)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="193"/>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker saat ini</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="194"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1209"/>
        <source>Folder is already being watched.</source>
        <translation>Folder telah dimonitor.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1212"/>
        <source>Folder does not exist.</source>
        <translation>Folder tidak ada.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1215"/>
        <source>Folder is not readable.</source>
        <translation>Folder tidak bisa dibaca.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1225"/>
        <source>Failure</source>
        <translation>Kegagalan</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1225"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Gagal untuk menambah Folder Pindaian  &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1275"/>
        <location filename="../gui/options_imp.cpp" line="1277"/>
        <source>Filters</source>
        <translation>Penyaring</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1275"/>
        <location filename="../gui/options_imp.cpp" line="1277"/>
        <source>Choose an IP filter file</source>
        <translation>Pilih berkas penyaring IP</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1344"/>
        <source>SSL Certificate</source>
        <translation>Sertifikat SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1356"/>
        <source>SSL Key</source>
        <translation>Kunci SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1389"/>
        <source>Parsing error</source>
        <translation>Galat penguraian</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1389"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Gagal mengurai penyaring IP yang diberikan</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1391"/>
        <source>Successfully refreshed</source>
        <translation>Berhasil disegarkan</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1391"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Berhasil mengurai penyaring IP yang diberikan: %1 aturan diterapkan.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1479"/>
        <source>Invalid key</source>
        <translation>Kunci tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1479"/>
        <source>This is not a valid SSL key.</source>
        <translation>Ini bukan kunci SSL yang valid.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1495"/>
        <source>Invalid certificate</source>
        <translation>Sertifikat tidak valid</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1495"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Ini bukan Sertifikat SSL yang valid.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1505"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Waktu mulai dan berakhir tidak boleh sama.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1508"/>
        <source>Time Error</source>
        <translation>Galat Waktu</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Sumber pengaya</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Sumber pengaya pencarian:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Berkas lokal</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Tautan web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Pemilihan pratinjau</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="26"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Berkas ini mendukung pratinjau, mohon pilih salah satunya:</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="61"/>
        <source>Preview</source>
        <translation>Pratinjau</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="68"/>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="28"/>
        <source>Search</source>
        <translation>Cari</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="51"/>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="75"/>
        <source>Stopped</source>
        <translation>Dihentikan</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="107"/>
        <source>Download</source>
        <translation>Unduh</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="117"/>
        <source>Go to description page</source>
        <translation>Pergi ke halaman deskripsi</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="127"/>
        <source>Copy description page URL</source>
        <translation>Salin URL halaman deskripsi</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="147"/>
        <source>Search engines...</source>
        <translation>Mesin pencari...</translation>
    </message>
</context>
</TS>
