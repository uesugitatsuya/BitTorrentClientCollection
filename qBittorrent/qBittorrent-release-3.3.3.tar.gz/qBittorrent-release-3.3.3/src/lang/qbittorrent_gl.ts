<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="gl">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Sobre qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="83"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="216"/>
        <location filename="../gui/about.ui" line="293"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="240"/>
        <location filename="../gui/about.ui" line="281"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="228"/>
        <location filename="../gui/about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>Correo-e:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="262"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Mantedor actual</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="354"/>
        <source>Original author</source>
        <translation>Autor orixinal</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="412"/>
        <source>Libraries</source>
        <translation>Bibliotecas</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="424"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Esta versión de qBittorrent compilouse contra as seguintes bibliotecas:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="184"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="382"/>
        <source>Translation</source>
        <translation>Tradución</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="399"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Grazas a</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Gardar como</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="53"/>
        <source>Browse...</source>
        <translation>Explorar...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="62"/>
        <source>Set as default save path</source>
        <translation>Estabelecer como ruta predefinida para gardar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="72"/>
        <source>Never show again</source>
        <translation>Non mostrar de novo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Torrent settings</source>
        <translation>Opcións torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="95"/>
        <source>Start torrent</source>
        <translation>Iniciar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="126"/>
        <source>Skip hash check</source>
        <translation>Saltar a comprobación hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="133"/>
        <source>Set as default label</source>
        <translation>Estabelecer como etiqueta predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="143"/>
        <source>Torrent Information</source>
        <translation>Información do torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="151"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="191"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="205"/>
        <source>Info Hash:</source>
        <translation>Info Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="296"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="301"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="306"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="311"/>
        <source>Do not download</source>
        <translation>Non descargar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="176"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="650"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="176"/>
        <source>The torrent file does not exist.</source>
        <translation>O ficheiro torrent non existe.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="184"/>
        <source>Invalid torrent</source>
        <translation>Torrent incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="184"/>
        <source>Failed to load the torrent: %1</source>
        <translation>Produciuse un fallo ao cargar o torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="196"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="224"/>
        <source>Already in download list</source>
        <translation>Xa está na lista de descargas.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="344"/>
        <source>Free disk space: %1</source>
        <translation>Espazo libre no disco: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="676"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="677"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="685"/>
        <source>Not available</source>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <source>Invalid magnet link</source>
        <translation>Ligazón magnet incorrecta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="196"/>
        <source>Torrent is already in download list. Trackers were merged.</source>
        <translation>O torrent xa está na lista de descargas. Mesturáronse os localizadores.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="199"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="227"/>
        <source>Cannot add torrent</source>
        <translation>Non é posíbel engadir o torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="199"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>Non é posíbel engadir este torrent. Quizais xa está noutro estado de engadir.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="213"/>
        <source>This magnet link was not recognized</source>
        <translation>Non se recoñeceu esta ligazón magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="224"/>
        <source>Magnet link is already in download list. Trackers were merged.</source>
        <translation>A ligazón magnet xa está na lista de descargas. Mesturáronse os localizadores.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="227"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>Non foi posíbel engadir este torrent. Quizais xa se estea engadindo.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="236"/>
        <source>Magnet link</source>
        <translation>Ligazón magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="243"/>
        <source>Retrieving metadata...</source>
        <translation>Recuperando os metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="342"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Non dispoñíbel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="373"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="381"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="383"/>
        <source>Choose save path</source>
        <translation>Seleccionar a ruta onde gardar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="432"/>
        <source>Rename the file</source>
        <translation>Cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="433"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="437"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="462"/>
        <source>The file could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="438"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nome de ficheiro contén caracteres prohibidos, escolla un nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="463"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="496"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome de ficheiro xa existe neste cartafol. Use un nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="495"/>
        <source>The folder could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do cartafol</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="552"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="556"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="651"/>
        <source>Invalid metadata</source>
        <translation>Metadatos incorrectos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="658"/>
        <source>Parsing metadata...</source>
        <translation>Analizando os metadatos...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="662"/>
        <source>Metadata retrieval complete</source>
        <translation>Completouse a recuperación dos metadatos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="722"/>
        <source>Download Error</source>
        <translation>Erro de descarga</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.h" line="219"/>
        <source>Disk write cache size</source>
        <translation>Tamaño da caché de escritura no disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="201"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="239"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Portos de saída (mín.) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="244"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Portos de saída (máx.) [0: Desactivado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="247"/>
        <source>Recheck torrents on completion</source>
        <translation>Volver comprobar os torrents ao rematar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="253"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de actualización da lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="252"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Setting</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="199"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="224"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="225"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de caducidade da caché do disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="228"/>
        <source>Enable OS cache</source>
        <translation>Activar a caché do SO</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="233"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="256"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Mostrar os países dos pares (Geoip)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="259"/>
        <source>Resolve peer host names</source>
        <translation>Mostrar os servidores dos pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="267"/>
        <source>Strict super seeding</source>
        <translation>Super sementeira estrita</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="287"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interface de rede (necesita reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="290"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Escoitar no enderezo IPv6 (precisa reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="315"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmar nova comprobación do torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="318"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercambio de localizadores con outros pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="321"/>
        <source>Always announce to all trackers</source>
        <translation>Anunciar sempre a todos os localizadores</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="269"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Calquera interface</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="234"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Gardar o intervalo de datos para continuar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="264"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Número máximo de conexións semi-abertas [0: Ilimitado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="293"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Enderezo IP que enviar aos localizadores (necesita reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="296"/>
        <source>Display program on-screen notifications</source>
        <translation>Mostrar as notificacións na pantalla</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="299"/>
        <source>Enable embedded tracker</source>
        <translation>Activar o localizador integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="304"/>
        <source>Embedded tracker port</source>
        <translation>Porto do localizador integrado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="307"/>
        <source>Check for software updates</source>
        <translation>Comprobar se hai actualizacións </translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="311"/>
        <source>Use system icon theme</source>
        <translation>Usar o tema das iconas do sistema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="105"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>Iniciouse o qBittorrent %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="262"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="263"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Para controlar o qBittorrent acceda á interface web en http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="264"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>O usuario do administrador da interface web é: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="267"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>O contrasinal do administrador da interface web é aínda o predefinido: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="268"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Isto é un risco de seguranza, debería cambiar o seu contrasinal nas preferencias do programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="442"/>
        <source>Saving torrent progress...</source>
        <translation>Gardando o progreso do torrent...</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="208"/>
        <source>Save to:</source>
        <translation>Gardar en:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Xestor de descargas RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable Automated RSS Downloader</source>
        <translation>Activar o xestor de descargas RSS automático</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="48"/>
        <source>Download Rules</source>
        <translation>Regras de descarga</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="88"/>
        <source>Rule Definition</source>
        <translation>Definición da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="94"/>
        <source>Use Regular Expressions</source>
        <translation>Usar expresións regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="103"/>
        <source>Must Contain:</source>
        <translation>Debe conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="110"/>
        <source>Must Not Contain:</source>
        <translation>Non debe conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="117"/>
        <source>Episode Filter:</source>
        <translation>Filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="180"/>
        <source>Assign Label:</source>
        <translation>Asignar etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="196"/>
        <source>Save to a Different Directory</source>
        <translation>Gardar nun cartafol diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="236"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorar resultados seguintes para (0 para desactivar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="246"/>
        <source> days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="276"/>
        <source>Add Paused:</source>
        <translation>Engadir pausados:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="284"/>
        <source>Use global settings</source>
        <translation>Usar os axustes globais</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="289"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="294"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="315"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar a regra ás fontes:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="337"/>
        <source>Matching RSS Articles</source>
        <translation>Artigos RSS coincidentes</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="369"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Resultados co filtro de episodios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source>Example: </source>
        <translation>Exemplo:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>son os episodios 2, 5 e 8 até o 15, e do 30 en adiante da primeira tempada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Episode filter rules: </source>
        <translation>Regras do filtro de episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>O número da tempada non pode ser cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Episode number is a mandatory non-zero value</source>
        <translation>O número de episodio non pode ser cero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source>Filter must end with semicolon</source>
        <translation>O filtro debe rematar con punto e coma</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Acéptanse tres tipos de intervalo para os episodios:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Número simple: &lt;b&gt;1x25;&lt;/b&gt; é o episodio 25 da primeira tempada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="85"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Intervalo normal: &lt;b&gt;1x25-40;&lt;/b&gt; son os episodios 25 ao 40 da primeira tempada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one</source>
        <translation>Intervalo infinito: &lt;b&gt;1x25-;&lt;/b&gt; son os episodios do 25 en diante da primeira tempada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="267"/>
        <source>Last Match: %1 days ago</source>
        <translation>Último resultado: hai %1 días</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="269"/>
        <source>Last Match: Unknown</source>
        <translation>Último resultado: descoñecido</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <source>New rule name</source>
        <translation>Nome da regra nova</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="362"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Escriba o nome da regra de descarga nova.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="366"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="484"/>
        <source>Rule name conflict</source>
        <translation>Conflito co nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="366"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="484"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Xa existe unha regra con este nome. Escolla un diferente.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="384"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Está seguro que desexa eliminar a regra de descarga chamada %1?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Está seguro que desexa eliminar as regras de descarga seleccionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="387"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmación de eliminación da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="403"/>
        <source>Destination directory</source>
        <translation>Cartafol de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="411"/>
        <source>Invalid action</source>
        <translation>A acción non é válida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="411"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>A lista está baleira, non hai nada que exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="415"/>
        <source>Where would you like to save the list?</source>
        <translation>Onde desexa gardar a lista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="415"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Lista de regras (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="420"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="420"/>
        <source>Failed to create the destination file</source>
        <translation>Produciuse un fallo ao crear o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="428"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Indique o ficheiro de regras de descarga RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="428"/>
        <source>Rules list</source>
        <translation>Lista de regras</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <source>Import Error</source>
        <translation>Erro de importación</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <source>Failed to import the selected rules file</source>
        <translation>Produciuse un fallo ao importar o ficheiro de regras seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="443"/>
        <source>Add new rule...</source>
        <translation>Engadir unha regra nova...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>Delete rule</source>
        <translation>Eliminar a regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="451"/>
        <source>Rename rule...</source>
        <translation>Cambiar o nome da regra...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="453"/>
        <source>Delete selected rules</source>
        <translation>Eliminar as regras seleccionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Rule renaming</source>
        <translation>Cambio do nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Please type the new rule name</source>
        <translation>Escriba o nome da regra nova</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="582"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Modo Regex: usa Perl como expresións regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="586"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Modo comodín: pode usar&lt;ul&gt;&lt;li&gt;? para substituír calquera caracter&lt;/li&gt;&lt;li&gt;* para substituír o cero ou máis dun caracter&lt;/li&gt;&lt;li&gt;Espazos en branco úsanse como operador AND&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="588"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Modo comodín: pode usar&lt;ul&gt;&lt;li&gt;? para substituír calquera caracter&lt;/li&gt;&lt;li&gt;* para substituír o cero ou máis dun caracter&lt;/li&gt;&lt;li&gt;| úsase como operador OR&lt;/li&gt;&lt;/ul&gt;</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="169"/>
        <source>Peer ID: </source>
        <translation>ID do par:</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="312"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>O axente do usuario HTTP é %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="339"/>
        <source>Anonymous mode [ON]</source>
        <translation>Modo anómino [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="341"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Modo anómino [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="532"/>
        <source>PeX support [ON]</source>
        <translation>Soporte PeX [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="534"/>
        <source>PeX support [OFF]</source>
        <translation>Soporte PeX [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="536"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>É necesario reiniciar para cambiar o soporte PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="541"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Soporte para busca de pares locais (LPD) [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="545"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Soporte para busca de pares locais (LPD) [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="558"/>
        <source>Encryption support [ON]</source>
        <translation>Soporte de cifrado [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="563"/>
        <source>Encryption support [FORCED]</source>
        <translation>Soporte de cifrado [FORZADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="568"/>
        <source>Encryption support [OFF]</source>
        <translation>Soporte de cifrado [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="646"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Localizador integrado [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="648"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Produciuse un fallo ao iniciar o localizador integrado!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="651"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Localizador integrado [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="689"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removing...</source>
        <translation>%1 alcanzou a taxa máxima estabelecida. Eliminando...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="695"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Pausing...</source>
        <translation>%1 alcanzou a taxa máxima estabelecida. Detendo...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>O estado da rede do sistema cambiou a %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>ONLINE</source>
        <translation>EN LIÑA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>OFFLINE</source>
        <translation>FÓRA DE LIÑA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1408"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>A configuración da rede de %1 cambiou, actualizando as vinculacións da sesión</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1692"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Non foi posíbel decodificar o ficheiro torrent %1.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1798"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Descarga recursiva do ficheiro %1 integrado no torrent %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2109"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Non foi posíbel gardar %1.torrent</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2214"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>porque o %1 está desactivado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2217"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>porque o %1 está desactivado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2235"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Fallou a busca da semente na URL: %1, mensaxe: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="808"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; eliminouse da lista de transferencias e do disco duro.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="810"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; eliminouse da lista de transferencias.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="973"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Descargando &apos;%1&apos;, espere...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1242"/>
        <source>DHT support [ON]</source>
        <translation>Compatibiliade DHT [ACTIVADA]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1247"/>
        <source>DHT support [OFF]. Reason: %1</source>
        <translation>Compatibilidade DHT [DESACTIVADA]. Razón: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1255"/>
        <source>DHT support [OFF]</source>
        <translation>Soporte DHT  [APAGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="161"/>
        <location filename="../base/bittorrent/session.cpp" line="1478"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent está tentando escoitar en todos os portos da interface: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1431"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>A interface indicada para a rede non é válida: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="165"/>
        <location filename="../base/bittorrent/session.cpp" line="1489"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent está tentando escoitar na interface %1 porto: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1455"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent non atopou un enderezo local %1 no que escoitar</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1482"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent fallou ao escoitar en cada porto da interface: %1. Razón: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1603"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Engadiuse o localizador «%1» ao torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1613"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Eliminouse o localizador «%1» do torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1628"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>A semente da URL «%1» engadiuse ao torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1634"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>A semente da URL «%1» eliminouse do torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1914"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Non é posíbel continuar o torrent «%1».</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1937"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analizouse correctamente o filtro IP indicado: aplicáronse %1 regras.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1943"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Erro: produciuse un fallo ao analizar o filtro IP indicado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2071"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Non foi posíbel engadir o torrent. Razón: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2092"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>Retomouse &apos;%1&apos; (continuación rápida)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2123"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>Engadiuse %1 á lista de descargas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2178"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Produciuse un erro de E/S, &apos;%1&apos; pausado. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2186"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: produciuse un fallo no mapeado dos portos, mensaxe: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2192"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: o mapeado dos portos foi correcto, mensaxe: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2202"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>debido ao filtro IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2205"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>debido ao filtro de portos.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2208"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>debido ás restricións do modo mixto i2P.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2211"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>porque ten un porto baixo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2249"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent escoita correctamente no porto da interface %1 porto: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2275"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation>qBittorrent fallou ao escoitar na interface %1 porto: %2/%3. Razón: %4.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2284"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externa: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1313"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Non foi posíbel mover o torrent: «%1». Razón: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1457"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>Os tamaños dos ficheiros non coinciden co torrent %1 , deténdoo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1463"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Os datos para a continuación rápida do torrent %1 foron rexeitados. Razón: %2, Comprobando de novo...</translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Xestión das cookies</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Chave</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.cpp" line="50"/>
        <source>Common keys for cookies are: &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>As chaves comúns para as cookies son &apos;%1&apos;, &apos;%2&apos;.
Debería obter esta información nas preferencias do navegador.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Está seguro que desexa eliminar «%1» da lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="50"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Está seguro que desexa eliminar estes %1 torrents da lista de transferencias?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>White: Missing pieces</source>
        <translation>Branco: faltan anacos</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Green: Partial pieces</source>
        <translation>Verde: anacos parciais</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Blue: Completed pieces</source>
        <translation>Azul: anacos completos</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="27"/>
        <source>General</source>
        <translation>Xeral</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueadas</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="101"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi bloqueado %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="103"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi bloqueado</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="46"/>
        <source>RSS feeds</source>
        <translation>Fontes RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="48"/>
        <source>Unread</source>
        <translation>Sen ler</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="65"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="159"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="267"/>
        <source>I/O Error: Could not open ip filter file in read mode.</source>
        <translation>Erro de E/S: Non foi posíbel abrir o ficheiro de filtros de ip en modo lectura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="278"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="290"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="311"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="320"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="330"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="340"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="360"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Erro de análise: o ficheiro de filtros non é un ficheiro Peer Guardian P2B correcto.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="101"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="131"/>
        <source>Unsupported database file size.</source>
        <translation>Tamaño do ficheiro da base de datos non aceptado</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Erro nos metadatos: non se atopou a entrada «%1».</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Erro nos metadatos: a entrada «%1» ten un tipo incorrecto.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="246"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versión da base de datos non aceptada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="253"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versión de IP non aceptada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Unsupported record size: %1</source>
        <translation>Tamaño de rexistro no aceptado: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="273"/>
        <source>Invalid database type: %1</source>
        <translation>Tipo de base de datos incorrecta: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de datos corrompida: non se atopou a sección dos datos.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Exit qBittorrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Descargar torrents desde unha URL ou ligazón Magnet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Only one link per line</source>
        <translation>Só unha ligazón por liña</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>O límite da velocidade global de envío debe ser superior a 0 ou non funcionará.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>O límite da velocidade global de descarga debe ser ser superior a 0 ou non funcionará.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>O límite alternativo da velocidade de envío debe ser superior a 0 ou non funcionará.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>O límite alternativo da velocidade de descarga debe ser superior a 0 ou non funcionará.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>As descargas activas máximas deben ser superiores a -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Os envíos activos máximos deben ser superiores a -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Os torrents activos máximos deben ser superiores a -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de conexións ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de conexións por torrent ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>O límite do número máximo de slots de envío por torrent ten que ser superior a 0 ou debe desactivalo.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Non foi posíbel gardar as preferencias do programa, probabelmente o qBittorrent estea inaccesíbel.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>O porto usado para as conexións entrantes debe estar entre 1 e 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>O porto usado para a interface web debe estar entre 1 e 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Non é posíbel iniciar sesión. Probabelmente o qBittorrent non está accesíbel.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Invalid Username or Password.</source>
        <translation>O usuario ou o contrasinal son incorrectos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Password</source>
        <translation>Contrasinal</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Upload Failed!</source>
        <translation>Fallou o envío.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Original authors</source>
        <translation>Autores orixinais</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Upload limit:</source>
        <translation>Límite do envío:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Download limit:</source>
        <translation>Límite da descarga:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Add</source>
        <translation>Engadir</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Upload Torrents</source>
        <translation>Enviar torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Seeding</source>
        <translation>Sementando</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="83"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="84"/>
        <source>Resumed</source>
        <translation>Continuados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Paused</source>
        <translation>Detido</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Active</source>
        <translation>Activos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Inactive</source>
        <translation>Inactivos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Save files to location:</source>
        <translation>Gardar os ficheiros na localización:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Type folder here</source>
        <translation>Escribir o cartafol aquí</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Run an external program on torrent completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Enable bandwidth management (uTP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="94"/>
        <source>Apply rate limit to uTP connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="95"/>
        <source>Alternative Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="96"/>
        <source>More information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="97"/>
        <source>Information about certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="98"/>
        <source>Save Files to</source>
        <translation type="unfinished">Gardar ficheiros en</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="99"/>
        <source>Watch Folder</source>
        <translation type="unfinished">Vixiar cartafol</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="100"/>
        <source>Default Folder</source>
        <translation type="unfinished">Cartafol predeterminado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="105"/>
        <source>from</source>
        <comment>from time1 to time2</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="106"/>
        <source>to</source>
        <comment>from time1 to time2</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="107"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation type="unfinished">Outra...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="108"/>
        <source>Every day</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished">Todos os días</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="109"/>
        <source>Week days</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="110"/>
        <source>Week ends</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="111"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="112"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="113"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="114"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="115"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="116"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="117"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other...</source>
        <translation type="obsolete">Outra...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="104"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Logout</source>
        <translation>Saír da sesión</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Upload local torrent</source>
        <translation>Enviar torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Está seguro que desexa eliminar os torrents seleccionados da lista de transferencias?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>O nome de usuario da interface web debe ter polo menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>O contrasinal da interface web debe ter polo menos 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Save</source>
        <translation>Gardar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>qBittorrent client is not reachable</source>
        <translation>O cliente qBittorrent non está accesíbel</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>The following parameters are supported:</source>
        <translation>Os seguintes parámetros son compatíbeis:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Torrent path</source>
        <translation>Ruta ao torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Torrent name</source>
        <translation>Nome do torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>O qBittorrent foi pechado.</translation>
    </message>
</context>
<context>
    <name>LabelFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Unlabeled (0)</source>
        <translation>Sen etiquetar (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="214"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="260"/>
        <source>All (%1)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="217"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="235"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="263"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="268"/>
        <source>Unlabeled (%1)</source>
        <translation>Sen etiquetar (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="239"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="276"/>
        <source>%1 (%2)</source>
        <comment>label_name (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="330"/>
        <source>Add label...</source>
        <translation>Engadir unha etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="334"/>
        <source>Remove label</source>
        <translation>Eliminar a etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="335"/>
        <source>Remove unused labels</source>
        <translation>Eliminar as etiquetas non usadas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="337"/>
        <source>Resume torrents</source>
        <translation>Continuar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="338"/>
        <source>Pause torrents</source>
        <translation>Pausar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="339"/>
        <source>Delete torrents</source>
        <translation>Eliminar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>New Label</source>
        <translation>Etiqueta nova</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Invalid label name</source>
        <translation>O nome da etiqueta non é correcto</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Non use ningún caracter especial no nome da etiqueta.</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../gui/lineedit/src/lineedit.cpp" line="37"/>
        <source>Clear the text</source>
        <translation>Borrar o texto</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="66"/>
        <source>&amp;Tools</source>
        <translation>Ferramen&amp;tas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="86"/>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="56"/>
        <source>&amp;Help</source>
        <translation>&amp;Axuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="70"/>
        <source>On Downloads &amp;Done</source>
        <translation>Ao rematar as &amp;descargas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="96"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="164"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcións...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>&amp;Resume</source>
        <translation>Continua&amp;r</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="197"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Creador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="202"/>
        <source>Set Upload Limit...</source>
        <translation>Estabelecer o límite de envío...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="207"/>
        <source>Set Download Limit...</source>
        <translation>Estabelecer o límite de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="217"/>
        <source>Set Global Download Limit...</source>
        <translation>Estabelecer o límite global de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="222"/>
        <source>Set Global Upload Limit...</source>
        <translation>Estabelecer o límite global de envío...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="227"/>
        <source>Minimum Priority</source>
        <translation>Prioridade mínima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="235"/>
        <source>Top Priority</source>
        <translation>Prioridade máxima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Decrease Priority</source>
        <translation>Disminuír a prioridade</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="251"/>
        <source>Increase Priority</source>
        <translation>Aumentar a prioridade</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="262"/>
        <location filename="../gui/mainwindow.ui" line="265"/>
        <source>Alternative Speed Limits</source>
        <translation>Límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="273"/>
        <source>&amp;Top Toolbar</source>
        <translation>Barra &amp;superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="276"/>
        <source>Display Top Toolbar</source>
        <translation>Mostrar a barra superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="284"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Velocidade na barra do título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="287"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar a velocidade de transferencia na barra do título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="295"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="303"/>
        <source>Search &amp;Engine</source>
        <translation>Motor de &amp;busca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="308"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Bl&amp;oquear o qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="319"/>
        <source>&amp;Import Existing Torrent...</source>
        <translation>&amp;Importar un torrent existente...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="322"/>
        <source>Import Torrent...</source>
        <translation>Importar un torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="327"/>
        <source>Do&amp;nate!</source>
        <translation>D&amp;oar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="335"/>
        <source>R&amp;esume All</source>
        <translation>Co&amp;ntinuar todo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="348"/>
        <source>&amp;Log</source>
        <translation>&amp;Rexistro</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="359"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Saír do qBittorr&amp;ent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="367"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="375"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="383"/>
        <source>S&amp;hutdown System</source>
        <translation>Pe&amp;char o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="391"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Desactivado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="406"/>
        <source>&amp;Statistics</source>
        <translation>E&amp;stadísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>Check for Updates</source>
        <translation>Buscar actualizacións</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="414"/>
        <source>Check for Program Updates</source>
        <translation>Buscar actualizacións do programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="179"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="184"/>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="340"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausar todo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="151"/>
        <source>&amp;Add Torrent File...</source>
        <translation>Eng&amp;adir un ficheiro torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="154"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="159"/>
        <source>E&amp;xit</source>
        <translation>&amp;Saír</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="192"/>
        <source>Open URL</source>
        <translation>Abrir a URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="212"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentación</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="311"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <location filename="../gui/mainwindow.cpp" line="1304"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1487"/>
        <source>Check for program updates</source>
        <translation>Buscar actualizacións do programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="189"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Engadir &amp;ligazón torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="330"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Se lle gusta o qBittorrent, por favor faga unha doazón!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="351"/>
        <location filename="../gui/mainwindow.cpp" line="1515"/>
        <source>Execution Log</source>
        <translation>Rexistro de execución</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="485"/>
        <source>Clear the password</source>
        <translation>Limpar o contrasinal</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="192"/>
        <source>Filter torrent list...</source>
        <translation>Filtrar a lista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="163"/>
        <source>&amp;Set Password</source>
        <translation>E&amp;stabelecer o contrasinal</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="165"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Limpar o contrasinal</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="210"/>
        <source>Transfers</source>
        <translation>Transferencias</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="350"/>
        <source>Torrent file association</source>
        <translation>Asociación cos ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="351"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent non é o aplicativo predefinido para abrir os ficheiros torrent nin as ligazóns Magnet
Desexa asociar o qBittorrent aos ficheiros torrent e ás ligazóns Magnet?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="382"/>
        <source>Icons Only</source>
        <translation>Só iconas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="384"/>
        <source>Text Only</source>
        <translation>Só texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="386"/>
        <source>Text Alongside Icons</source>
        <translation>Texto e iconas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="388"/>
        <source>Text Under Icons</source>
        <translation>Texto debaixo das iconas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="390"/>
        <source>Follow System Style</source>
        <translation>Seguir o estilo do sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="470"/>
        <location filename="../gui/mainwindow.cpp" line="497"/>
        <location filename="../gui/mainwindow.cpp" line="799"/>
        <source>UI lock password</source>
        <translation>Contrasinal de bloqueo da interface</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="470"/>
        <location filename="../gui/mainwindow.cpp" line="497"/>
        <location filename="../gui/mainwindow.cpp" line="799"/>
        <source>Please type the UI lock password:</source>
        <translation>Escriba un contrasinal para bloquear a interface:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="474"/>
        <source>The password should contain at least 3 characters</source>
        <translation>O contrasinal debe conter cando menos 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="479"/>
        <source>Password update</source>
        <translation>Actualizar o contrasinal</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="479"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>O contrasinal de bloqueo da interface actualizouse correctamente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="485"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Está seguro de limpar o contrasinal?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="537"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="548"/>
        <source>Transfers (%1)</source>
        <translation>Transferencias (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="639"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="639"/>
        <source>Failed to add torrent: %1</source>
        <translation>Produciuse un fallo ao engadir o torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <source>Download completion</source>
        <translation>FInalización da descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="651"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="712"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmación de descarga recursiva</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="713"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="714"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="715"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="735"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite global de velocidade de envío</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="751"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite global de velocidade de descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="901"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="902"/>
        <source>&amp;Yes</source>
        <translation>&amp;Si</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="903"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Sempre si</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1386"/>
        <source>Python found in %1</source>
        <translation>Atopouse Python en %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1401"/>
        <source>Old Python Interpreter</source>
        <translation>Intérprete antigo de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1471"/>
        <source>qBittorrent Update Available</source>
        <translation>Hai dipoñíbel unha actualización do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1472"/>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation>Hai dispoñíbel unha nova versión.
Desexa descargar %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1481"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Xa usa a última versión do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1411"/>
        <source>Undetermined Python version</source>
        <translation>Versión indeterminada de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>Finalizou a descarga de %1.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="651"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Produciuse un erro de E/S no torrent %1.
Razón: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="712"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>O torrent %1 contén ficheiros torrent, desexa continuar coa descarga?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="727"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Non foi posíbel descargar o ficheiro desde a URL: %1, razón: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1401"/>
        <source>Your Python version %1 is outdated. Please upgrade to latest version for search engines to work. Minimum requirement: 2.7.0/3.3.0.</source>
        <translation>A súa versión de Python %1 está desactualizada. Anove á última versión para que os motores de busca funcionen. Requerimento mínimo: 2.7.0/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1411"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>Non foi posíbel determinar a súa versión de Python (%1). Desactivouse o motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1422"/>
        <location filename="../gui/mainwindow.cpp" line="1434"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta o intérprete de Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1423"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Precísase Python para usar o motor de busca pero non parece que estea instalado.
Desexa instalalo agora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1434"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Precísase Python para usar o motor de busca pero non parece que estea instalado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1482"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Non hai actualizacións dispoñíbeis.
Xa usa a última versión.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1486"/>
        <source>&amp;Check for Updates</source>
        <translation>Buscar a&amp;ctualizacións</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1584"/>
        <source>Checking for Updates...</source>
        <translation>Buscando actualizacións...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1585"/>
        <source>Already checking for program updates in the background</source>
        <translation>Xa se están buscando actualizacións do programa en segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1600"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Atopouse Python en %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1653"/>
        <source>Download error</source>
        <translation>Erro de descarga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1653"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Non foi posíbel descargar a configuración de Python, razón:%1.
Instálea manualmente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="474"/>
        <location filename="../gui/mainwindow.cpp" line="813"/>
        <source>Invalid password</source>
        <translation>Contrasinal incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="515"/>
        <location filename="../gui/mainwindow.cpp" line="527"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="727"/>
        <source>URL download error</source>
        <translation>Erro na descarga desde a URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="813"/>
        <source>The password is invalid</source>
        <translation>O contrasinal é incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1199"/>
        <location filename="../gui/mainwindow.cpp" line="1206"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Vel. de descarga: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1202"/>
        <location filename="../gui/mainwindow.cpp" line="1208"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Vel. de envío: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1213"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1, E: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1304"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="898"/>
        <source>Exiting qBittorrent</source>
        <translation>Saíndo do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="899"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Estanse transferindo algúns ficheiros.
Está seguro que desexa saír do qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1040"/>
        <source>Open Torrent Files</source>
        <translation>Abrir os ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1041"/>
        <source>Torrent Files</source>
        <translation>Ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1076"/>
        <source>Options were saved successfully.</source>
        <translation>Os axustes gardáronse correctamente.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="197"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>O DNS dinámico actualizouse correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="202"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Erro de DNS dinámico: o servizo non está dispoñíbel temporalmente, intentarase de novo dentro de 30 minutos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="212"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Erro de DNS dinámico: o nome do servidor indicado non existe nesta conta específica.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="218"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Erro de DNS dinámico: nome do usuario/contrasinal incorrectos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="224"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinámico: o qBittorrent está na lista negra deste servizo, por favor informe deste erro en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="231"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinámico: o servizo devolveu %1 , por favor informe deste erro en http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="238"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Erro de DNS dinámico: o nome do usuario foi bloqueado por un abuso.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="259"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Erro de DNS dinámico: o nome do dominio indicado non é correcto.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="270"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Erro de DNS dinámico: o nome do dominio indicado é curto de máis.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="281"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Erro de DNS dinámico: o contrasinal indicado é curto de máis.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="104"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="117"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>O tamaño do ficheiro é %1. Supera o límite de descarga de %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="186"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redireccionamento inesperado a un URI magnet.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="431"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Cargouse a base de datos de GeoIP. TIpo: %1. Tempo de construción: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="452"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>Non foi posíbel cargar a base de datos de GeoIP. Razón: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Viet Nam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <location filename="../base/net/geoipmanager.cpp" line="397"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="143"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>United Arab Emirates</source>
        <translation>Emiratos Árabes Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>Afghanistan</source>
        <translation>Afganistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua e Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Albania</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Armenia</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Antarctica</source>
        <translation>Antártida</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Argentina</source>
        <translation>Arxentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>American Samoa</source>
        <translation>Samoa Americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Austria</source>
        <translation>Austria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Azerbaijan</source>
        <translation>Azerbaidjan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnia-Herzegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Belgium</source>
        <translation>Bélxica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Bulgaria</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei Darussalam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bouvet Island</source>
        <translation>Illa Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Belarus</source>
        <translation>Bielorrusia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Canada</source>
        <translation>Canadá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Illas Cocos (Keelings)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>República Democrática do Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Central African Republic</source>
        <translation>República Centro Africana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Switzerland</source>
        <translation>Suíza</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cook Islands</source>
        <translation>Illas Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Cameroon</source>
        <translation>Camerún</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Colombia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cape Verde</source>
        <translation>Cabo Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Christmas Island</source>
        <translation>Illa de Nadal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Cyprus</source>
        <translation>Chipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Czech Republic</source>
        <translation>República Checa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Germany</source>
        <translation>Alemaña</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Djibouti</source>
        <translation>Djibuti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Algeria</source>
        <translation>Alxeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Estonia</source>
        <translation>Estonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Egypt</source>
        <translation>Exipto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Western Sahara</source>
        <translation>Sahara Occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Spain</source>
        <translation>Estado Español</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Ethiopia</source>
        <translation>Etiopía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Finland</source>
        <translation>Finlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Fiji</source>
        <translation>Fixi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Illas Malvinas (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Faroe Islands</source>
        <translation>Illas Faroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>France</source>
        <translation>Francia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Gabon</source>
        <translation>Gabón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>United Kingdom</source>
        <translation>Reino Unido</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Georgia</source>
        <translation>Xeorxia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>French Guiana</source>
        <translation>Güiana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Gibraltar</source>
        <translation>Xibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Greenland</source>
        <translation>Groenlandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Ecuatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Greece</source>
        <translation>Grecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Illas Xeorxia e Sandwich do Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guyana</source>
        <translation>Güiana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Illa Heard e Illas McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Croatia</source>
        <translation>Croacia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Haiti</source>
        <translation>Haití</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Hungary</source>
        <translation>Hungría</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Indonesia</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>India</source>
        <translation>India</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territorio Oceánico das Indias Británicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Iraq</source>
        <translation>Iraq</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Irán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iceland</source>
        <translation>Islandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Italy</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jamaica</source>
        <translation>Xamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jordan</source>
        <translation>Xordania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Japan</source>
        <translation>Xapón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Kenya</source>
        <translation>Kenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kyrgyzstan</source>
        <translation>Kirguizstán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Cambodia</source>
        <translation>Cambodja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Comoros</source>
        <translation>Comoros</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint Kitts e Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>República Popular Democrática de Korea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Republic of</source>
        <translation>República de Korea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Cayman Islands</source>
        <translation>Illas Caimán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>República Democrática Popular de Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lebanon</source>
        <translation>Líbano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Saint Lucia</source>
        <translation>Santa Lucía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lithuania</source>
        <translation>Lituania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Luxembourg</source>
        <translation>Luxemburgo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Latvia</source>
        <translation>Letonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Morocco</source>
        <translation>Marrocos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Monaco</source>
        <translation>Mónaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Moldova, Republic of</source>
        <translation>Moldavia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Marshall Islands</source>
        <translation>Illas Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Mongolia</source>
        <translation>Mongolia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Northern Mariana Islands</source>
        <translation>Illas Marianas do Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mauritania</source>
        <translation>Mauritania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Mauritius</source>
        <translation>Mauricio</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Maldives</source>
        <translation>Maldivas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Mexico</source>
        <translation>México</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Malaysia</source>
        <translation>Malasia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>New Caledonia</source>
        <translation>Nova Caledonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Niger</source>
        <translation>Níxer</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Norfolk Island</source>
        <translation>Illa Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Nigeria</source>
        <translation>Nixeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Netherlands</source>
        <translation>Países Baixos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>New Zealand</source>
        <translation>Siria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Oman</source>
        <translation>Omán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>French Polynesia</source>
        <translation>Polinesia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Papua New Guinea</source>
        <translation>Papúa Nova Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Philippines</source>
        <translation>Filipinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Pakistan</source>
        <translation>Paquistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Poland</source>
        <translation>Polonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint Pierre e Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Reunion</source>
        <translation>Reunión</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Romania</source>
        <translation>Rumanía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Russian Federation</source>
        <translation>Federación Rusa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Saudi Arabia</source>
        <translation>Arabia Saudí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Solomon Islands</source>
        <translation>Illas Salomón</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Sudan</source>
        <translation>Sudán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sweden</source>
        <translation>Suecia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Slovenia</source>
        <translation>Eslovenia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Illas Svalbard e Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Slovakia</source>
        <translation>Eslovaquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Sierra Leone</source>
        <translation>Serra Leoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Sao Tome and Principe</source>
        <translation>San Tomé e Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Syrian Arab Republic</source>
        <translation>Siria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Swaziland</source>
        <translation>Swazilandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Turks and Caicos Islands</source>
        <translation>Illas Turks e Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Chad</source>
        <translation>Chad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>French Southern Territories</source>
        <translation>Territorios Franceses do Sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Thailand</source>
        <translation>Tailandia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Tajikistan</source>
        <translation>Tadjikistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistán</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Tunisia</source>
        <translation>Tunisia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Timor-Leste</source>
        <translation>Timor-Leste</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire, Sint Eustatius e Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Costa do Marfil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Libya</source>
        <translation>Libia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Saint Martin (French part)</source>
        <translation>San Martín (parte francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedonia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Pitcairn</source>
        <translation>Illas Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Palestine, State of</source>
        <translation>Palestine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Helena, Ascensión e Tristán da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>South Sudan</source>
        <translation>Sudán do sur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (parte holandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Turkey</source>
        <translation>Turquía</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad e Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Ukraine</source>
        <translation>Ucraína</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Illas Exteriores Menores dos Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States</source>
        <translation>Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Estado do Vaticano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>San Vicente e as Granadinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Virgin Islands, British</source>
        <translation>Illas Virxes, británicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Illas Virxes, U.S.A.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis e Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Yemen</source>
        <translation>Iemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Serbia</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>South Africa</source>
        <translation>Suráfrica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Zambia</source>
        <translation>Zambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aland Islands</source>
        <translation>Illas Alands</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Isle of Man</source>
        <translation>Illa de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Saint Barthelemy</source>
        <translation>Saint-Barthelemy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="420"/>
        <source>Could not uncompress GeoIP database file.</source>
        <translation>Non foi posíbel descomprimir o ficheiro da base de datos de GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="441"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>Non foi posíbel gardar o ficheiro da base de datos de GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>A base de datos de GeoIP actualizouse correctamente.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="459"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>Non foi posíbel descargar o ficheiro coa base de datos de GeoIP. Razón: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="110"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Soporte UPnP / NAT-PMP [ACTIVADO]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="119"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Soporte UPnP / NAT-PMP [APAGADO]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="502"/>
        <source>Email Notification Error:</source>
        <translation>Erro na notificación por correo-e:</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="293"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interesado(local) e rexeitado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="299"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interesado(local) e aceptado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="308"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interesado(par) e rexeitado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="314"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interesado(par) e aceptado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="322"/>
        <source>optimistic unchoke</source>
        <translation>aceptado optimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="329"/>
        <source>peer snubbed</source>
        <translation>par desbotado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="336"/>
        <source>incoming connection</source>
        <translation>conexión entrante</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="343"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>non interesado(local) e aceptado(par)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="350"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>non interesado(par) e aceptado(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="357"/>
        <source>peer from PEX</source>
        <translation>par de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="364"/>
        <source>peer from DHT</source>
        <translation>par de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="371"/>
        <source>encrypted traffic</source>
        <translation>tráfico cifrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="378"/>
        <source>encrypted handshake</source>
        <translation>handshake cifrado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="393"/>
        <source>peer from LSD</source>
        <translation>par de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="70"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Port</source>
        <translation>Porto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>Flags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>V. de descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>V. de envío</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevancia</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Ficheiros</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="169"/>
        <source>Add a new peer...</source>
        <translation>Engadir un par novo...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="175"/>
        <source>Copy selected</source>
        <translation>Copiar selección</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="177"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="215"/>
        <source>Ban peer permanently</source>
        <translation>Bloquear este par pemanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="189"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Engadindo manualmente o par %1...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="193"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>Non foi posíbel engadir o par %1 a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="226"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Bloqueando manualmente o par %1...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="197"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="199"/>
        <source>Peer addition</source>
        <translation>Adición de pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="197"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Non foi posíbel engadir algúns pares. Mira o rexistro para obter máis información.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="199"/>
        <source>The peers were added to this torrent.</source>
        <translation>Engadíronse os pares a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="215"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Está seguro que desexa bloquear permantemente os pares seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="216"/>
        <source>&amp;Yes</source>
        <translation>&amp;Si</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="216"/>
        <source>&amp;No</source>
        <translation>&amp;Non</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="58"/>
        <source>No peer entered</source>
        <translation>Non se introduciu ningún par</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="59"/>
        <source>Please type at least one peer.</source>
        <translation>Escriba polo menos un par.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="69"/>
        <source>Invalid peer</source>
        <translation>Par incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="70"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>O par %1 non é válido.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>White: Unavailable pieces</source>
        <translation>Branco: anacos non dispoñíbeis</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>Blue: Available pieces</source>
        <translation>Azul: anacos dispoñíbeis</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Engadidos de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Engadidos de busca instalados</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="50"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="55"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="60"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="65"/>
        <location filename="../gui/search/pluginselectdlg.ui" line="124"/>
        <source>Enabled</source>
        <translation>Activado</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="83"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Pode obter novos engadidos con motores de busca aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="98"/>
        <source>Install a new one</source>
        <translation>Instalar un novo</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="105"/>
        <source>Check for updates</source>
        <translation>Buscar actualizacións</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="112"/>
        <source>Close</source>
        <translation>Pechar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="129"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="162"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="224"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="283"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="166"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="205"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="228"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="287"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Uninstall warning</source>
        <translation>Aviso de desinstalación</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Algúns engadidos non se poden desinstalar porque están incluídos no qBittorrent.
Unicamente pode desinstalar os que vostede engada.
Desactiváronse estes engadidos.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>Uninstall success</source>
        <translation>A desinstalación foi correcta</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Desistaláronse correctamente todos os engadidos seleccionados</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="333"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="340"/>
        <source>New search engine plugin URL</source>
        <translation>URL novo do engadido co motor de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="334"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="341"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="338"/>
        <source>Invalid link</source>
        <translation>Ligazón incorrecta</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="338"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Esta ligazón non semella apuntar a un engadido cun motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="354"/>
        <source>Select search plugins</source>
        <translation>Seleccionar os engadidos de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="355"/>
        <source>qBittorrent search plugin</source>
        <translation>Engadidos de busca do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="395"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="408"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="437"/>
        <source>Search plugin update</source>
        <translation>Actualización do engadido de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="395"/>
        <source>All your plugins are already up to date.</source>
        <translation>Xa están actualizados todos os engadidos.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="408"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Sentímolo pero non foi posíbel buscar actualizaións do engadido. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="415"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="421"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="430"/>
        <source>Search plugin install</source>
        <translation>Instalación de engadidos de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="415"/>
        <source>&quot;%1&quot; search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>O engadido co motor de busca %1 instalouse correctamente.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="421"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Non foi posíbel instalar «%1» engadido co motor de busca «%2»</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="430"/>
        <source>&quot;%1&quot; search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>O engadido co motor de busca %1 actualizouse correctamente.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="437"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Non foi posíbel actualizar «%1» engadido co motor de busca. «%2»</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Fonte do engadido</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Fonte do engadido de busca:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="35"/>
        <source>Local file</source>
        <translation>Ficheiro local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="42"/>
        <source>Web link</source>
        <translation>Ligazón web</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../gui/options.ui" line="69"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="80"/>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="91"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="113"/>
        <source>Web UI</source>
        <translation>Interface web</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="124"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="209"/>
        <source>(Requires restart)</source>
        <translation>(Precisa reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Alternar as cores das filas</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="295"/>
        <location filename="../gui/options.ui" line="321"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="305"/>
        <location filename="../gui/options.ui" line="331"/>
        <source>No action</source>
        <translation>Sen acción</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="701"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Anexar a extensión !qB aos nomes dos ficheiros incompletos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="801"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar os ficheiros torrent en:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1118"/>
        <source>Connections Limits</source>
        <translation>Límites da conexión</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1271"/>
        <source>Proxy Server</source>
        <translation>Servidor proxy</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1574"/>
        <source>Global Rate Limits</source>
        <translation>Límites globais de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1876"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar os límites de velocidade aos datos complementarios do transporte</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1669"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar o uso de límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1681"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>De:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1705"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>A:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1990"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Activar a busca de pares locais (LPD) para encontrar máis pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2002"/>
        <source>Encryption mode:</source>
        <translation>Modo cifrado:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2010"/>
        <source>Prefer encryption</source>
        <translation>Preferir cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2015"/>
        <source>Require encryption</source>
        <translation>Precisa cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2020"/>
        <source>Disable encryption</source>
        <translation>Desactivar o cifrado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2055"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Máis información&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2098"/>
        <source>Maximum active downloads:</source>
        <translation>Descargas activas máximas:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2118"/>
        <source>Maximum active uploads:</source>
        <translation>Envíos activos máximos:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2138"/>
        <source>Maximum active torrents:</source>
        <translation>Torrents activos máximos:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="537"/>
        <source>When adding a torrent</source>
        <translation>Cando engada un torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="58"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="173"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="553"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar o contido do torrent e algunhas opcións</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="991"/>
        <source>Run external program on torrent completion</source>
        <translation>Executar un programa externo ao rematar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1054"/>
        <source>Port used for incoming connections:</source>
        <translation>Porto usado para as conexións entrantes:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1074"/>
        <source>Random</source>
        <translation>Aleatorio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1124"/>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo global de conexións:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1150"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de conexións por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1173"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de envío por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1596"/>
        <location filename="../gui/options.ui" line="1787"/>
        <source>Upload:</source>
        <translation>Enviar:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1640"/>
        <location filename="../gui/options.ui" line="1794"/>
        <source>Download:</source>
        <translation>Descargar:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1603"/>
        <location filename="../gui/options.ui" line="1626"/>
        <location filename="../gui/options.ui" line="1833"/>
        <location filename="../gui/options.ui" line="1840"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="768"/>
        <source>Remove folder</source>
        <translation>Eliminar o cartafol</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1746"/>
        <source>Every day</source>
        <translation>Todos os días</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1974"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Clientes de bittorrent compatíbeis co intercambio de pares (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1313"/>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1292"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1279"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="14"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Acción co dobre clic</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="278"/>
        <source>Downloading torrents:</source>
        <translation>Descargando os torrents:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="300"/>
        <location filename="../gui/options.ui" line="326"/>
        <source>Open destination folder</source>
        <translation>Abrir o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="313"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="345"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="358"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar a pantalla de presentación ao iniciar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="368"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar o qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="394"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar o qBittorrent á area de notificación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="404"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Pechar o qBittorrent á área de notificación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="413"/>
        <source>Tray icon style:</source>
        <translation>Estilo da icona da bandexa:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="421"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="426"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromo (tema escuro)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="431"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromo (tema claro)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="181"/>
        <source>User Interface Language:</source>
        <translation>Idioma da interface do usuario:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="237"/>
        <source>Transfer List</source>
        <translation>Lista de transferencias</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="243"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar a eliminación dos torrents</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="351"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent cando se inicie Windows</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="375"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmar a saída cando haxa torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="385"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostrar o qBittorrent na área de notificacións</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="444"/>
        <source>File association</source>
        <translation>Asociación de ficheiros</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="450"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar o qBittorrent para ficheiros .torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="457"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar o qBittorrent para ligazóns magnet</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="470"/>
        <source>Power Management</source>
        <translation>Xestión de enerxía</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="476"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhibir a suspensión do sistema cando haxa torrents activos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="546"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Non iniciar a descarga automaticamente</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="562"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Traer o diálogo ao primeiro plano</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="584"/>
        <source>Hard Disk</source>
        <translation>Disco ríxido</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="590"/>
        <source>Save files to location:</source>
        <translation>Gardar os ficheiros na localización:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="638"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Anexar a etiqueta do torrent á ruta onde se garda</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="648"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-asignar o espazo no disco a todos os ficheiros</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="655"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Manter os torrents incompletos en:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="708"/>
        <source>Automatically add torrents from:</source>
        <translation>Engadir automaticamente os torrents desde:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="758"/>
        <source>Add folder...</source>
        <translation>Engadir un cartafol...</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="850"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar os ficheiros torrent das descargas rematadas a:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="906"/>
        <source>Email notification upon download completion</source>
        <translation>Enviar un correo-e ao rematar a descarga</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="920"/>
        <source>Destination email:</source>
        <translation>Correo-e de destino:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="930"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="979"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Este servidor require unha conexión segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1046"/>
        <source>Listening Port</source>
        <translation>Porto de escoita</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1096"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar un porto UPnP / NAT-PMP para reencamiñar desde o router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1106"/>
        <source>Use different port on each startup</source>
        <translation>Usar un porto distinto en cada inicio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1232"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Número máximo global de slots de envío:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1367"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Doutro xeito, o servidor proxy usarase unicamente para conexións co localizador</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1370"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar o proxy para conexións cos pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1377"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Desactivar as conexións non aceptadas por proxies</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1390"/>
        <source>Use proxy only for torrents</source>
        <translation>Usar o proxy só para torrents</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1387"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>As fontes RSS, os motores de busca, as actualizacións do software ou calquera outra cousa que non sexan as transferencias do torrent e as operacións relacionadas (como o intercambio de pares) usarán unha conexión directa.</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1459"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Información: o contrasinal gárdase sen cifrar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1472"/>
        <source>IP Filtering</source>
        <translation>Filtrado de IPs</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1513"/>
        <source>Reload the filter</source>
        <translation>Recargar o filtro</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1529"/>
        <source>Apply to trackers</source>
        <translation>Aplicar aos localizadores</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1869"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar o límite da velocidade aos pares no LAN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1732"/>
        <source>When:</source>
        <translation>Cando:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1751"/>
        <source>Weekdays</source>
        <translation>Entresemana</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1756"/>
        <source>Weekends</source>
        <translation>Fins de semana</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1863"/>
        <source>Rate Limits Settings</source>
        <translation>Axustes dos límites de velocidade</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1883"/>
        <source>Enable µTP protocol</source>
        <translation>Activar o protocolo µTP</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1890"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar o límite de velocidade ao protocolo uTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1958"/>
        <source>Privacy</source>
        <translation>Privacidade</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1964"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar o DHT (rede descentralizada) para encontrar máis pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1977"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Activar o intercambio de pares (PeX) para buscar máis pares</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1987"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar pares na súa rede local</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2045"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Activar cando se use unha conexión proxy ou VPN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2048"/>
        <source>Enable anonymous mode</source>
        <translation>Activar o modo anónimo</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2197"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Non ter en conta os torrents lentos nestes límites</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2218"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sementar os torrents até alcanzar a taxa</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2247"/>
        <source>then</source>
        <translation>despois</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2258"/>
        <source>Pause them</source>
        <translation>Pausalos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2263"/>
        <source>Remove them</source>
        <translation>Eliminalos</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2282"/>
        <source>Automatically add these trackers to new downloads:</source>
        <translation>Engadir automaticamente estes localizadores ás novas descargas:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2401"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar un porto UPnP / NAT-PMP para reencamiñar desde o router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2411"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Usar HTTPS no canto de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2454"/>
        <source>Import SSL Certificate</source>
        <translation>Importar o certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2507"/>
        <source>Import SSL Key</source>
        <translation>Importar a chave SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2442"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1663"/>
        <source>Alternative Rate Limits</source>
        <translation>Límites alternativos de velocidade </translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2495"/>
        <source>Key:</source>
        <translation>Chave:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2529"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Información sobre certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2574"/>
        <source>Bypass authentication for localhost</source>
        <translation>Omitir a autenticación no localhost</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2598"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualizar o nome do dominio dinámico</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2610"/>
        <source>Service:</source>
        <translation>Servizo:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2633"/>
        <source>Register</source>
        <translation>Rexistro</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2642"/>
        <source>Domain name:</source>
        <translation>Nome do dominio:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1287"/>
        <source>(None)</source>
        <translation>(Ningún)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="102"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1302"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1339"/>
        <location filename="../gui/options.ui" line="2366"/>
        <source>Port:</source>
        <translation>Porto:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="940"/>
        <location filename="../gui/options.ui" line="1403"/>
        <location filename="../gui/options.ui" line="2542"/>
        <source>Authentication</source>
        <translation>Autenticación</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="952"/>
        <location filename="../gui/options.ui" line="1417"/>
        <location filename="../gui/options.ui" line="2581"/>
        <location filename="../gui/options.ui" line="2656"/>
        <source>Username:</source>
        <translation>Nome do usuario:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="962"/>
        <location filename="../gui/options.ui" line="1437"/>
        <location filename="../gui/options.ui" line="2588"/>
        <location filename="../gui/options.ui" line="2670"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2083"/>
        <source>Torrent Queueing</source>
        <translation>Torrent na cola</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2207"/>
        <source>Share Ratio Limiting</source>
        <translation>Limites da taxa de compartición</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2352"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Activar a interface de usuario web (control remoto)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1297"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1484"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta do filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="83"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>Detectouse unha saída incorrecta do programa. Usando os ficheiros de reserva para restabelecer os axustes.</translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="178"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Produciuse un erro de acceso cando se tentaba escribir o ficheiro de configuración.</translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="180"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Produciuse un erro de formato cando se tentaba escribir o ficheiro de configuración.</translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../gui/previewselect.cpp" line="54"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="55"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="56"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Preview impossible</source>
        <translation>A previsualización non é posíbel</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Sentímolo, non se pode previsualizar este ficheiro</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="106"/>
        <source>Not downloaded</source>
        <translation>Non descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="162"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="109"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="163"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="103"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="112"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="164"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="46"/>
        <source>General</source>
        <translation>Xeral</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>Trackers</source>
        <translation>Localizadores</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="55"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>HTTP Sources</source>
        <translation>Fontes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="63"/>
        <source>Content</source>
        <translation>Contido</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Descargado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Dispoñíbel:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferencia</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tempo  en activo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Tempo restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Enviado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Sementes:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocidade de descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocidade de envío:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Pares:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Límite da descarga:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Límite do envío:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Desbotado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Conexións:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1020"/>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1027"/>
        <source>Select None</source>
        <translation>Non seleccionar nada</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1103"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1098"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Taxa de compartición:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Anunciar de novo en:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Visto completo por última vez:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Tamaño total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Anacos:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Creado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Engadido o:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Completado o:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Creado o:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Hash do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1093"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1085"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <source>Do not download</source>
        <translation>Non descargar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="431"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="438"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (ten %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="383"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="386"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 esta sesión)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="395"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sementou durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="402"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="415"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="419"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="423"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="427"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 media)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="568"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="569"/>
        <source>Open Containing Folder</source>
        <translation>Abrir o cartafol que o contén</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="570"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="575"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="621"/>
        <source>New Web seed</source>
        <translation>Nova semente web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="627"/>
        <source>Remove Web seed</source>
        <translation>Retirar semente web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="629"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL da semente web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="630"/>
        <source>Edit Web seed URL</source>
        <translation>Editar URL da semente web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="655"/>
        <source>Rename the file</source>
        <translation>Cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="656"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="660"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="691"/>
        <source>The file could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="661"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Este nome de ficheiro contén caracteres prohibidos, escolla un nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="692"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="730"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome de ficheiro xa existe neste cartafol. Use un nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="729"/>
        <source>The folder could not be renamed</source>
        <translation>Non foi posíbel cambiar o nome do cartafol</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="832"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="81"/>
        <source>Filter files...</source>
        <translation>Ficheiros dos filtros...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="775"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova semente desde unha url</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="776"/>
        <source>New URL seed:</source>
        <translation>Nova semente desde unha url:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="782"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="833"/>
        <source>This URL seed is already in the list.</source>
        <translation>Esta semente desde unha url xa está na lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="825"/>
        <source>Web seed editing</source>
        <translation>Edición da semente web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="826"/>
        <source>Web seed URL:</source>
        <translation>URL da semente web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="111"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>O seu enderezo IP bloqueouse despois de moitos intentos de autenticación.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="388"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Erro: «%1» non é un ficheiro torrent correcto.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="396"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Erro: Non foi posíbel engadir o torrent á sesión.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="405"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Erro de E/S: Non foi posíbel crear o ficheiro temporal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="140"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 é un parámetro descoñecido para a liña de ordes.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="152"/>
        <location filename="../app/main.cpp" line="165"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 debe ser o parámetro único para a liña de ordes.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="175"/>
        <source>%1 must specify the correct port (1 to 65535).</source>
        <translation>%1 debe especificar o porto correcto (1-65535).</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="199"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Non pode usar %1: qBittorrent xa está en execución por este usuario.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="384"/>
        <source>Usage:</source>
        <translation>Utilización:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="397"/>
        <source>Options:</source>
        <translation>Opcións:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Displays program version</source>
        <translation>Mostrar a versión do programa</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Displays this help message</source>
        <translation>Mostra esta mensaxe de axuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="403"/>
        <source>Changes the Web UI port (current: %1)</source>
        <translation>Cambia o porto da interface web (actual: %1)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="406"/>
        <source>Disable splash screen</source>
        <translation>Desactivar a pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="408"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Executar no modo daemon (en segundo plano)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="410"/>
        <source>Downloads the torrents passed by the user</source>
        <translation>Descargar os torrents indicados polo usuario</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="429"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Executar o aplicativo coa opción -h para saber os parámetros da liña de ordes.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="431"/>
        <source>Bad command line</source>
        <translation>Liña de ordes incorrecta</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="437"/>
        <source>Bad command line: </source>
        <translation>Liña de ordes incorrecta:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="450"/>
        <source>Legal Notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="451"/>
        <location filename="../app/main.cpp" line="461"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent é un programa para compartir ficheiros. Cando descarga un torrent os seus datos son visíbeis para outros . Calquera contido que comparta é da súa única responsabilidade.

Non se mostrarán máis avisos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="452"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Prema a tecla %1 para aceptar e continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="462"/>
        <source>Legal notice</source>
        <translation>Aviso legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="463"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="464"/>
        <source>I Agree</source>
        <translation>Acepto</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="122"/>
        <source>Torrent name: %1</source>
        <translation>Nome do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="123"/>
        <source>Torrent size: %1</source>
        <translation>Tamaño do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="124"/>
        <source>Save path: %1</source>
        <translation>Ruta onde gardar: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="125"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>O torrent descargouse en %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="128"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Grazas por usar o qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="134"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] rematou a descarga de %1</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="204"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Non se encontrou o nome do servidor remoto (nome incorrecto)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The operation was canceled</source>
        <translation>Cancelouse a operación</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>O servidor remoto pechou a conexión prematuramente, antes de que se recibise e procesase a resposta completa</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The connection to the remote server timed out</source>
        <translation>Excedeuse o tempo para conectar co servidor remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Produciuse un fallo no saúdo do SSL/TLS</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>The remote server refused the connection</source>
        <translation>O servidor remoto rexeitou a conexion</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The connection to the proxy server was refused</source>
        <translation>O servidor proxy rexeitou a conexión</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>O servidor proxy pechou a conexión prematuramente</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy host name was not found</source>
        <translation>Non se encontrou o nome do servidor proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Excedeuse o tempo para conectar co proxy ou este non respondeu en tempo á solicitude enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>O proxy require autenticación para satisfacer a solicitude pero non aceptou as credenciais ofrecidas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Denegouse o acceso ao contido remoto (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Non se permite a operación solicitada no contido remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Non se encontrou o contido remoto no servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>O servidor remoto require autenticacion para servir o contido pero non aceptou as credenciais enviadas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>A API de acceso á rede non pode responder á solicitude porque o protocolo é descoñecido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>A operación solicitada é incorrecta para este protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>An unknown network-related error was detected</source>
        <translation>Detectouse un erro descoñecido relacionado coa rede</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Detectouse un erro descoñecido relacionado co proxy</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Detectouse un erro descoñecido relacionado co contido remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Detectouse unha ruptura no protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>Unknown error</source>
        <translation>Erro descoñecido</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="53"/>
        <location filename="../app/upgrade.h" line="66"/>
        <source>Upgrade</source>
        <translation>Anovar</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="56"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Actualizou desde unha versión antiga que gardaba as cousas dun xeito distinto. Debe migrar ao novo sistema de gardado. Non lle será posíbel usar unha versión anterior á v3.3.0 de novo. Desexa continuar? [y/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="65"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Actualizou desde unha versión antiga que gardaba as cousas dun xeito distinto. Debe migrar ao novo sistema de gardado. Se continúa, non lle será posíbel usar unha versión anterior á v3.3.0 de novo.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="143"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>Non foi posíbel migrar o torrent co hash: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="146"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>Non foi posíbel mirgrar o torrent. O nome do ficheiro co resumo rápido é incorrecto: %1</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../gui/rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Subscrición nova</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="47"/>
        <location filename="../gui/rss/rss.ui" line="195"/>
        <location filename="../gui/rss/rss.ui" line="198"/>
        <source>Mark items read</source>
        <translation>Marcar como lidos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Actualizar todos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>Xestor de descargas RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Axustes...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="124"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (dobre clic para descargar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="158"/>
        <location filename="../gui/rss/rss.ui" line="161"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="166"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="169"/>
        <source>Rename</source>
        <translation>Cambiar o nome</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="174"/>
        <location filename="../gui/rss/rss.ui" line="177"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="182"/>
        <source>New subscription...</source>
        <translation>Subscrición nova...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="187"/>
        <location filename="../gui/rss/rss.ui" line="190"/>
        <source>Update all feeds</source>
        <translation>Actualizar todas as fontes</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="203"/>
        <source>Download torrent</source>
        <translation>Descargar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="208"/>
        <source>Open news URL</source>
        <translation>Abrir a URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="213"/>
        <source>Copy feed URL</source>
        <translation>Copiar a URL da fonte</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="218"/>
        <source>New folder...</source>
        <translation>Cartafol novo...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="223"/>
        <source>Manage cookies...</source>
        <translation>Xestionar as cookies...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Actualizar os fluxos RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="219"/>
        <source>Stream URL:</source>
        <translation>URL de fluxo:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="219"/>
        <source>Please type a RSS stream URL</source>
        <translation>Escriba unha url do fluxo rss</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="229"/>
        <source>This RSS feed is already in the list.</source>
        <translation>A fonte rss xa está na lista.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Please choose a folder name</source>
        <translation>Seleccione un nome de cartafol</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Folder name:</source>
        <translation>Nome do cartafol:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>New folder</source>
        <translation>Cartafol novo</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="257"/>
        <source>Deletion confirmation</source>
        <translation>Confirmación de eliminación</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="258"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Confirma a eliminación das fontes RSS seleccionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="405"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Escolla un nome novo para esta fonte RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="405"/>
        <source>New feed name:</source>
        <translation>Nome novo da fonte:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="409"/>
        <source>Name already in use</source>
        <translation>O nome xa existe</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="409"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Este nome xa está usado por un elemento, escolla outro.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="579"/>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="581"/>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="658"/>
        <source>Unread</source>
        <translation>Sen ler</translation>
    </message>
</context>
<context>
    <name>Rss::Feed</name>
    <message>
        <location filename="../base/rss/rssfeed.cpp" line="381"/>
        <source>Automatic download of &apos;%1&apos; from &apos;%2&apos; RSS feed failed because it doesn&apos;t contain a torrent or a magnet link...</source>
        <translation>A descarga automática de «%1» desde a fonte RSS «%2» fallou porque non contén ningún torrent nin ligazón magnet.</translation>
    </message>
    <message>
        <location filename="../base/rss/rssfeed.cpp" line="386"/>
        <source>Automatically downloading &apos;%1&apos; torrent from &apos;%2&apos; RSS feed...</source>
        <translation>Descargando automaticamente %1 torrents desde %2 fontes RSS...</translation>
    </message>
</context>
<context>
    <name>Rss::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rssparser.cpp" line="248"/>
        <source>Invalid RSS feed.</source>
        <translation>Fonte RSS incorrecta.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Axustes do lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Intervalo de actualización de fontes RSS:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artigos por fonte:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="66"/>
        <source>Watch Folder</source>
        <translation>Vixiar cartafol</translation>
    </message>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="67"/>
        <source>Default Folder</source>
        <translation>Cartafol predeterminado</translation>
    </message>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="68"/>
        <source>Browse...</source>
        <translation>Explorar...</translation>
    </message>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Choose save path</source>
        <translation>Seleccionar a ruta onde gardar</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="131"/>
        <source>Watch Folder</source>
        <translation>Vixiar cartafol</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="134"/>
        <source>Default Folder</source>
        <translation>Cartafol predeterminado</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="156"/>
        <source>Watched Folder</source>
        <translation>Cartafol explorado</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="159"/>
        <source>Save Files to</source>
        <translation>Gardar ficheiros en</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../base/searchengine.cpp" line="171"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Formato descoñecido do ficheiro co engadido do motor de busca.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="185"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Xa está instalada unha versión máis recente do engadido.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="213"/>
        <location filename="../base/searchengine.cpp" line="216"/>
        <source>Plugin is not supported.</source>
        <translation>O engadido non é compatíbel.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="337"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>O servidor de actualizacións non está dispoñíbel temporalmente. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="355"/>
        <location filename="../base/searchengine.cpp" line="357"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Produciuse un fallo ao descargar o ficheiro do engadido. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="597"/>
        <source>An incorrect update info received.</source>
        <translation>Recibiuse unha información incorrecta da actualización.º</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="621"/>
        <source>All categories</source>
        <translation>Todas as categorías</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="622"/>
        <source>Movies</source>
        <translation>Películas</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="623"/>
        <source>TV shows</source>
        <translation>Programas de TV</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="624"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="625"/>
        <source>Games</source>
        <translation>Xogos</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="626"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="627"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="628"/>
        <source>Pictures</source>
        <translation>Imaxes</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="629"/>
        <source>Books</source>
        <translation>Libros</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="57"/>
        <location filename="../gui/search/searchlistdelegate.cpp" line="61"/>
        <source>Unknown</source>
        <translation>Descoñecido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="72"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="73"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="74"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Sementadores</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="75"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Pares incompletos</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="76"/>
        <source>Search engine</source>
        <translation>Motor de busca</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="28"/>
        <location filename="../gui/search/searchwidget.cpp" line="181"/>
        <location filename="../gui/search/searchwidget.cpp" line="202"/>
        <location filename="../gui/search/searchwidget.cpp" line="296"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="75"/>
        <location filename="../gui/search/searchwidget.cpp" line="364"/>
        <source>Stopped</source>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="107"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="117"/>
        <source>Go to description page</source>
        <translation>Ir á páxina da descrición</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="127"/>
        <source>Copy description page URL</source>
        <translation>Copiar URL da páxina coa descrición</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="147"/>
        <source>Search plugins...</source>
        <translation>Engadidos de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="121"/>
        <source>All enabled</source>
        <translation>Todo activado</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="122"/>
        <source>All plugins</source>
        <translation>Todos os engadidos</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="125"/>
        <location filename="../gui/search/searchwidget.cpp" line="167"/>
        <source>Multiple...</source>
        <translation>Múltiple...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="194"/>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <location filename="../gui/search/searchwidget.cpp" line="302"/>
        <source>Search Engine</source>
        <translation>Motor de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="194"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Instale Python para usar o motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="212"/>
        <source>Empty search pattern</source>
        <translation>Patrón de busca baleiro</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="212"/>
        <source>Please type a search pattern first</source>
        <translation>Escriba primeiro o patrón de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="239"/>
        <location filename="../gui/search/searchwidget.cpp" line="341"/>
        <source>Results &lt;i&gt;(%1)&lt;/i&gt;:</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados &lt;i&gt;(%1)&lt;/i&gt;:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="271"/>
        <source>Searching...</source>
        <translation>Buscando...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="274"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <location filename="../gui/search/searchwidget.cpp" line="292"/>
        <source>Search has finished</source>
        <translation>A busca rematou</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="288"/>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <source>Search aborted</source>
        <translation>Busca cancelada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="290"/>
        <source>Search returned no results</source>
        <translation>A busca non obtivo resultados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="302"/>
        <source>Search has failed</source>
        <translation>A busca fallou</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="309"/>
        <source>An error occurred during search...</source>
        <translation>Produciuse un erro durante a busca...</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="45"/>
        <source>Exit confirmation</source>
        <translation>Confirmación de saída</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="46"/>
        <source>Exit now</source>
        <translation>Saír agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="49"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmación de peche</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="50"/>
        <source>Shutdown now</source>
        <translation>Pechar agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="109"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation>qBittorrent sairá se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="112"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation>O computador apagarase se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="115"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation>O computador entrará no modo suspensión se non o cancela nos próximos %1 segundos.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="118"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation>O computador entrará no modo hibernación se non o cancela nos vindeiros %1 segundos.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="78"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="47"/>
        <source>Total Upload</source>
        <translation>Total enviado</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="48"/>
        <source>Total Download</source>
        <translation>Total descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Payload Upload</source>
        <translation>Envío dos datos principais</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Payload Download</source>
        <translation>Descarga dos datos principais</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Overhead Upload</source>
        <translation>Datos complementarios do envío</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Overhead Download</source>
        <translation>Datos complementarios da descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>DHT Upload</source>
        <translation>Envío DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>Tracker Upload</source>
        <translation>Envío ao localizador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>Tracker Download</source>
        <translation>Descarga do localizador</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Período:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 </translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="103"/>
        <source>Select Graphs</source>
        <translation>Seleccionar gráficos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="79"/>
        <source>Total Upload</source>
        <translation>Total enviado</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Download</source>
        <translation>Total descargado</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Payload Upload</source>
        <translation>Envío dos datos principais</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Download</source>
        <translation>Descarga dos datos principais</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Overhead Upload</source>
        <translation>Datos complementarios do envío</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Download</source>
        <translation>Datos complementarios da descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>DHT Upload</source>
        <translation>Envío DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Download</source>
        <translation>Descarga DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Tracker Upload</source>
        <translation>Envío ao localizador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Download</source>
        <translation>Descarga do localizador</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadísticas de usuario</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Conexións totais con pares:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Taxa global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Descarga absoluta:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Envío absoluto:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Desbotado total (esta sesión):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadísticas da caché</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache Hits:</source>
        <translation>Accesos á caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Tamaño total dos búferes:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadísticas de rendemento</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Traballos na cola E/S:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga da caché de escritura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue (ms):</source>
        <translation>Tempo medio na cola (ms):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga da caché de lectura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamaño total da cola:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="243"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>Connection status:</source>
        <translation>Estado da conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Non hai conexións directas. Isto pode significar que hai problemas na configuración da rede.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="73"/>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="141"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>É necesario reiniciar o qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="151"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>O qBittorrent foi actualizado e necesita reiniciarse para que os cambios sexan efectivos.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Connection Status:</source>
        <translation>Estado da conexión:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Desconectado. Isto significa, normalmente, que o programa fallou ao escoitar o porto seleccionado para conexións entrantes.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Online</source>
        <translation>Conectado</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="203"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Prema para cambiar aos límites alternativos de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="199"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Prema para cambiar aos límites normais de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="212"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Cambio manual do modo de límites de velocidade. O programador está desactivado.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="219"/>
        <source>Global Download Speed Limit</source>
        <translation>Límite global de velocidade de descarga</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Límite global de velocidade de envío</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="117"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="120"/>
        <source>Downloading (0)</source>
        <translation>Descargando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="123"/>
        <source>Seeding (0)</source>
        <translation>Sementando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="126"/>
        <source>Completed (0)</source>
        <translation>Completado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="129"/>
        <source>Resumed (0)</source>
        <translation>Continuado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="132"/>
        <source>Paused (0)</source>
        <translation>Detido (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="135"/>
        <source>Active (0)</source>
        <translation>Activo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="138"/>
        <source>Inactive (0)</source>
        <translation>Inactivo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="141"/>
        <source>Errored (0)</source>
        <translation>Atopouse o erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="159"/>
        <source>Downloading (%1)</source>
        <translation>Descargando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="160"/>
        <source>Seeding (%1)</source>
        <translation>Sementando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Completed (%1)</source>
        <translation>Completado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="162"/>
        <source>Paused (%1)</source>
        <translation>Detido (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="163"/>
        <source>Resumed (%1)</source>
        <translation>Continuado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="164"/>
        <source>Active (%1)</source>
        <translation>Activo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>Inactive (%1)</source>
        <translation>Inactivo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Errored (%1)</source>
        <translation>Atopouse o erro (%1)</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="59"/>
        <source>Download Priority</source>
        <translation>Prioridade da descarga</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="78"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccionar un cartafol para engadir ao torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="92"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccionar un ficheiro para engadir ao torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>No input path set</source>
        <translation>Non se estabeleceu unha ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>Please type an input path first</source>
        <translation>Escriba primeiro unha ruta de entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Select destination torrent file</source>
        <translation>Seleccionar o destino para o ficheiro torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Ficheiros torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully: %1</source>
        <comment>%1 is the path of the torrent</comment>
        <translation>O torrent creouse correctamente: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Crear un torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>A creación do torrent fallou, razón:%1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>O ficheiro torrent creado non é válido. Non será engadido á lista de descargas.</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importación de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>O asistente axudarao a compartir co qBittorrent un torrent descargado.</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Ficheiro torrent a importar:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Localización do contido:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Ignorar o paso de comprobación de datos e sementar inmediatamente</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent file to import</source>
        <translation>Ficheiro torrent a importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent files</source>
        <translation>Ficheiros torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="89"/>
        <source>&apos;%1&apos; Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>Ficheiros %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="91"/>
        <source>Please provide the location of &apos;%1&apos;</source>
        <comment>%1 is a file name</comment>
        <translation>Indique a localización de %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="124"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Indique a localización do torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>Invalid torrent file</source>
        <translation>Ficheiro torrent incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>This is not a valid torrent file.</source>
        <translation>Este non é un ficheiro torrent correcto.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Feito</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Sementes</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. de descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. de envío</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Taxa</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tempo restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Engadido o</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado o</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Tracker</source>
        <translation>Localizador</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límite de descarga</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límite de envío</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Descargado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Desc. na sesión</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Env. na sesión</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tempo  en activo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Gardar a ruta</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límite da taxa</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Visto completo por última vez</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última actividade</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamaño total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="428"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="431"/>
        <source>Trackerless (0)</source>
        <translation>Sen localizador (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="434"/>
        <source>Error (0)</source>
        <translation>Erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="437"/>
        <source>Warning (0)</source>
        <translation>Aviso (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="478"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="535"/>
        <source>Trackerless (%1)</source>
        <translation>Sen localizador (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="484"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="530"/>
        <source>%1 (%2)</source>
        <comment>openbittorrent.com (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="560"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="592"/>
        <source>Error (%1)</source>
        <translation>Erro (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="573"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="607"/>
        <source>Warning (%1)</source>
        <translation>Aviso (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="637"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;. Trying to download favicon in PNG format.</source>
        <translation>Non foi posíbel decodificar o favicon da url «%1». Tentando descargar o favicon en formato PNG.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="642"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;.</source>
        <translation>Non foi posíbel decodificar o favicon da URL «%1».</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="656"/>
        <source>Couldn&apos;t download favicon for URL &apos;%1&apos;. Reason: %2</source>
        <translation>Non foi posíbel descargar o favicon da url «%1». Razón: «%2»</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="665"/>
        <source>Resume torrents</source>
        <translation>Continuar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="666"/>
        <source>Pause torrents</source>
        <translation>Pausar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="667"/>
        <source>Delete torrents</source>
        <translation>Eliminar os torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="701"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="715"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="69"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="70"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="71"/>
        <source>Peers</source>
        <translation>Pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="72"/>
        <source>Message</source>
        <translation>Mensaxe</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="217"/>
        <location filename="../gui/properties/trackerlist.cpp" line="286"/>
        <source>Working</source>
        <translation>Funcionando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="218"/>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="239"/>
        <source>This torrent is private</source>
        <translation>Este torrent é privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="290"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="294"/>
        <source>Not working</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="298"/>
        <source>Not contacted yet</source>
        <translation>Aínda sen conexión</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker URL:</source>
        <translation>URL do localizador:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker editing</source>
        <translation>Edición do localizador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>Tracker editing failed</source>
        <translation>Fallou a edición do localizador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>A URL introducida para o localizador non é correcta.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>The tracker URL already exists.</source>
        <translation>A URL do localizador xa existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="448"/>
        <source>Add a new tracker...</source>
        <translation>Engadir un novo localizador...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="454"/>
        <source>Copy tracker URL</source>
        <translation>Copiar a url do localizador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="455"/>
        <source>Edit selected tracker URL</source>
        <translation>Editar a URL do localizador seleccionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="460"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forzar outro anuncio nos localizadores seleccionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="462"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forzar outro anuncio en todos os localizadores</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="453"/>
        <source>Remove tracker</source>
        <translation>Eliminar o localizador</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo de adición de localizadores</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de localizadores a engadir (un por liña):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>URL da lista compatíbel con µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Produciuse un erro mentres se tentaba abrir o ficheiro descargado.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No change</source>
        <translation>Sen cambios</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No additional trackers were found.</source>
        <translation>Non se encontraron localizadores novos.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>Download error</source>
        <translation>Erro de descarga</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Non foi posíbel descargar a lista de localizadores, razón: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="97"/>
        <source>Downloading</source>
        <translation>Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="103"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Descargando os metadatos</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="109"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Asignando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="133"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="120"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Na cola</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="113"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sementando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="100"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Á espera</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="106"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Descargando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="116"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sementando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="124"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Comprobando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>Na cola de comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="130"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Comprobando os datos para continuar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="136"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="139"/>
        <source>Missing Files</source>
        <translation>Ficheiros que faltan</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="142"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Atopouse un erro</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="172"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sementado durante %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>Hai %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="794"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="802"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="810"/>
        <source>Trackers</source>
        <translation>Localizadores</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="511"/>
        <source>Column visibility</source>
        <translation>Visibilidade da columna</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="763"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="252"/>
        <source>Choose save path</source>
        <translation>Seleccionar unha ruta onde gardar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="439"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límites da velocidade de descarga do torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="468"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límites da velocidade de envío do torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Recheck confirmation</source>
        <translation>Confirmación da nova comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Está seguro que desexa comprobar de novo os torrents seleccionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>New Label</source>
        <translation>Etiqueta nova</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Invalid label name</source>
        <translation>O nome da etiqueta non é correcto</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Non use ningún caracter especial no nome da etiqueta.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>Rename</source>
        <translation>Cambiar o nome</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>New name:</source>
        <translation>Nome novo:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="629"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="633"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forzar continuación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="631"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="635"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="637"/>
        <source>Preview file...</source>
        <translation>Previsualizar o ficheiro...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="639"/>
        <source>Limit share ratio...</source>
        <translation>Límite da taxa de compartición...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="641"/>
        <source>Limit upload rate...</source>
        <translation>Límite da velocidade de envío...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="643"/>
        <source>Limit download rate...</source>
        <translation>Límite da velocidade de descarga...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="645"/>
        <source>Open destination folder</source>
        <translation>Abrir o cartafol de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="647"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="649"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover abaixo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="651"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover ao principio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="653"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover ao final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="655"/>
        <source>Set location...</source>
        <translation>Estabelecer a localización...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="661"/>
        <source>Copy name</source>
        <translation>Copiar o nome</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="813"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="657"/>
        <source>Force recheck</source>
        <translation>Forzar outra comprobación</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="659"/>
        <source>Copy magnet link</source>
        <translation>Copiar a ligazón magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="663"/>
        <source>Super seeding mode</source>
        <translation>Modo super-sementeira</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="666"/>
        <source>Rename...</source>
        <translation>Cambiar o nome...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="668"/>
        <source>Download in sequential order</source>
        <translation>Descargar en orde secuencial</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="671"/>
        <source>Download first and last piece first</source>
        <translation>Descargar primeiro os anacos inicial e final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nova...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="765"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Restabelecer</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Límites da taxa de Envío/Descarga do torrent</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Usar o límite da taxa global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Non estabelecer límite na taxa</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Estabelecer o límite da taxa en</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="84"/>
        <source>The Web UI is listening on port %1</source>
        <translation>A interface web está escoitando no porto %1</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI Error - Unable to bind Web UI to port %1</source>
        <translation>Erro na interface de usuario web - Non é posíbel conectar a interface web ao porto %1</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="55"/>
        <source>An advanced BitTorrent client programmed in &lt;nobr&gt;C++&lt;/nobr&gt;, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un cliente BitTorrent avanzado programado en &lt;nobr&gt;C++&lt;/nobr&gt;, baseado en QT toolkit e libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="57"/>
        <source>Copyright %1 2006-2015 The qBittorrent project</source>
        <translation>Dereitos de autor ©2006-2015 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="59"/>
        <source>Home Page: </source>
        <translation>Páxina de inicio:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="61"/>
        <source>Bug Tracker: </source>
        <translation>Seguimento de fallos:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="63"/>
        <source>Forum: </source>
        <translation>Foro:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="66"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent en Freenode</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Engadir pares</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one per line):</source>
        <translation>Lista de pares a engadir (un por liña):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:porto / [IPv6]:porto</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autenticación do localizador</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Localizador:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Nome do usuario:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="154"/>
        <source>Log in</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmación de eliminación - &apos;qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Lembrar a elección</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Eliminar tamén os ficheiros do disco duro</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="308"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Ferramenta para a creación de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Crear un ficheiro torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="60"/>
        <source>Add file</source>
        <translation>Engadir un ficheiro</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="67"/>
        <source>Add folder</source>
        <translation>Engadir un cartafol</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Ficheiro ou cartafol para engadir ao torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>URLs do localizador:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>URLs das sementes web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="98"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Pode separar os grupos / tiers de localizadores cunha liña en branco.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Tamaño do anaco:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="165"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="170"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="175"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="180"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="185"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="190"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="195"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="200"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="205"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="210"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="215"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="223"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="248"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privado (se está activado non se distribuirá na rede DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="255"/>
        <source>Start seeding after creation</source>
        <translation>Iniciar a sementeira despois da creación</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar os límites da taxa de compartición para este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="301"/>
        <source>Create and save...</source>
        <translation>Crear e gardar...</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Progress:</source>
        <translation>Progreso:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Engadir ligazóns torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="58"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un por liña (acepta ligazóns HTTP, magnet e info-hashes)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="80"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="87"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descargar desde urls</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>No URL entered</source>
        <translation>Non se introduciu ningunha URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>Please type at least one URL.</source>
        <translation>Escriba polo menos unha URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Información do fallo</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/utils/fs.cpp" line="446"/>
        <location filename="../base/utils/fs.cpp" line="453"/>
        <location filename="../base/utils/fs.cpp" line="463"/>
        <location filename="../base/utils/fs.cpp" line="496"/>
        <location filename="../base/utils/fs.cpp" line="508"/>
        <source>Downloads</source>
        <translation>Descargas</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="283"/>
        <source>Python not detected</source>
        <translation>Non se detectou Python</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="311"/>
        <source>Python version: %1</source>
        <translation>Versión de Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="338"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="426"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="430"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="326"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Descoñecido</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="206"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>O qBittorrent vai apagar o computador porque remataron todas as descargas.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="419"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="422"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="457"/>
        <source>Working</source>
        <translation>Funcionando</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="455"/>
        <source>Updating...</source>
        <translation>Actualizando...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="459"/>
        <source>Not working</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="453"/>
        <source>Not contacted yet</source>
        <translation>Aínda sen contactar</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../gui/options_imp.cpp" line="1280"/>
        <location filename="../gui/options_imp.cpp" line="1282"/>
        <source>Choose export directory</source>
        <translation>Seleccionar un cartafol de exportación</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1320"/>
        <location filename="../gui/options_imp.cpp" line="1322"/>
        <location filename="../gui/options_imp.cpp" line="1333"/>
        <location filename="../gui/options_imp.cpp" line="1335"/>
        <source>Choose a save directory</source>
        <translation>Seleccionar un cartafol onde gardar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1228"/>
        <source>Add directory to scan</source>
        <translation>Engadir un cartafol para explorar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="191"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parámetros aceptados (sensíbel ás maiúsc.)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="192"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nome do torrent</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="193"/>
        <source>%L: Label</source>
        <translation>%L: Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="194"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: ruta ao contido (igual á ruta raíz pero para torrents de varios ficheiros)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="195"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: ruta raíz (ruta ao subcartafol do primeiro torrent)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="196"/>
        <source>%D: Save path</source>
        <translation>%D: Ruta onde gardar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="197"/>
        <source>%C: Number of files</source>
        <translation>%C: Número de ficheiros</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="198"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamaño do torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="199"/>
        <source>%T: Current tracker</source>
        <translation>%T: Localizador actual</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="200"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1235"/>
        <source>Folder is already being watched.</source>
        <translation>O cartafol xa está sendo explorado.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1238"/>
        <source>Folder does not exist.</source>
        <translation>O cartafol non existe.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1241"/>
        <source>Folder is not readable.</source>
        <translation>O cartafol non se pode ler.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1252"/>
        <source>Failure</source>
        <translation>Fallo</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1252"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>Produciuse un fallo ao explorar o cartafol &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1306"/>
        <location filename="../gui/options_imp.cpp" line="1308"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1306"/>
        <location filename="../gui/options_imp.cpp" line="1308"/>
        <source>Choose an IP filter file</source>
        <translation>Seleccionar un ficheiro para os filtros de ip</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1375"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1387"/>
        <source>SSL Key</source>
        <translation>Chave SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1420"/>
        <source>Parsing error</source>
        <translation>Erro de análise</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1420"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Produciuse un fallo ao analizar o filtro Ip indicado</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1422"/>
        <source>Successfully refreshed</source>
        <translation>Actualizado correctamente</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1422"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analizouse correctamente o filtro IP indicado: aplicáronse %1 regras.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1510"/>
        <source>Invalid key</source>
        <translation>Chave incorrecta</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1510"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta non é unha chave SSL correcta.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1526"/>
        <source>Invalid certificate</source>
        <translation>Certificado incorrecto</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1526"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este non é un certificado SSL correcto.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1536"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>A hora de inicio e de remate teñen que ser distintas.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1539"/>
        <source>Time Error</source>
        <translation>Erro de hora</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Previsualizar a selección</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="26"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Os seguintes ficheiros admiten vista previa, seleccione un deles:</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="61"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="68"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>
