<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ca">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="21"/>
        <source>About qBittorrent</source>
        <translation>Quant a qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="83"/>
        <source>About</source>
        <translation>Quant a</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="216"/>
        <location filename="../gui/about.ui" line="293"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="240"/>
        <location filename="../gui/about.ui" line="281"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="228"/>
        <location filename="../gui/about.ui" line="312"/>
        <source>E-mail:</source>
        <translation>Correu electrònic:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="262"/>
        <source>Greece</source>
        <translation>Grècia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="341"/>
        <source>Current maintainer</source>
        <translation>Mantenidor actual</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="354"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="412"/>
        <source>Libraries</source>
        <translation>Llibreries</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="424"/>
        <source>This version of qBittorrent was built against the following libraries:</source>
        <translation>Aquesta versió de qBittorrent va ser construïda en base a les següents llibreries:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="184"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="382"/>
        <source>Translation</source>
        <translation>Traducció</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="399"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="365"/>
        <source>Thanks to</source>
        <translation>Gràcies a</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="29"/>
        <source>Save as</source>
        <translation>Desa com a</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="53"/>
        <source>Browse...</source>
        <translation>Explora...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="62"/>
        <source>Set as default save path</source>
        <translation>Defineix com a camí per defecte de desada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="72"/>
        <source>Never show again</source>
        <translation>No ho tornis a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Torrent settings</source>
        <translation>Configuració de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="95"/>
        <source>Start torrent</source>
        <translation>Inicia Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="126"/>
        <source>Skip hash check</source>
        <translation>Omet comprovació de funció resum (hash)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="133"/>
        <source>Set as default label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="143"/>
        <source>Torrent Information</source>
        <translation>Informació del Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="151"/>
        <source>Size:</source>
        <translation>Mida:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="191"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="205"/>
        <source>Info Hash:</source>
        <translation>Informació de la funció resum (hash)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="296"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="301"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="306"/>
        <source>Maximum</source>
        <translation>Màxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="311"/>
        <source>Do not download</source>
        <translation>No ho baixis</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="172"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="646"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada-sortida</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="172"/>
        <source>The torrent file does not exist.</source>
        <translation>L&apos;arxiu Torrent no existeix.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="180"/>
        <source>Invalid torrent</source>
        <translation>Torrent invàlid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="180"/>
        <source>Failed to load the torrent: %1</source>
        <translation>No ha estat possible carregar el Torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="192"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="220"/>
        <source>Already in download list</source>
        <translation>Ja és a la llista de baixades</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="340"/>
        <source>Free disk space: %1</source>
        <translation>Espai disponible en disc: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="672"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="673"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="681"/>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="209"/>
        <source>Invalid magnet link</source>
        <translation>Enllaç imant invàlid.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="192"/>
        <source>Torrent is already in download list. Trackers were merged.</source>
        <translation>El Torrent ja és a la llista de baixades. Els rastrejadors han estat fusionats.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="195"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="223"/>
        <source>Cannot add torrent</source>
        <translation>No es pot afegir el Torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="195"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>No s&apos;ha pogut afegir aquest Torrent. Potser està en estat d&apos;addició.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="209"/>
        <source>This magnet link was not recognized</source>
        <translation>Aquest enllaç imant no és reconegut.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="220"/>
        <source>Magnet link is already in download list. Trackers were merged.</source>
        <translation>El Torrent ja és a la llista de baixades. Els rastrejadors han estat fusionats.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="223"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>No s&apos;ha pogut afegir aquest Torrent. Potser ja s&apos;està afegint.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="232"/>
        <source>Magnet link</source>
        <translation>Enllaç imant</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="239"/>
        <source>Retrieving metadata...</source>
        <translation>Rebent metadades...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="338"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="369"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="377"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="379"/>
        <source>Choose save path</source>
        <translation>Seleccioneu camí de desada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="428"/>
        <source>Rename the file</source>
        <translation>Reanomena l&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="429"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="433"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="458"/>
        <source>The file could not be renamed</source>
        <translation>L&apos;arxiu no es pot reanomenar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="434"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>Aquest nom d&apos;arxiu conté caràcters prohibits, escolliu un de diferent.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="459"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="492"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja és en ús en aquesta carpeta. Utilitzeu un de diferent.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="491"/>
        <source>The folder could not be renamed</source>
        <translation>La carpeta no pot ser reanomenada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="548"/>
        <source>Rename...</source>
        <translation>Reanomena...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="552"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="647"/>
        <source>Invalid metadata</source>
        <translation>Metadades no vàlides</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="654"/>
        <source>Parsing metadata...</source>
        <translation>Analitzant metadades...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="658"/>
        <source>Metadata retrieval complete</source>
        <translation>Recuperació de metadades completada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="718"/>
        <source>Download Error</source>
        <translation>Error de baixada</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.h" line="219"/>
        <source>Disk write cache size</source>
        <translation>Mida de la memòria cau d&apos;escriptura del disc</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="201"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="239"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Ports de sortida (Min) [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="244"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Ports de sortida (Max) [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="247"/>
        <source>Recheck torrents on completion</source>
        <translation>Verifica Torrents completats</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="253"/>
        <source>Transfer list refresh interval</source>
        <translation>Interval d&apos;actualització de la llista de transferència</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="252"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Setting</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="80"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="199"/>
        <source> (auto)</source>
        <translation>(auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="224"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="225"/>
        <source>Disk cache expiry interval</source>
        <translation>Interval d&apos;expiració de la memòria cau del disc</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="228"/>
        <source>Enable OS cache</source>
        <translation>Habilita memòria cau del sistema operatiu</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="233"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="256"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Resol països en xarxa de punt a punt (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="259"/>
        <source>Resolve peer host names</source>
        <translation>Resol noms d&apos;hostes en xarxa de punt a punt</translation>
    </message>
    <message>
        <source>Maximum number of half-open connections [0: Disabled]</source>
        <translation type="obsolete">Capacitat màxima de connexions obertes [0: Desactivat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="267"/>
        <source>Strict super seeding</source>
        <translation>Sembra super estricta</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="287"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interfície de xarxa (requereix reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="290"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Contacta en adreça IPv6 (requereix reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="315"/>
        <source>Confirm torrent recheck</source>
        <translation>Comfirma la re-comprovació del Torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="318"/>
        <source>Exchange trackers with other peers</source>
        <translation>Intercanvia rastrejadors amb altres punts de la xarxa</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="321"/>
        <source>Always announce to all trackers</source>
        <translation>Comunica sempre amb tots els rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="269"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Qualsevol interfície</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="234"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Desa l&apos;interval de reprenció de dades</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="264"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="293"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Adreça IP per a notificar als rastrejadors (requereix reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="296"/>
        <source>Display program on-screen notifications</source>
        <translation>Mostra notificacions en pantalla</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="299"/>
        <source>Enable embedded tracker</source>
        <translation>Habilita rastrejador integrat</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="304"/>
        <source>Embedded tracker port</source>
        <translation>Port d&apos;integració del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="307"/>
        <source>Check for software updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.h" line="311"/>
        <source>Use system icon theme</source>
        <translation>Utilitza icones del tema del sistema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="105"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciat</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="262"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="263"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Per a controlar qBittorrent, accediu a l&apos;interfície web a http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="264"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>El nom d&apos;usuari de l&apos;administrador de l&apos;interfície web és: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="267"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contrasenya de l&apos;administrador de l&apos;interfície web encara és l&apos;original: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="268"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Això és un risc de seguretat, considereu canviar la vostra contrasenya a la configuració del programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="442"/>
        <source>Saving torrent progress...</source>
        <translation>Desant el progrés del Torrent...</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="208"/>
        <source>Save to:</source>
        <translation>Desa a:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="26"/>
        <source>Enable Automated RSS Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="48"/>
        <source>Download Rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="88"/>
        <source>Rule Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="94"/>
        <source>Use Regular Expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="103"/>
        <source>Must Contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="110"/>
        <source>Must Not Contain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="117"/>
        <source>Episode Filter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="180"/>
        <source>Assign Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="196"/>
        <source>Save to a Different Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="236"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="246"/>
        <source> days</source>
        <translation>dies</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="276"/>
        <source>Add Paused:</source>
        <translation>Afegeix pausada:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="284"/>
        <source>Use global settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="289"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="294"/>
        <source>Never</source>
        <translation type="unfinished">Mai</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="315"/>
        <source>Apply Rule to Feeds:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="337"/>
        <source>Matching RSS Articles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>&amp;Import...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="369"/>
        <source>&amp;Export...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Emparella articles basant-se en el filtre d&apos;episodis.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="77"/>
        <source>Example: </source>
        <translation>Exemple:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="78"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>emparellarà 2, 5 i 8 a través del 15 i 30 i els propers episodis de la primera temporada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Episode filter rules: </source>
        <translation>Regles del filtre d&apos;episodis:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="79"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada ha de ser un valor diferent de zero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Episode number is a mandatory non-zero value</source>
        <translation>El número d&apos;episodi ha de ser un valor diferent de zero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Filter must end with semicolon</source>
        <translation>El filtre ha d&apos;acabar en punt i coma</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Són suportats tres tipus de rangs d&apos;episodis:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Un sol nombre: &lt;b&gt;1x25;&lt;b&gt; emparella l&apos;episodi 25 de la temporada u</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Rang normal: &lt;b&gt;1x25-40;&lt;b&gt; adjunta de l&apos;episodi 25 al 40 de la primera temporada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="85"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one</source>
        <translation>Rang infinit: &lt;b&gt;1x25-;&lt;/b&gt; adjunta l&apos;episodi 25 i els propers de la primera temporada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="266"/>
        <source>Last Match: %1 days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="268"/>
        <source>Last Match: Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>New rule name</source>
        <translation>Nova regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Escriviu el nom de la nova regla de baixada.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="365"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="483"/>
        <source>Rule name conflict</source>
        <translation>Conflicte amb el nom de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="365"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="483"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ja existena una regla amb aquest nom, si us plau, trieu un altre nom.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Esteu segur que voleu eliminar la regla de baixada anomenada &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="385"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Segur que voleu eliminar les normes de descàrrega seleccionada?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmar eliminar regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="402"/>
        <source>Destination directory</source>
        <translation>Directori de destinació</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="410"/>
        <source>Invalid action</source>
        <translation>Acció no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="410"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La llista està buida, no hi ha res per exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="414"/>
        <source>Where would you like to save the list?</source>
        <translation>On voleu desar la llista?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="414"/>
        <source>Rules list (*.rssrules)</source>
        <translation>Llista de regles (*.rssrules)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada-sortida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="419"/>
        <source>Failed to create the destination file</source>
        <translation>No s&apos;ha pogut crear l&apos;arxiu de destí</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>Please point to the RSS download rules file</source>
        <translation>Si us plau, seleccioneu les normes de descàrrega de canals RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>Rules list</source>
        <translation>Llista de regles</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <source>Import Error</source>
        <translation>Error al importar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <source>Failed to import the selected rules file</source>
        <translation>No s&apos;ha pogut importar el fitxer de la regla seleccionada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="442"/>
        <source>Add new rule...</source>
        <translation>Afegir nova regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>Delete rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="450"/>
        <source>Rename rule...</source>
        <translation>Reanomena regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="452"/>
        <source>Delete selected rules</source>
        <translation>Eliminar regles seleccionades</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Rule renaming</source>
        <translation>Regla renombrada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Please type the new rule name</source>
        <translation>Si us plau, escriviu el nom de la nova regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="581"/>
        <source>Regex mode: use Perl-like regular expressions</source>
        <translation>Mode Regex: utilitza Perl-like en expressions regulars</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="585"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;Whitespaces count as AND operators&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Ús de comodins: es pot usar&lt;ul&gt;&lt;li&gt;? perquè coincideixi amb qualsevol caràcter individual&lt;/li&gt;&lt;li&gt;* per fer coincidir zero o més dels caràcters&lt;/li&gt;&lt;li&gt; com Espais en blanc i&lt;/li&gt;&lt;/ul&gt; per al operadore AND</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="587"/>
        <source>Wildcard mode: you can use&lt;ul&gt;&lt;li&gt;? to match any single character&lt;/li&gt;&lt;li&gt;* to match zero or more of any characters&lt;/li&gt;&lt;li&gt;| is used as OR operator&lt;/li&gt;&lt;/ul&gt;</source>
        <translation>Ús de comodins: es pot usar&lt;ul&gt;&lt;li&gt;? perquè coincideixi amb qualsevol caràcter individual&lt;/li&gt;&lt;li&gt;* per fer coincidir zero o més dels caràcters&lt;/li&gt;&lt;li&gt; com Espais en blanc i&lt;/li&gt;&lt;/ul&gt; per al operadore OR</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="173"/>
        <source>Peer ID: </source>
        <translation>Identitat del parell:</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="316"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>La HTTP de l&apos;usuari és %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="343"/>
        <source>Anonymous mode [ON]</source>
        <translation>Mode anònim [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="345"/>
        <source>Anonymous mode [OFF]</source>
        <translation>Mode anònim [Apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="536"/>
        <source>PeX support [ON]</source>
        <translation>Suport per a PeX [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="538"/>
        <source>PeX support [OFF]</source>
        <translation>Suport PeX [Apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="540"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>És necessari reiniciar per activar suport PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="545"/>
        <source>Local Peer Discovery support [ON]</source>
        <translation>Suport per a trobar parells locals [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="549"/>
        <source>Local Peer Discovery support [OFF]</source>
        <translation>Suport per trobar parells locals [Apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="562"/>
        <source>Encryption support [ON]</source>
        <translation>Suport per a l&apos;encriptació [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <source>Encryption support [FORCED]</source>
        <translation>Suport per a l&apos;encriptació [Forçat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="572"/>
        <source>Encryption support [OFF]</source>
        <translation>Suport per a l&apos;encriptació [Apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="650"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Rastrejador integrat [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="652"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error en iniciar el rastrejador integratt!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="655"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Rastrejador integrat [Apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="693"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removing...</source>
        <translation>%1 ha assolit el ràtio màxim establert. Eliminant...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="699"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Pausing...</source>
        <translation>%1 ha assolit el ràtio màxim establert. Pausant...</translation>
    </message>
    <message>
        <source>Error: Could not create torrent export directory: &apos;%1&apos;</source>
        <translation type="obsolete">Error: No s&apos;ha pogut crear el directori d&apos;exportació Torrent: &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Error: could not export torrent &apos;%1&apos;, maybe it has not metadata yet.</source>
        <translation type="obsolete">Error: no s&apos;ha pogut exportar el Torrent &apos;%1&apos;, potser encara no te metadades.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>ONLINE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1396"/>
        <source>OFFLINE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1408"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1692"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>No s&apos;han pogut descodificar &apos;%1&apos; arxius Torrent.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1798"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Descàrrega recursiva d&apos;arxiu %1 integrada al Torrent %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2109"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>No s&apos;ha pogut desar &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2214"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>perquè %1 es troba inhabilitat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2217"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>perquè %1 es troba inhabilitat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2235"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Ha fallat la cerca de llavor per a la URL: %1, missatge: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="812"/>
        <source>&apos;%1&apos; was removed from transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; ha estat eliminat de la llista de transferència i del disc.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="814"/>
        <source>&apos;%1&apos; was removed from transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; ha estat eliminat de la llista de transferència.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="973"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Baixant &apos;%1&apos;, espereu...</translation>
    </message>
    <message>
        <source>Torrent Export: torrent is invalid, skipping...</source>
        <translation type="obsolete">Exportació del Torrent: el Torrent no és vàlid, ometent...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1242"/>
        <source>DHT support [ON]</source>
        <translation>Suport DHT [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1247"/>
        <source>DHT support [OFF]. Reason: %1</source>
        <translation>Suport DHT [Apagat]. Raó: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1255"/>
        <source>DHT support [OFF]</source>
        <translation>Suport DHT [Encès]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="165"/>
        <location filename="../base/bittorrent/session.cpp" line="1478"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent està intentant contactar a algun port interfície: %1</translation>
    </message>
    <message>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation type="obsolete">qBittorrent ha fallat en intentar contactar a algun port interfície: %1. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1431"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfície de la xarxa definida no és vàlida:%1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="169"/>
        <location filename="../base/bittorrent/session.cpp" line="1489"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent està intentant contactar a l&apos;interfície %1 del port: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1455"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent no ha trobat una adreça local %1 per a contactar</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1482"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation type="unfinished">qBittorrent ha fallat en intentar contactar a algun port interfície: %1. Raó: %2. {1.?}</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1603"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>El rastrejador &apos;%1&apos; ha estat afegit al Torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1613"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>El rastrejador &apos;%1&apos; ha estat eliminat del Torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1628"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>La llavor URL &apos;%1&apos; ha estat afegida al Torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1634"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>La llavor URL &apos;%1&apos; ha estat eliminada del Torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1914"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Impossible reprendre el Torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1937"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analitzat satisfactòriament el filtre IP: %1 regles han estat aplicades.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1943"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Ha fallat l&apos;anàlisi del filtre IP proporcionat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2071"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>No s&apos;ha pogut afegir el Torrent: &apos;%1&apos;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2092"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; reprès. (represa ràpida)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2123"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; afegit a la llista de baixades.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2178"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>S&apos;ha produït un error d&apos;entrada-sortida, &apos;%1&apos; pausat. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2186"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Ha fallat el mapatge del port, missatge: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2192"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapatge del port reeixit, missatge: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2202"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>degut al filtre IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2205"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>degut al filtre de ports.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2208"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>degut a restriccions mixtes i2p.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2211"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>perquè te un port baix.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2249"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent està contactant satisfactòriament en la interfície %1 del port: %2%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2275"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation type="unfinished">qBittorrent ha fallat intentant contactar en la interfície %1 port: %2%3. Raó: %4. {1 ?} {2/%3.?}</translation>
    </message>
    <message>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use</comment>
        <translation type="obsolete">qBittorrent ha fallat intentant contactar en la interfície %1 port: %2%3. Raó: %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2284"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externa: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1313"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>No s&apos;ha pogut moure el Torrent: &apos;%1&apos;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1454"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>La mida de l&apos;arxiu no coincideix amb el Torrent &apos;%1&apos;, pausat-lo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1460"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>S&apos;han negat les dades per a la represa ràpida del Torrent &apos;%1&apos;. Raó: %2. Comprovant de nou... </translation>
    </message>
</context>
<context>
    <name>CookiesDlg</name>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="14"/>
        <source>Cookies management</source>
        <translation>Administració de Cookies</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="36"/>
        <source>Key</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Clau</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.ui" line="41"/>
        <source>Value</source>
        <extracomment>As in Key/Value pair</extracomment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/rss/cookiesdlg.cpp" line="48"/>
        <source>Common keys for cookies are: &apos;%1&apos;, &apos;%2&apos;.
You should get this information from your Web browser preferences.</source>
        <translation>Les claus comunes per a les galetes són: &apos;%1&apos;, &apos;%2&apos;.
Podeu obtenir aquesta informació a les preferències del vostre navegador web.</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="48"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Esteu segur que voleu eliminar &apos;%1&apos; de la llista de transferència?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="50"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Esteu segur que voleu eliminar aquests %1 Torrents de la llista de transferència?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>White: Missing pieces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Green: Partial pieces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="37"/>
        <source>Blue: Completed pieces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="27"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="33"/>
        <source>Blocked IPs</source>
        <translation>IPs bloquejades</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="101"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; ha estat blocat %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="103"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; ha estat bandejat</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="41"/>
        <source>RSS feeds</source>
        <translation>Canals RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="43"/>
        <source>Unread</source>
        <translation>No llegits</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="65"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="159"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="267"/>
        <source>I/O Error: Could not open ip filter file in read mode.</source>
        <translation>Error d&apos;entrada-sortida: No s&apos;ha pogut obrir l&apos;arxiu de filtres IP en mode lectura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="278"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="290"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="311"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="320"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="330"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="340"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="360"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Error d&apos;anàlisi: L&apos;arxiu de filtre no és un arxiu PeerGuardian P2B vàlid.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="101"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="131"/>
        <source>Unsupported database file size.</source>
        <translation>La mida de l&apos;arxiu de base de dades no és suportada.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Error de metadades: &apos;%1&apos; entrades no trobades.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="237"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Error de metadades: &apos;%1&apos; entrades tenen una escriptura invàlida.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="246"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versió de base de dades no suportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="253"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versió IP no suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Unsupported record size: %1</source>
        <translation>Mida de registre no suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="273"/>
        <source>Invalid database type: %1</source>
        <translation>Entrada de base de dades invàlida: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="294"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de dades corrupta: no s&apos;ha trobat secció de dades.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>File</source>
        <translation>Arxiu</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Download Torrents from their URL or Magnet link</source>
        <translation>Baixa Torrents des d&apos;URL o enllaç imant</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Only one link per line</source>
        <translation>Només un enllaç per línia</translation>
    </message>
    <message>
        <source>Download local torrent</source>
        <translation type="obsolete">Baixa Torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Download</source>
        <translation>Baixa</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de pujada ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de baixada ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de pujada alternatiu ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de baixada alternativa ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>El màxim de baixades actives ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>El màxim de pujades actives ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>El màxim de Torrents actius ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limiti de connexions ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limit de connexions per Torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim de pujades de ranures per Torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>No es poden desar les preferències del programa, probablement qBittorrent no és accessible.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>El port utilitzat per a connexions entrants ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>El port utilitzat per a la interfície d&apos;usuari web ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>No ha estat possible iniciar sessió, qBittorrent deu estar il·localitzable en aquests moments. </translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>Invalid Username or Password.</source>
        <translation>Nom d&apos;usuari o contrasenya incorrectes.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Password</source>
        <translation>Contrasenya</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Login</source>
        <translation>Inicia sessió</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>Upload Failed!</source>
        <translation>Pujada fallida!</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Original authors</source>
        <translation>Autors originals</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Upload limit:</source>
        <translation>Límit de pujada:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Download limit:</source>
        <translation>Límit de baixada:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Apply</source>
        <translation>Aplica</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Add</source>
        <translation>Afegeix</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Upload Torrents</source>
        <translation>Puja Torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>All</source>
        <translation>Tots</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Downloading</source>
        <translation>Baixant</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Seeding</source>
        <translation>Sembrant</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Completed</source>
        <translation>Completats</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="83"/>
        <source>Resumed</source>
        <translation>Represos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="84"/>
        <source>Paused</source>
        <translation>Pausats</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Active</source>
        <translation>Actius</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Inactive</source>
        <translation>Inactius</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Save files to location:</source>
        <translation type="unfinished">Desa els arxius en la seva ubicació:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Label:</source>
        <translation type="unfinished">Etiqueta:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Cookie:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Downloaded</source>
        <comment>Is the file downloaded or not?</comment>
        <translation>Baixat</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Logout</source>
        <translation>Tanca la sessió</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Upload local torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Esteu segur que voleu eliminar els Torrent seleccionats de la llista de transferències?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nom d&apos;Interfície d&apos;Usuari web ha de ser d&apos;almenys 3 caràcters.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>The Web UI password must be at least 3 characters long.</source>
        <translation>La contrasenya d&apos;Interfície d&apos;Usuari Web ha de ser d&apos;almenys 3 caràcters.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>qBittorrent client is not reachable</source>
        <translation>El client qBittorrent no és accessible</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>HTTP Server</source>
        <translation>Servidor HTTP</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>The following parameters are supported:</source>
        <translation>Els següents paràmetres són compatibles:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Torrent path</source>
        <translation>Ruta Torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Torrent name</source>
        <translation>Nom del Torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent s&apos;ha apagat.</translation>
    </message>
</context>
<context>
    <name>LabelFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Tots (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Unlabeled (0)</source>
        <translation>No etiquetats (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="214"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="260"/>
        <source>All (%1)</source>
        <comment>this is for the label filter</comment>
        <translation>Tots (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="217"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="235"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="263"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="268"/>
        <source>Unlabeled (%1)</source>
        <translation>No etiquetats (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="239"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="276"/>
        <source>%1 (%2)</source>
        <comment>label_name (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="330"/>
        <source>Add label...</source>
        <translation>Afegir etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="334"/>
        <source>Remove label</source>
        <translation>Elimina etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="335"/>
        <source>Remove unused labels</source>
        <translation>Elimina etiquetes no utilitzades</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="337"/>
        <source>Resume torrents</source>
        <translation>Reprendre els Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="338"/>
        <source>Pause torrents</source>
        <translation>Pausa els Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="339"/>
        <source>Delete torrents</source>
        <translation>Elimina els Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>New Label</source>
        <translation>Nova etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="366"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Invalid label name</source>
        <translation>Nom d&apos;etiqueta invàlid</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="372"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>No utilitzeu caràcters especials en el nom d&apos;etiqueta.</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../gui/lineedit/src/lineedit.cpp" line="37"/>
        <source>Clear the text</source>
        <translation>Esborra el text</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="47"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Clear</source>
        <translation>Neteja</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="66"/>
        <source>&amp;Tools</source>
        <translation>&amp;Eines</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="86"/>
        <source>&amp;File</source>
        <translation>&amp;Axiu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="56"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="70"/>
        <source>On Downloads &amp;Done</source>
        <translation>A Baixades &amp;Fet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="96"/>
        <source>&amp;View</source>
        <translation>&amp;Mostra</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="164"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcions...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reprendre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="197"/>
        <source>Torrent &amp;Creator</source>
        <translation>Torrent &amp;Creador</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="202"/>
        <source>Set Upload Limit...</source>
        <translation>Establiu límit de pujada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="207"/>
        <source>Set Download Limit...</source>
        <translation>Establiu límit de baixada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="217"/>
        <source>Set Global Download Limit...</source>
        <translation>Establiu límit de baixada global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="222"/>
        <source>Set Global Upload Limit...</source>
        <translation>Establiu límit de pujada global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="227"/>
        <source>Minimum Priority</source>
        <translation>Prioritat mínima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="235"/>
        <source>Top Priority</source>
        <translation>Prioritat màxima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Decrease Priority</source>
        <translation>Disminuir prioritat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="251"/>
        <source>Increase Priority</source>
        <translation>Incrementar prioritat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="262"/>
        <location filename="../gui/mainwindow.ui" line="265"/>
        <source>Alternative Speed Limits</source>
        <translation>Límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="273"/>
        <source>&amp;Top Toolbar</source>
        <translation>Barra d&apos;eines &amp;superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="276"/>
        <source>Display Top Toolbar</source>
        <translation>Mostra barra d&apos;eines superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="284"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>Mostra v&amp;elocitat a la barra de títol</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="287"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostra velocitat de transferència a la barra de títol</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="295"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="303"/>
        <source>Search &amp;Engine</source>
        <translation>&amp;Motor de cerca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="308"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>B&amp;loca qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="319"/>
        <source>&amp;Import Existing Torrent...</source>
        <translation>&amp;Importa Torrent existent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="322"/>
        <source>Import Torrent...</source>
        <translation>Importa Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="327"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;neu</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="335"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eprende Tot</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="348"/>
        <source>&amp;Log</source>
        <translation>&amp;Registre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="359"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Tanca qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="367"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspèn el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="375"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hiberna el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="383"/>
        <source>S&amp;hutdown System</source>
        <translation>A&amp;paga el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="391"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Inhabilitat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="406"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Estadístiques</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>Check for Updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="414"/>
        <source>Check for Program Updates</source>
        <translation>Cerca actualitzacions del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>&amp;About</source>
        <translation>&amp;Quant a</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Surt</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="179"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="184"/>
        <source>&amp;Delete</source>
        <translation>&amp;Elimina</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="340"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausa totes</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="151"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Afegeix arxiu Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="154"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="159"/>
        <source>E&amp;xit</source>
        <translation>T&amp;anca</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Opcions</translation>
    </message>
    <message>
        <source>Resume</source>
        <translation type="obsolete">Reprèn</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pausa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Elimina</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="192"/>
        <source>Open URL</source>
        <translation>Obre URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="212"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentació</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="311"/>
        <source>Lock</source>
        <translation>Bloca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <location filename="../gui/mainwindow.cpp" line="1293"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1480"/>
        <source>Check for program updates</source>
        <translation>Cerca actualitzacions del programa</translation>
    </message>
    <message>
        <source>Lock qBittorrent</source>
        <translation type="obsolete">Bloca qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="189"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Afegeix &amp;enllaç Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="330"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si us agrada qBittorrent, feu una donació!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="351"/>
        <location filename="../gui/mainwindow.cpp" line="1508"/>
        <source>Execution Log</source>
        <translation>Execució Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="478"/>
        <source>Clear the password</source>
        <translation>Neteja la contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="187"/>
        <source>Filter torrent list...</source>
        <translation>Filtra la llista de Torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="158"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Estableix contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="160"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Esborra contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="205"/>
        <source>Transfers</source>
        <translation>Transferint</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="343"/>
        <source>Torrent file association</source>
        <translation>Associació d&apos;arxius Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="344"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent no és l&apos;aplicació per defecte per obrir arxius torrent o enllaços imant.
¿Voleu que qBittorrent sigui el programa per defecte per gestionar aquests arxius?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="375"/>
        <source>Icons Only</source>
        <translation>Només icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="377"/>
        <source>Text Only</source>
        <translation>Només text</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="379"/>
        <source>Text Alongside Icons</source>
        <translation>Text al costat de les icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="381"/>
        <source>Text Under Icons</source>
        <translation>Text sota les icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="383"/>
        <source>Follow System Style</source>
        <translation>Seguir l&apos;estil del sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <location filename="../gui/mainwindow.cpp" line="792"/>
        <source>UI lock password</source>
        <translation>Contrasenya de bloqueig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <location filename="../gui/mainwindow.cpp" line="490"/>
        <location filename="../gui/mainwindow.cpp" line="792"/>
        <source>Please type the UI lock password:</source>
        <translation>Escriviu la contrasenya de bloqueig:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="467"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Com a mínim la contrasenya ha de tenir 3 caràcters</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="472"/>
        <source>Password update</source>
        <translation>Actualització de contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="472"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contrasenya de bloqueig de qBittorrent s&apos;ha actualitzat correctament</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="478"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Esteu segurs que voleu netejar la contrasenya?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="530"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="541"/>
        <source>Transfers (%1)</source>
        <translation>Transferències (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="632"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="632"/>
        <source>Failed to add torrent: %1</source>
        <translation>No ha estat possible afegir el Torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <source>Download completion</source>
        <translation>Descàrrega completada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="644"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error d&apos;entrada-sortida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="705"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmació descàrregues recursives</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="706"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="707"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="708"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="728"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="744"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat límit global de descàrrega</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="894"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="895"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="896"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Sempre sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1379"/>
        <source>Python found in %1</source>
        <translation>Python trobat en %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1394"/>
        <source>Old Python Interpreter</source>
        <translation>Intèrpret de Python antic</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1464"/>
        <source>qBittorrent Update Available</source>
        <translation>Actualització de qBittorrent disponible</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1474"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Ja feu servir la darrera versió de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1404"/>
        <source>Undetermined Python version</source>
        <translation>Versió de Python no determinada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; ha acabat de descarregar-se.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="644"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>S&apos;ha produït un error d&apos;entrada-sortida al Torrent &apos;%1&apos;.
Raó: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="705"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Aquest torrent &apos;%1&apos; conté arxius Torrent, vol seguir endavant amb la seva descàrrega?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>No s&apos;ha pogut baixar l&apos;arxiu en la URL &apos;%1&apos;, raó: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1394"/>
        <source>Your Python version %1 is outdated. Please upgrade to latest version for search engines to work. Minimum requirement: 2.7.0/3.3.0.</source>
        <translation>La versió de Python %1 no està actualitzada. Actualitzeu a la darrera versió per a que funcionin els motors de cerca. Mínim requerit: 2.7.0/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1404"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>No s&apos;ha pogut determinar la vostra versió de Python (%1). Motor de cerca inhabilitat.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1415"/>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta intèrpret Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1416"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Es requereix Python per a fer servir el motor de cerca i sembla que no el teniu instal·lat.
Voleu instal·lar-lo ara?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1427"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Es requereix Python per a fer servir el motor de cerca i sembla que no el teniu instal·lat.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1465"/>
        <source>A new version is available.
Update to version %1?</source>
        <translation>Hi ha una nova versió disponible.
Voleu actualitzar a la versió %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1475"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>No hi ha actualitzacions disponibles.
Esteu fent servir la darrera versió.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1479"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1577"/>
        <source>Checking for Updates...</source>
        <translation>Cercant actualitzacions...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1578"/>
        <source>Already checking for program updates in the background</source>
        <translation>Ja s&apos;estan cercant actualitzacions en segon terme</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1593"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python ha trobat en %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1646"/>
        <source>Download error</source>
        <translation>Error de baixada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1646"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>No ha estat possible baixar l&apos;instal·lador de Python, raó: 51.
Instal·leu-lo manualment.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="467"/>
        <location filename="../gui/mainwindow.cpp" line="806"/>
        <source>Invalid password</source>
        <translation>Contrasenya no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="508"/>
        <location filename="../gui/mainwindow.cpp" line="520"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>URL download error</source>
        <translation>error al baixar l&apos;URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="806"/>
        <source>The password is invalid</source>
        <translation>La contrasenya no és vàlida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1188"/>
        <location filename="../gui/mainwindow.cpp" line="1195"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Velocitat de baixada: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1191"/>
        <location filename="../gui/mainwindow.cpp" line="1197"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Velocitat de pujada: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1202"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[B: %1, P: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1293"/>
        <source>Hide</source>
        <translation>Amaga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="891"/>
        <source>Exiting qBittorrent</source>
        <translation>Tancant qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="892"/>
        <source>Some files are currently transferring.
Are you sure you want to quit qBittorrent?</source>
        <translation>Alguns arxius encara s&apos;estan transferint.
Esteu segur que voleu tancar qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1033"/>
        <source>Open Torrent Files</source>
        <translation>Obre arxius Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1034"/>
        <source>Torrent Files</source>
        <translation>Arxius Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1069"/>
        <source>Options were saved successfully.</source>
        <translation>Opcions desades correctament.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="200"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>El vostre DNS dinàmic ha estat correctament actualitzat.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="204"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error de DNS dinàmica: El servei no està disponible temporalment, nou reintent en 30 minuts.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="213"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;amfitrió proporcionat no existeix en el compte especificat.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="218"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error DNS dinàmica: nom d&apos;usuari/contrasenya no vàlides.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="223"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: qBittorrent ha estat inclòs en la Llista Negra, si us plau, informar d&apos;això a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: %1 ha estat rebutjat pel servei, si us plau, informe d&apos;aquest error a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="235"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error de DNS dinàmica: El seu nom d&apos;usuari ha estat blocat degut a un abús.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="256"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari subministrat és massa curt.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="267"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari proporcionat és massa curt.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="278"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari subministrat és massa curt.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="104"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada-sortida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="117"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>La mida d&apos;aquest arxiu és de %1. Això excedeix el límit de baixada de %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="186"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redirecció a una URL imant no esperada.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="432"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Base de dades GeoIP carregada. Tipus: %1. Temps de compilació: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="453"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>No s&apos;ha pogut carregar la base de dades GeoIP. Raó: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="141"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="142"/>
        <source>Asia/Pacific Region</source>
        <translation>Regió Àsia-Pacífic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="143"/>
        <source>Europe</source>
        <translation>Europa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Emirats Àrabs Units</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afganistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua i Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Netherlands Antilles</source>
        <translation>Antilles Neerlandeses</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Antarctica</source>
        <translation>Antàrtica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>American Samoa</source>
        <translation>Samoa Nord-americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Austria</source>
        <translation>Àustria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>Azerbaidjan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bòsnia i Hercegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>Bangladeix</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Bèlgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgària</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>Benín</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bolivia</source>
        <translation>Bolívia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bahamas</source>
        <translation>Bahames</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bouvet Island</source>
        <translation>Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Belarus</source>
        <translation>Bielorússia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Canada</source>
        <translation>Canadà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Illes Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Congo, República Democràtica del</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Central African Republic</source>
        <translation>República Centreafricana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Switzerland</source>
        <translation>Suïssa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Cote D&apos;Ivoire</source>
        <translation>Costa d&apos;Ivori</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Cook Islands</source>
        <translation>Illes Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Chile</source>
        <translation>Xile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cameroon</source>
        <translation>Camerun</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>China</source>
        <translation>Xina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Colombia</source>
        <translation>Colòmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Cape Verde</source>
        <translation>Cap Verd</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Christmas Island</source>
        <translation>Illa Christmas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cyprus</source>
        <translation>Xipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Czech Republic</source>
        <translation>República Txeca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Germany</source>
        <translation>Alemanya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Algeria</source>
        <translation>Algèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Ecuador</source>
        <translation>Equador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Estonia</source>
        <translation>Estònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Egypt</source>
        <translation>Egipte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Western Sahara</source>
        <translation>Sahara Occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Spain</source>
        <translation>Espanya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Ethiopia</source>
        <translation>Etiòpia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Finland</source>
        <translation>Finlàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Illes Malvines (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronèsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Faroe Islands</source>
        <translation>Illes Fèroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>France, Metropolitan</source>
        <translation>França metropolitana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>United Kingdom</source>
        <translation>Regne Unit</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Georgia</source>
        <translation>Geòrgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>French Guiana</source>
        <translation>Guaiana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Greenland</source>
        <translation>Groenlàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Gambia</source>
        <translation>Gàmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe (França)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Equatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Greece</source>
        <translation>Grècia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Illes Geòrgia del Sud i Sandwich del Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Illes Heard i McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Honduras</source>
        <translation>Hondures</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Croatia</source>
        <translation>Croàcia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Haiti</source>
        <translation>Haití</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Hungary</source>
        <translation>Hongria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Indonesia</source>
        <translation>Indonèsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>India</source>
        <translation>Índia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territori Britànic de l&apos;Oceà Índic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Iran</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Iceland</source>
        <translation>Islàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Italy</source>
        <translation>Itàlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Jordan</source>
        <translation>Jordània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Japan</source>
        <translation>Japó</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Kenya</source>
        <translation>Kènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Kyrgyzstan</source>
        <translation>Kirguizistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Cambodia</source>
        <translation>Cambodja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint Christopher i Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Corea del Nord</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Korea, Republic of</source>
        <translation>Corea del Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Cayman Islands</source>
        <translation>Illes Caiman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Lebanon</source>
        <translation>Líban</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Saint Lucia</source>
        <translation>Saint Lucia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Liberia</source>
        <translation>Libèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Lithuania</source>
        <translation>Lituània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Latvia</source>
        <translation>Letònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Libyan Arab Jamahiriya</source>
        <translation>Líbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Morocco</source>
        <translation>Marroc</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Monaco</source>
        <translation>Mònaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Moldova, Republic of</source>
        <translation>Moldàvia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Marshall Islands</source>
        <translation>Illes Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Macedonia</source>
        <translation>Macedònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Mongolia</source>
        <translation>Mongòlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Macau</source>
        <translation>Macau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Northern Mariana Islands</source>
        <translation>Illes Mariannes Septentrionals</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Mauritania</source>
        <translation>Mauritània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mauritius</source>
        <translation>Maurici</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Maldives</source>
        <translation>Maldives</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mexico</source>
        <translation>Mèxic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Malaysia</source>
        <translation>Malàsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Mozambique</source>
        <translation>Moçambic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Namibia</source>
        <translation>Namíbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>New Caledonia</source>
        <translation>Nova Caledònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Norfolk Island</source>
        <translation>Illa Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Nigeria</source>
        <translation>Nigèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Netherlands</source>
        <translation>Països Baixos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>New Zealand</source>
        <translation>Nova Zelanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Panama</source>
        <translation>Panamà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>French Polynesia</source>
        <translation>Polinèsia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Papua New Guinea</source>
        <translation>Papua Nova Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Philippines</source>
        <translation>Filipines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Poland</source>
        <translation>Polònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint-Pierre i Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Pitcairn Islands</source>
        <translation>Illes Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Palestinian Territory</source>
        <translation>Palestina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Reunion</source>
        <translation>Reunió</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Romania</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Russian Federation</source>
        <translation>Federació Russa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Saudi Arabia</source>
        <translation>Aràbia Saudí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Solomon Islands</source>
        <translation>Illes Solomon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Sudan</source>
        <translation>Sudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Sweden</source>
        <translation>Suècia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Saint Helena</source>
        <translation>Santa Helena</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Slovenia</source>
        <translation>Eslovènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard i Jan mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Slovakia</source>
        <translation>Eslovàquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Somalia</source>
        <translation>Somàlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Sao Tome and Principe</source>
        <translation>São Tomé i Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Syrian Arab Republic</source>
        <translation>República Àrab Siriana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Swaziland</source>
        <translation>Swazilàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Turks and Caicos Islands</source>
        <translation>Illes Turks i Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Chad</source>
        <translation>Txad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>French Southern Territories</source>
        <translation>Terres Australs i Antàrtiques Franceses</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Thailand</source>
        <translation>Tailàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Tajikistan</source>
        <translation>Tadjikistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Tunisia</source>
        <translation>Tuníssia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Timor-Leste</source>
        <translation>Timor Oriental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Turkey</source>
        <translation>Turquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinitat i Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Ukraine</source>
        <translation>Ucraïna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Illes Perifèriques Menors dels EUA</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>United States</source>
        <translation>Estats Units</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Ciutat del Vaticà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Saint Vincent i les Grenadines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Venezuela</source>
        <translation>Veneçuela</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Virgin Islands, British</source>
        <translation>Illes Verges Britàniques</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Illes Verges Nord-americanes</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Vietnam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis i Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Yemen</source>
        <translation>Iemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Serbia</source>
        <translation>Sèrbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>South Africa</source>
        <translation>Sud Àfrica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Zambia</source>
        <translation>Zàmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Anonymous Proxy</source>
        <translation>Servidor intermediari anònim</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Satellite Provider</source>
        <translation>Proveïdor satèl·lit</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Other</source>
        <translation>Altres</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Aland Islands</source>
        <translation>Illes Åland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Isle of Man</source>
        <translation>Illa de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Saint Barthelemy</source>
        <translation>Saint-Barthélemy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <source>Saint Martin</source>
        <translation>Sant Martí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="421"/>
        <source>Could not uncompress GeoIP database file.</source>
        <translation>No ha estat possible descomprimir l&apos;arxiu de base de dades GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="442"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>No ha estat possible desar l&apos;arxiu de base de dades GeoIP baixat.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="445"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Base de dades GeoIP actualitzada correctament.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="460"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>No s&apos;ha pogut baixar la base de dades GeoIP. Raó: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="110"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Suport UPnP / NAT-PMP [Encès]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="119"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Suport UPnP / NAT-PMP [Apagat]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="501"/>
        <source>Email Notification Error:</source>
        <translation>Error de notificació de correu electrònic:</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="293"/>
        <source>interested(local) and choked(peer)</source>
        <translation type="unfinished">interessats (local) i muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="299"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation type="unfinished">interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="308"/>
        <source>interested(peer) and choked(local)</source>
        <translation type="unfinished">interessats (parells) i muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="314"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation type="unfinished">interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="322"/>
        <source>optimistic unchoke</source>
        <translation type="unfinished">unchoke optimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="329"/>
        <source>peer snubbed</source>
        <translation type="unfinished">parell desairat</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="336"/>
        <source>incoming connection</source>
        <translation type="unfinished">connexió entrant</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="343"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation type="unfinished">no interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="350"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation type="unfinished">no interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="357"/>
        <source>peer from PEX</source>
        <translation type="unfinished">parell de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="364"/>
        <source>peer from DHT</source>
        <translation type="unfinished">parell de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="371"/>
        <source>encrypted traffic</source>
        <translation type="unfinished">trànsit encriptat</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="378"/>
        <source>encrypted handshake</source>
        <translation type="unfinished">salutació encriptada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="393"/>
        <source>peer from LSD</source>
        <translation type="unfinished">parell de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="70"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>Flags</source>
        <translation>Banderes</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Client</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocitat de Baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocitat de Pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Descarregat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevancia </translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="168"/>
        <source>Add a new peer...</source>
        <translation>Afegir nou Parell...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="174"/>
        <source>Copy selected</source>
        <translation>Copia seleccionats</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="176"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="214"/>
        <source>Ban peer permanently</source>
        <translation>Prohibició permanent de Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="188"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Afegint manualment el parell &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="192"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>No s&apos;ha pogut afegir el parell &apos;%1&apos; a aquest Torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="225"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Bandejant manualment el parell &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="198"/>
        <source>Peer addition</source>
        <translation>Incorporar Parell</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="196"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>No s&apos;han pogut afegir alguns parells. Reviseu el registre per a més detalls.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="198"/>
        <source>The peers were added to this torrent.</source>
        <translation>Els parells ha estat afegits al Torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="214"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Esteu segur que voleu bandejar permanentment els parells seleccionats?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="215"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="215"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>interested(local) and choked(peer)</source>
        <translation type="obsolete">interessats (local) i muts (parells)</translation>
    </message>
    <message>
        <source>interested(local) and unchoked(peer)</source>
        <translation type="obsolete">interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <source>interested(peer) and choked(local)</source>
        <translation type="obsolete">interessats (parells) i muts (local)</translation>
    </message>
    <message>
        <source>interested(peer) and unchoked(local)</source>
        <translation type="obsolete">interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <source>optimistic unchoke</source>
        <translation type="obsolete">unchoke optimista</translation>
    </message>
    <message>
        <source>peer snubbed</source>
        <translation type="obsolete">parell desairat</translation>
    </message>
    <message>
        <source>incoming connection</source>
        <translation type="obsolete">connexió entrant</translation>
    </message>
    <message>
        <source>not interested(local) and unchoked(peer)</source>
        <translation type="obsolete">no interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <source>not interested(peer) and unchoked(local)</source>
        <translation type="obsolete">no interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <source>peer from PEX</source>
        <translation type="obsolete">parell de PEX</translation>
    </message>
    <message>
        <source>peer from DHT</source>
        <translation type="obsolete">parell de DHT</translation>
    </message>
    <message>
        <source>encrypted traffic</source>
        <translation type="obsolete">trànsit encriptat</translation>
    </message>
    <message>
        <source>encrypted handshake</source>
        <translation type="obsolete">salutació encriptada</translation>
    </message>
    <message>
        <source>peer from LSD</source>
        <translation type="obsolete">parell de LSD</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="58"/>
        <source>No peer entered</source>
        <translation>No s&apos;ha entrat cap parell</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="59"/>
        <source>Please type at least one peer.</source>
        <translation>Si us plau escriviu almenys un parell.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="69"/>
        <source>Invalid peer</source>
        <translation>Parell invàlid</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="70"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>El parell &apos;%1&apos; no és vàlid.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>White: Unavailable pieces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="39"/>
        <source>Blue: Available pieces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../gui/options.ui" line="69"/>
        <source>Downloads</source>
        <translation>Baixats</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="80"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="91"/>
        <source>Speed</source>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="113"/>
        <source>Web UI</source>
        <translation>IU Web</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="124"/>
        <source>Advanced</source>
        <translation>Avançat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="209"/>
        <source>(Requires restart)</source>
        <translation>(Es necessita reiniciar qBittorrent)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="253"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Usar colors alterns en la llista de Transferència</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="295"/>
        <location filename="../gui/options.ui" line="321"/>
        <source>Start / Stop Torrent</source>
        <translation>Inicia/Atura Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="305"/>
        <location filename="../gui/options.ui" line="331"/>
        <source>No action</source>
        <translation>Sense acció</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="701"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Afegeix .!qB com extensió per als fitxers incomplets</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="804"/>
        <source>Copy .torrent files to:</source>
        <translation>Copia arxius .torrent a:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1121"/>
        <source>Connections Limits</source>
        <translation>Límits de connexió</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1274"/>
        <source>Proxy Server</source>
        <translation>Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1577"/>
        <source>Global Rate Limits</source>
        <translation>Límits globals de Ràtio</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1879"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar límit de ràtio per transport sobrecarregat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1672"/>
        <source>Schedule the use of alternative rate limits</source>
        <translation>Programar l&apos;ús de límits de ràtio alternativa</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1684"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1708"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1993"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar Trobat Local de Pares per trobar més parells</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2005"/>
        <source>Encryption mode:</source>
        <translation>Mode de xifrat:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2013"/>
        <source>Prefer encryption</source>
        <translation>Preferència de xifrat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2018"/>
        <source>Require encryption</source>
        <translation>Necessiten xifrat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2023"/>
        <source>Disable encryption</source>
        <translation>Deshabilitar xifrat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2058"/>
        <source> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;http://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Més informació&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2101"/>
        <source>Maximum active downloads:</source>
        <translation>Màxim d&apos;arxius Baixant:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2121"/>
        <source>Maximum active uploads:</source>
        <translation>Màxim d&apos;arxius Pujant:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2141"/>
        <source>Maximum active torrents:</source>
        <translation>Màxim d&apos;arxius Torrents:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="537"/>
        <source>When adding a torrent</source>
        <translation>En afegir un Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="58"/>
        <source>Behavior</source>
        <translation>Comportament</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="173"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="553"/>
        <source>Display torrent content and some options</source>
        <translation>Mostrar el contingut del Torrent i opcions</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="994"/>
        <source>Run external program on torrent completion</source>
        <translation>Executar un programa extern en acabar el torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1057"/>
        <source>Port used for incoming connections:</source>
        <translation>Port utilitzat per a connexions entrants:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1077"/>
        <source>Random</source>
        <translation>Aleatori</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1127"/>
        <source>Global maximum number of connections:</source>
        <translation>Nombre global màxim de connexions:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1153"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Nombre màxim de connexions per Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1176"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Nombre màxim de ranures de pujada per Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1599"/>
        <location filename="../gui/options.ui" line="1790"/>
        <source>Upload:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1643"/>
        <location filename="../gui/options.ui" line="1797"/>
        <source>Download:</source>
        <translation>Baixada:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1606"/>
        <location filename="../gui/options.ui" line="1629"/>
        <location filename="../gui/options.ui" line="1836"/>
        <location filename="../gui/options.ui" line="1843"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="771"/>
        <source>Remove folder</source>
        <translation>Esborrar carpeta</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1749"/>
        <source>Every day</source>
        <translation>Tots</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1977"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercanviar parells amb clients Bittorrent compatibles (μTorrent, Vuze,...)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1316"/>
        <source>Host:</source>
        <translation>Hoste:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1295"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1282"/>
        <source>Type:</source>
        <translation>Tipus:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="14"/>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="269"/>
        <source>Action on double-click</source>
        <translation>Acció a realitzar amb un Doble-click</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="278"/>
        <source>Downloading torrents:</source>
        <translation>Baixant Torrents:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="300"/>
        <location filename="../gui/options.ui" line="326"/>
        <source>Open destination folder</source>
        <translation>Obrir carpeta destí</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="313"/>
        <source>Completed torrents:</source>
        <translation>Torrents completats:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="345"/>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="358"/>
        <source>Show splash screen on start up</source>
        <translation>Mostra pantalla de benvinguda en iniciar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="368"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimitzat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="394"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimitzar qBittorrent en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="404"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>En tancar qBittorrent deixeu actiu en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="413"/>
        <source>Tray icon style:</source>
        <translation>Estil de la icona al panell:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="421"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="426"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Dark theme)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="431"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Light theme)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="181"/>
        <source>User Interface Language:</source>
        <translation>Llenguatge de la interfície:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="237"/>
        <source>Transfer List</source>
        <translation>Llista de Transferència</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="243"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirma quan elimini Torrents</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="351"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Inicia qBittorrent en l&apos;arrencada de Windows</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="375"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirma tancada quan hi hagi Torrents actius</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="385"/>
        <source>Show qBittorrent in notification area</source>
        <translation>Mostra qBittorrent en l&apos;àrea de notificació</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="444"/>
        <source>File association</source>
        <translation>Associació d&apos;arxius</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="450"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Utilitza qBittorrent per als arxius .torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="457"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Utilitza qBittorrent per als enllaços imant</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="470"/>
        <source>Power Management</source>
        <translation>Administració d&apos;energia</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="476"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Desactivar la suspensió de l&apos;equip quan encara resten Torrents actius</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="546"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciar la descàrrega de forma automàtica</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="562"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Porta el diàleg del Torrent al davant</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="584"/>
        <source>Hard Disk</source>
        <translation>Disc Dur</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="590"/>
        <source>Save files to location:</source>
        <translation>Desa els arxius en la seva ubicació:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="638"/>
        <source>Append the label of the torrent to the save path</source>
        <translation>Afegir l&apos;etiqueta del Torrent a la ruta on es desa</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="648"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pre-assignar espai al disc per a tots els arxius</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="655"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantenir Torrents incomplets a:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="708"/>
        <source>Automatically add torrents from:</source>
        <translation>Carregar automàticament arxius Torrents des de:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="761"/>
        <source>Add folder...</source>
        <translation>Afegeix carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="853"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copia arxius .torrent de les baixades finalitzades a:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="909"/>
        <source>Email notification upon download completion</source>
        <translation>Avisa&apos;m per correu electrònic de la finalització de les descàrregues</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="923"/>
        <source>Destination email:</source>
        <translation>Adreça de correu electrònic:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="933"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="982"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requereix una connexió segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1049"/>
        <source>Listening Port</source>
        <translation>Port de contacte</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1099"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Utilitza UPnP / NAT-PMP reenviament de ports del router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1109"/>
        <source>Use different port on each startup</source>
        <translation>Fes servir ports diferents a cada inici</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1235"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Nombre global màxim de solcs de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1370"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Per contra, el servidor proxy s&apos;utilitzarà només per les connexions tracker</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1373"/>
        <source>Use proxy for peer connections</source>
        <translation>Utilitza proxy per a les connexions entre parells</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1380"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Desactiva connexions no suportades per servidors intermediaris</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1393"/>
        <source>Use proxy only for torrents</source>
        <translation>Utilitza servidor intermediari només per als Torrents</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1390"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Les fonts RSS, motors de cerca, actualitzacions del programa o altres coses que no siguin transferències Torrent i operacions relacionades (com intercanvis de parells) faran servir una connexió directa</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1462"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: La contrasenya desada no és encriptada</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1475"/>
        <source>IP Filtering</source>
        <translation>filtrat IP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1516"/>
        <source>Reload the filter</source>
        <translation>Actualització del filtre</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1532"/>
        <source>Apply to trackers</source>
        <translation>Aplica als rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1872"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplica taxa límit als parells en LAN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1735"/>
        <source>When:</source>
        <translation>Quan:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1754"/>
        <source>Weekdays</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1759"/>
        <source>Weekends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1866"/>
        <source>Rate Limits Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1886"/>
        <source>Enable µTP protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../gui/options.ui" line="1893"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1961"/>
        <source>Privacy</source>
        <translation>Privacitat</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1967"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activar DHT (xarxa descentralitzada) per trobar més parells</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1980"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar intercanvi de parells (PEX) per trobar més parells</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1990"/>
        <source>Look for peers on your local network</source>
        <translation>Podeu cercar parells a la teva xarxa local</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2048"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilita quan utilitzi un servidor intermediari o una connexió VPN</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2051"/>
        <source>Enable anonymous mode</source>
        <translation>Activar manera anònima</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2200"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>No comptar amb Torrents lents fora d&apos;aquests límits</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2221"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Ratio compartició de llavors Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2250"/>
        <source>then</source>
        <translation>després</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2261"/>
        <source>Pause them</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2266"/>
        <source>Remove them</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2285"/>
        <source>Automatically add these trackers to new downloads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2404"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Utilitza UPnP / NAT-PMP per transmetre al port del meu router</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2414"/>
        <source>Use HTTPS instead of HTTP</source>
        <translation>Utilitza HTTPS en lloc de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2457"/>
        <source>Import SSL Certificate</source>
        <translation>Importació de certificats SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2510"/>
        <source>Import SSL Key</source>
        <translation>Importar clau SSL</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2445"/>
        <source>Certificate:</source>
        <translation>Certificat:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1666"/>
        <source>Alternative Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2498"/>
        <source>Key:</source>
        <translation>Clau:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2532"/>
        <source>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=http://httpd.apache.org/docs/2.2/ssl/ssl_faq.html#aboutcerts&gt;Informació sobre els certificats&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2577"/>
        <source>Bypass authentication for localhost</source>
        <translation>Eludir la autenticació per localhost</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2601"/>
        <source>Update my dynamic domain name</source>
        <translation>Actualitzar el meu nom de domini dinàmic</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2613"/>
        <source>Service:</source>
        <translation>Servei:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2636"/>
        <source>Register</source>
        <translation>Registre</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2645"/>
        <source>Domain name:</source>
        <translation>Nom de domini:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1290"/>
        <source>(None)</source>
        <translation>(Cap)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="102"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1305"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1342"/>
        <location filename="../gui/options.ui" line="2369"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="943"/>
        <location filename="../gui/options.ui" line="1406"/>
        <location filename="../gui/options.ui" line="2545"/>
        <source>Authentication</source>
        <translation>Autentificació</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="955"/>
        <location filename="../gui/options.ui" line="1420"/>
        <location filename="../gui/options.ui" line="2584"/>
        <location filename="../gui/options.ui" line="2659"/>
        <source>Username:</source>
        <translation>Nom d&apos;Usuari:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="965"/>
        <location filename="../gui/options.ui" line="1440"/>
        <location filename="../gui/options.ui" line="2591"/>
        <location filename="../gui/options.ui" line="2673"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2086"/>
        <source>Torrent Queueing</source>
        <translation>Torrents en cua</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2210"/>
        <source>Share Ratio Limiting</source>
        <translation>Límit de Ràtio de Compartició</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="2355"/>
        <source>Enable Web User Interface (Remote control)</source>
        <translation>Habilitar interfície Web d&apos;usuari (Control remot)</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1300"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/options.ui" line="1487"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Ruta de Filtre (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="79"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="174"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/preferences.cpp" line="176"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreviewSelect</name>
    <message>
        <location filename="../gui/previewselect.cpp" line="54"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="55"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="56"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Preview impossible</source>
        <translation>Impossible vista prèvia</translation>
    </message>
    <message>
        <location filename="../gui/previewselect.cpp" line="90"/>
        <location filename="../gui/previewselect.cpp" line="127"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Ho sento, no es pot realitzar una vista prèvia d&apos;aquest arxiu</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="106"/>
        <source>Not downloaded</source>
        <translation>No descarregar</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="162"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="109"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="163"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="103"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="112"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="164"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Màxim</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="46"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="55"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>HTTP Sources</source>
        <translation>Fonts HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="63"/>
        <source>Content</source>
        <translation>Contingut</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Speed</source>
        <translation>Velocitat</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Baixat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Disponibilitat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progrés:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferència</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Temps actiu:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Temps estimat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Llavors:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocitat de baixada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocitat de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Parells:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Límit de baixada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Límit de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Perdut:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Connexions:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <source>Torrent content:</source>
        <translation type="obsolete">Contingut del Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1020"/>
        <source>Select All</source>
        <translation>Selecciona Totes</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1027"/>
        <source>Select None</source>
        <translation>Treure Seleccions</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1103"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1098"/>
        <source>High</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Ràtio de compartició:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Comunica en:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Últim cop vist complet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Mida total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Peces:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Creat per:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Afegit el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Completat el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Creat el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Funció resum del Torrent (hash):</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Ruta de desada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1093"/>
        <source>Maximum</source>
        <translation>Màxim</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1085"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <source>Do not download</source>
        <translation>No descarregar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="431"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="438"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (te %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="383"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="386"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 en aquesta sessió)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="395"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrat per %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="402"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 màxim)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="415"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="419"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="423"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="427"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 de mitja)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="568"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="569"/>
        <source>Open Containing Folder</source>
        <translation>Obre carpeta contenidora</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="570"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="575"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="621"/>
        <source>New Web seed</source>
        <translation>Nova llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="627"/>
        <source>Remove Web seed</source>
        <translation>Elimina llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="629"/>
        <source>Copy Web seed URL</source>
        <translation>Copia URL de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="630"/>
        <source>Edit Web seed URL</source>
        <translation>Edita URL de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="655"/>
        <source>Rename the file</source>
        <translation>Rebatejar arxiu Torrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="656"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="660"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="691"/>
        <source>The file could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="661"/>
        <source>This file name contains forbidden characters, please choose a different one.</source>
        <translation>El nom introduït conté caràcters prohibits, si us plau n&apos;elegeixi un altre.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="692"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="730"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja està en ús. Si us plau, usi un nom diferent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="729"/>
        <source>The folder could not be renamed</source>
        <translation>No es pot canviar el nom d&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="832"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="81"/>
        <source>Filter files...</source>
        <translation>Filtra arxius...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="775"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova llavor URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="776"/>
        <source>New URL seed:</source>
        <translation>Nova llavor URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="782"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="833"/>
        <source>This URL seed is already in the list.</source>
        <translation>Aquesta llavor URL ja es troba en la llista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="825"/>
        <source>Web seed editing</source>
        <translation>Edició de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="826"/>
        <source>Web seed URL:</source>
        <translation>URL de la llavor web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="110"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>La vostra adreça IP ha estat bandejada després de masses intents d&apos;autentificació fallits.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="388"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Error: &apos;%1&apos; no és un arxiu Torrent vàlid.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="396"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Error: no s&apos;ha pogut afegir el Torrent a la sessió.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="405"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Error d&apos;entrada-sortida: No s&apos;ha pogut crear un arxiu temporal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="140"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 és un parametre de comanda de línia no conegut.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="152"/>
        <location filename="../app/main.cpp" line="165"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 ha de ser un sol paràmetre de comanda de línia.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="175"/>
        <source>%1 must specify the correct port (1 to 65535).</source>
        <translation>%1 ha d&apos;especificar el port correcte (d&apos;1 a 65535).</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="199"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>No podeu utilitzar %1: qBittorrent ja s&apos;esta executant per a aquest usuari.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="384"/>
        <source>Usage:</source>
        <translation>Utilització:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="397"/>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Displays program version</source>
        <translation>Mostra la versió del programa</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Displays this help message</source>
        <translation>Mostra aquest missatge d&apos;ajuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="403"/>
        <source>Changes the Web UI port (current: %1)</source>
        <translation>Canvia el port de la interfície web (actual: %1)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="406"/>
        <source>Disable splash screen</source>
        <translation>Desactiva finestra de benvinguda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="408"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Executa en mode dimoni (segon terme)</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="410"/>
        <source>Downloads the torrents passed by the user</source>
        <translation>Baixa els Torrents passats per l&apos;usuari</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="429"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Executa l&apos;aplicació amb l&apos;opció -h per a llegir quant als paràmetres de comandes de línia.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="431"/>
        <source>Bad command line</source>
        <translation>Comanda de línia errònia</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="437"/>
        <source>Bad command line: </source>
        <translation>Comanda de línia errònia:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="450"/>
        <source>Legal Notice</source>
        <translation>Notes legals</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="451"/>
        <location filename="../app/main.cpp" line="461"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent és un programa per compartir arxius. Quan s&apos;executa un torrent, les dades d&apos;aquest es fan disponibles per a altres. Qualsevol contingut que compartiu serà sobre la vostra responsabilitat.

No es mostraran més avisos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="452"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Premeu la tecla %1 per a acceptar i continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="462"/>
        <source>Legal notice</source>
        <translation>Notes legals</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="463"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="464"/>
        <source>I Agree</source>
        <translation>Estic d&apos;acord</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="122"/>
        <source>Torrent name: %1</source>
        <translation>Nom del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="123"/>
        <source>Torrent size: %1</source>
        <translation>Mida del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="124"/>
        <source>Save path: %1</source>
        <translation>Ruta de desada: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="125"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El torrernt s&apos;ha baixat a %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="128"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gràcies per fer servir qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="134"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; s&apos;han finalitzat les baixades</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="204"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>El nom host no s&apos;ha trobat (nom host no vàlid)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The operation was canceled</source>
        <translation>L&apos;operació ha estat cancel·lada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remot ha tancat la connexió abans de temps, abans quela resposta fos rebuda i processada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The connection to the remote server timed out</source>
        <translation>Temps d&apos;espera esgotat per a la connexió amb el servidor remot</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Salutació SSL/TSL fallida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remot ha rebutjat la connexió</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The connection to the proxy server was refused</source>
        <translation>La connexió amb el servidor intermediari ha estat rebutjada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>El servidor intermediari ha tancat la connexió abans de temps</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy host name was not found</source>
        <translation>El nom del servidor intermediari no s&apos;ha trobat</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La connexió amb el servidor intermediari s&apos;ha esgotat, o el servidor no ha respost a temps a la sol·licitud enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>El servidor intermediari requereix autenticació per a atendre la sol·licitud, però no ha acceptat les credencials ofertes</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>L&apos;accés al contingut remot ha estat rebutjat (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>L&apos;operació sol·licitada en el contingut remot no és permesa</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contingut remot no es troba al servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remot requereix autenticació per servir el contingut, però les credencials proporcionades no són correctes</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>L&apos;accés a la xarxa de l&apos;API no pot complir amb la sol·licitud perquè el protocol és desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>L&apos;operació sol·licitada no és vàlida per a aquest protocol</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>An unknown network-related error was detected</source>
        <translation>Error de xarxa desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Error de servidor intermediari desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Error de contingut remot desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Una error en el protocol ha estat detectat</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="52"/>
        <location filename="../app/upgrade.h" line="65"/>
        <source>Upgrade</source>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="55"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Heu actualitzat des d&apos;una versió antiga que desava les coses de manera diferent. Heu de migrar al nou sistema de desada i no podreu tornar a fer servir una versió més antiga de 3.3.0. Voleu continuar?</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Heu actualitzat des d&apos;una versió antiga que desava les coses de manera diferent. Heu de migrar al nou sistema de desada. Si continueu, no podreu tornar a fer servir una versió més antiga de la 3.3.0.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="138"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>No s&apos;ha pogut migrar el Torrent amb la funció resum (hash): %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="141"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>No s&apos;ha pogut migrar el torrent. Nom del fitxer de represa ràpida invàlid: %1</translation>
    </message>
</context>
<context>
    <name>RSS</name>
    <message>
        <location filename="../gui/rss/rss.ui" line="17"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="31"/>
        <source>New subscription</source>
        <translation>Nova subscripció</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="47"/>
        <location filename="../gui/rss/rss.ui" line="195"/>
        <location filename="../gui/rss/rss.ui" line="198"/>
        <source>Mark items read</source>
        <translation>Marcar per llegir</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="66"/>
        <source>Update all</source>
        <translation>Actualitzar tot</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="95"/>
        <source>RSS Downloader...</source>
        <translation>Descarregar RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="102"/>
        <source>Settings...</source>
        <translation>Configuració...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="124"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (doble clic per a baixar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="158"/>
        <location filename="../gui/rss/rss.ui" line="161"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="166"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="169"/>
        <source>Rename</source>
        <translation>Rebatejar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="174"/>
        <location filename="../gui/rss/rss.ui" line="177"/>
        <source>Update</source>
        <translation>Actualitzar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="182"/>
        <source>New subscription...</source>
        <translation>Nova subscripció...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="187"/>
        <location filename="../gui/rss/rss.ui" line="190"/>
        <source>Update all feeds</source>
        <translation>Actualitzar tots els Canals</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="203"/>
        <source>Download torrent</source>
        <translation>Baixa el Torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="208"/>
        <source>Open news URL</source>
        <translation>Obrir nova URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="213"/>
        <source>Copy feed URL</source>
        <translation>Copiar Canal URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="218"/>
        <source>New folder...</source>
        <translation>Nova carpeta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="223"/>
        <source>Manage cookies...</source>
        <translation>Administrar Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss.ui" line="63"/>
        <source>Refresh RSS streams</source>
        <translation>Actualitzar els Canals RSS</translation>
    </message>
</context>
<context>
    <name>RSSImp</name>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="218"/>
        <source>Stream URL:</source>
        <translation>URL del Canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="218"/>
        <source>Please type a RSS stream URL</source>
        <translation>Escriviu una URL d&apos;un canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="228"/>
        <source>This RSS feed is already in the list.</source>
        <translation>Aquesta font RSS ja és a la llista.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Please choose a folder name</source>
        <translation>Si us plau elegeixi un nom per a la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>Folder name:</source>
        <translation>Nom de la carpeta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="173"/>
        <source>New folder</source>
        <translation>Nova carpeta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="254"/>
        <source>Deletion confirmation</source>
        <translation>Confirmació de supressió</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="255"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Esteu segurs que voleu eliminar les fonts RSS seleccionades?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="406"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Si us plau, elegeixi un nou nom per al Canal RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="406"/>
        <source>New feed name:</source>
        <translation>Nom del nou Canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="410"/>
        <source>Name already in use</source>
        <translation>Aquest nom ja es troba en ús</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="410"/>
        <source>This name is already used by another item, please choose another one.</source>
        <translation>Aquest nom ja s&apos;està usant, si us plau, elegeixi un altre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="580"/>
        <source>Date: </source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="582"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rss_imp.cpp" line="659"/>
        <source>Unread</source>
        <translation>No llegits</translation>
    </message>
</context>
<context>
    <name>RssFeed</name>
    <message>
        <location filename="../gui/rss/rssfeed.cpp" line="369"/>
        <source>Automatic download of &apos;%1&apos; from &apos;%2&apos; RSS feed failed because it doesn&apos;t contain a torrent or a magnet link...</source>
        <translation>La baixada automàtica de &apos;%1&apos; de la font &apos;RSS&apos; %2 ha fallat perquè no conté un Torrent o enllaç imant...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rssfeed.cpp" line="374"/>
        <source>Automatically downloading &apos;%1&apos; torrent from &apos;%2&apos; RSS feed...</source>
        <translation>Baixant automàticament &apos;%1&apos; Torrent de &apos;%2&apos; fonts RSS...</translation>
    </message>
</context>
<context>
    <name>RssParser</name>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="464"/>
        <source>Failed to open downloaded RSS file.</source>
        <translation>No s&apos;ha pogut obrir l&apos;arxiu RSS baixat.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rssparser.cpp" line="501"/>
        <source>Invalid RSS feed at &apos;%1&apos;.</source>
        <translation>Proveïdor d&apos;RSS invàlid en &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>RssSettingsDlg</name>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="14"/>
        <source>RSS Reader Settings</source>
        <translation>Ajustaments Lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="47"/>
        <source>RSS feeds refresh interval:</source>
        <translation>Interval d&apos;actualització de Canals RSS:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="70"/>
        <source>minutes</source>
        <translation>minuts</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsssettingsdlg.ui" line="77"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Nombre màxim d&apos;articles per Canal:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="157"/>
        <source>Watched Folder</source>
        <translation>Cerca fitxers .torrents</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="160"/>
        <source>Download here</source>
        <translation>Descarregar Torrent aquí</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="163"/>
        <source>Download path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchCategories</name>
    <message>
        <location filename="../searchengine/supportedengines.h" line="53"/>
        <source>All categories</source>
        <translation>Totes les categories</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="54"/>
        <source>Movies</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="55"/>
        <source>TV shows</source>
        <translation>Programes TV</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="56"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="57"/>
        <source>Games</source>
        <translation>Jocs</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="58"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="59"/>
        <source>Software</source>
        <translation>Programes</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="60"/>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../searchengine/supportedengines.h" line="61"/>
        <source>Books</source>
        <translation>Llibres</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="190"/>
        <location filename="../searchengine/searchengine.cpp" line="220"/>
        <location filename="../searchengine/searchengine.cpp" line="479"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="203"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Instal·leu Python per a fer servir el motor de cerca.</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="233"/>
        <source>Empty search pattern</source>
        <translation>Patró de recerca buit</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="233"/>
        <source>Please type a search pattern first</source>
        <translation>Si us plau escrigui un patró de recerca primer</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="313"/>
        <source>Searching...</source>
        <translation>Buscant...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="316"/>
        <source>Stop</source>
        <translation>Atura</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="203"/>
        <location filename="../searchengine/searchengine.cpp" line="453"/>
        <source>Search Engine</source>
        <translation>Motor de cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="453"/>
        <location filename="../searchengine/searchengine.cpp" line="474"/>
        <source>Search has finished</source>
        <translation>Recerca acabada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="463"/>
        <source>An error occurred during search...</source>
        <translation>Va ocórrer un error durant la recerca...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="461"/>
        <location filename="../searchengine/searchengine.cpp" line="468"/>
        <source>Search aborted</source>
        <translation>Recerca avortada</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="118"/>
        <source>All enabled</source>
        <translation>Tot habilitat</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="119"/>
        <source>All engines</source>
        <translation>Tots els motors</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="122"/>
        <location filename="../searchengine/searchengine.cpp" line="177"/>
        <source>Multiple...</source>
        <translation>Múltiple...</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="262"/>
        <location filename="../searchengine/searchengine.cpp" line="334"/>
        <source>Results &lt;i&gt;(%1)&lt;/i&gt;:</source>
        <comment>i.e: Search results</comment>
        <translation>Resulats &lt;i&gt;(%1)&lt;/i&gt;:</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="472"/>
        <source>Search returned no results</source>
        <translation>La recerca no va tornar resultats</translation>
    </message>
    <message>
        <location filename="../searchengine/searchengine.cpp" line="561"/>
        <source>Stopped</source>
        <translation>Detinguts</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../searchengine/searchlistdelegate.h" line="60"/>
        <location filename="../searchengine/searchlistdelegate.h" line="64"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="66"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="67"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="68"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="69"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechers</translation>
    </message>
    <message>
        <location filename="../searchengine/searchtab.cpp" line="70"/>
        <source>Search engine</source>
        <translation>Motor de cerca</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="45"/>
        <source>Exit confirmation</source>
        <translation>Confirmació de sortida</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="46"/>
        <source>Exit now</source>
        <translation>Surt ara</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="49"/>
        <source>Shutdown confirmation</source>
        <translation>Tancar confirmació</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="50"/>
        <source>Shutdown now</source>
        <translation>Atura ara</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="109"/>
        <source>qBittorrent will now exit unless you cancel within the next %1 seconds.</source>
        <translation>qBittorrent sortirà ara no sigui que cancel·leu en els propers %1 segons.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="112"/>
        <source>The computer will now be switched off unless you cancel within the next %1 seconds.</source>
        <translation>L&apos;ordinador s&apos;apagarà no sigui que cancel·leu en els propers %1 segons.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="115"/>
        <source>The computer will now go to sleep mode unless you cancel within the next %1 seconds.</source>
        <translation>L&apos;ordinador passarà a mode en espera. %1 segons per a cancel·lar.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirm.cpp" line="118"/>
        <source>The computer will now go to hibernation mode unless you cancel within the next %1 seconds.</source>
        <translation>L&apos;ordinador passarà a hibernar. %1 segons per a cancel·lar.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="78"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="47"/>
        <source>Total Upload</source>
        <translation>Total pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="48"/>
        <source>Total Download</source>
        <translation>Total baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Payload Upload</source>
        <translation>Càrrega de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Payload Download</source>
        <translation>Càrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Overhead Upload</source>
        <translation>Pujada per damunt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Overhead Download</source>
        <translation>Baixada per damunt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>DHT Upload</source>
        <translation>Pujada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>DHT Download</source>
        <translation>Baixada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>Tracker Upload</source>
        <translation>Pujada del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>Tracker Download</source>
        <translation>Baixada del rastrejador</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Període:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minuts</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minuts</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 hores</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="103"/>
        <source>Select Graphs</source>
        <translation>Seleccioneu gràfics</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="79"/>
        <source>Total Upload</source>
        <translation>Total pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Download</source>
        <translation>Total baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Payload Upload</source>
        <translation>Càrrega de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Download</source>
        <translation>Càrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Overhead Upload</source>
        <translation>Pujada per damunt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Download</source>
        <translation>Baixada per damunt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>DHT Upload</source>
        <translation>Pujada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Download</source>
        <translation>Baixada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Tracker Upload</source>
        <translation>Pujada del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Download</source>
        <translation>Baixada del rastrejador</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadístiques</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadístiques d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Connexions de parells totals:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Ràtio global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Temps total baixat:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Temps total pujat:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Despesa total (aquesta sessió):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadístiques de memòria cau</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache Hits:</source>
        <translation>Resultats de lectura de memòria cau:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Mida total de la memòria intermèdia (buffer):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadístiques de rendiment</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Ordres d&apos;entrada-sortida en cua:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Escriure memòria cau sobrecarregada:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue (ms):</source>
        <translation>Temps mitjà en cua (ms):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Llegir memòria cau sobrecarregada:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Mida total en cua:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="243"/>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>Connection status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="59"/>
        <location filename="../gui/statusbar.cpp" line="171"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hi ha connexions directes. Això pot indicar problemes en la configuració de la xarxa.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="73"/>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodes</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="141"/>
        <source>qBittorrent needs to be restarted</source>
        <translation>És necessari reiniciar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="151"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent ha estat actualitzat i ha de ser reiniciat perquè els canvis siguin efectius.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Connection Status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="163"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fora de línia. Això normalment significa que qBittorrent no pot contactar al port seleccionat per a les connexions entrants.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="168"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="203"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="199"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat normal</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="212"/>
        <source>Manual change of rate limits mode. The scheduler is disabled.</source>
        <translation>Canvi manual del ràtio de límits. L&apos;horari és desactivat.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="219"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat límit global de descàrrega</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="245"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="117"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Tots (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="120"/>
        <source>Downloading (0)</source>
        <translation>Baixant (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="123"/>
        <source>Seeding (0)</source>
        <translation>Sembrant (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="126"/>
        <source>Completed (0)</source>
        <translation>Completats (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="129"/>
        <source>Resumed (0)</source>
        <translation>Represos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="132"/>
        <source>Paused (0)</source>
        <translation>Pausats (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="135"/>
        <source>Active (0)</source>
        <translation>Actius (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="138"/>
        <source>Inactive (0)</source>
        <translation>Inactius (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="141"/>
        <source>Errored (0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>All (%1)</source>
        <translation>Tots (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="159"/>
        <source>Downloading (%1)</source>
        <translation>Baixant (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="160"/>
        <source>Seeding (%1)</source>
        <translation>Sembrant (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Completed (%1)</source>
        <translation>Completats (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="162"/>
        <source>Paused (%1)</source>
        <translation>Pausats (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="163"/>
        <source>Resumed (%1)</source>
        <translation>Represos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="164"/>
        <source>Active (%1)</source>
        <translation>Actius (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>Inactive (%1)</source>
        <translation>Inactius (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Errored (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="56"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="56"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="57"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="57"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="78"/>
        <source>Select a folder to add to the torrent</source>
        <translation>Seleccioneu una carpeta per a afegir el Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="92"/>
        <source>Select a file to add to the torrent</source>
        <translation>Seleccioneu un arxiu per a afegir al Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>No input path set</source>
        <translation>Sense ruta de destí establerta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="114"/>
        <source>Please type an input path first</source>
        <translation>Si us plau escriu primer una ruta d&apos;entrada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Select destination torrent file</source>
        <translation>Seleccioneu una destinació per a l&apos;arxiu Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="124"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Arxius Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent was created successfully: %1</source>
        <comment>%1 is the path of the torrent</comment>
        <translation>El Torrent s&apos;ha creat amb èxit: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Torrent creation</source>
        <translation>Creació de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="152"/>
        <source>Torrent creation was unsuccessful, reason: %1</source>
        <translation>La creació del Torrent no ha estat reeixida, raó: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="165"/>
        <source>Created torrent file is invalid. It won&apos;t be added to download list.</source>
        <translation>La creació de l&apos;arxiu Torrent no és vàlida. No s&apos;afegirà a la llista de descàrregues.</translation>
    </message>
</context>
<context>
    <name>TorrentImportDlg</name>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="14"/>
        <source>Torrent Import</source>
        <translation>Importar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="53"/>
        <source>This assistant will help you share with qBittorrent a torrent that you have already downloaded.</source>
        <translation>Aquest assistent l&apos;ajudarà a compartir amb qBittorrent, un torrent ja descarregat.</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="65"/>
        <source>Torrent file to import:</source>
        <translation>Arxiu Torrent per importar:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="90"/>
        <source>Content location:</source>
        <translation>Ubicació del contingut:</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="121"/>
        <source>Skip the data checking stage and start seeding immediately</source>
        <translation>Saltar-se la fase de control de dades i començar a sembrar tot seguit</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.ui" line="131"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent file to import</source>
        <translation>Arxiu Torrent per importar</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="65"/>
        <source>Torrent files</source>
        <translation>Arxius Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="89"/>
        <source>&apos;%1&apos; Files</source>
        <comment>%1 is a file extension (e.g. PDF)</comment>
        <translation>&apos;%1&apos; Arxius</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="91"/>
        <source>Please provide the location of &apos;%1&apos;</source>
        <comment>%1 is a file name</comment>
        <translation>Indiqueu la ubicació de &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="124"/>
        <source>Please point to the location of the torrent: %1</source>
        <translation>Si us plau, elegeixi la ubicació del Torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>Invalid torrent file</source>
        <translation>Arxiu Torrent no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/torrentimportdlg.cpp" line="222"/>
        <source>This is not a valid torrent file.</source>
        <translation>Això no és un arxiu Torrent vàlid.</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. Baixada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. Pujada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ratio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Temps estimat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Afegit el</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completat a</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límit Baixada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límit Pujada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Baixats</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Pujats</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Baixades durant la sessió</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Pujades durant la sessió</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restants</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Temps actiu</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Desa el camí</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límit del ràtio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Últim cop vist complet</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Darrera activitat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Mida total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="428"/>
        <source>All (0)</source>
        <comment>this is for the label filter</comment>
        <translation>Tots (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="431"/>
        <source>Trackerless (0)</source>
        <translation>Sense rastrejadors (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="434"/>
        <source>Error (0)</source>
        <translation>Error (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="437"/>
        <source>Warning (0)</source>
        <translation>Advertència (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="478"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="535"/>
        <source>Trackerless (%1)</source>
        <translation>Sense rastrejadors (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="484"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="530"/>
        <source>%1 (%2)</source>
        <comment>openbittorrent.com (10)</comment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="560"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="592"/>
        <source>Error (%1)</source>
        <translation>Error (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="573"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="607"/>
        <source>Warning (%1)</source>
        <translation>Advertència (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="635"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;. Trying to download favicon in PNG format.</source>
        <translation>No s&apos;ha pogut descodificar la icona del web de la URL &apos;%1&apos;. Proveu a baixar la icona de web en format PNG.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="640"/>
        <source>Couldn&apos;t decode favicon for URL &apos;%1&apos;.</source>
        <translation>No s&apos;ha pogut descodificar la icona del web de la URL &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="654"/>
        <source>Couldn&apos;t download favicon for URL &apos;%1&apos;. Reason: %2</source>
        <translation>No s&apos;ha pogut baixar la icona del web de la URL &apos;%1&apos;. Raó: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="663"/>
        <source>Resume torrents</source>
        <translation>Reprèn Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="664"/>
        <source>Pause torrents</source>
        <translation>Pausa Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="665"/>
        <source>Delete torrents</source>
        <translation>Elimina Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="699"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="713"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Tots (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="69"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="70"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="71"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="72"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="217"/>
        <location filename="../gui/properties/trackerlist.cpp" line="286"/>
        <source>Working</source>
        <translation>Treballant</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="218"/>
        <source>Disabled</source>
        <translation>Deshabilitat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="239"/>
        <source>This torrent is private</source>
        <translation>Aquest Torrent és privat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="290"/>
        <source>Updating...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="294"/>
        <source>Not working</source>
        <translation>Aturat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="298"/>
        <source>Not contacted yet</source>
        <translation>Encara sense connexió</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker URL:</source>
        <translation>URL del rastrejador:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="380"/>
        <source>Tracker editing</source>
        <translation>Edició del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>Tracker editing failed</source>
        <translation>Edició del rastrejador fallada</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="386"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>L&apos;URL entrada del rastrejador és invàlida.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="397"/>
        <source>The tracker URL already exists.</source>
        <translation>L&apos;URL del rastrejador ja existeix.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="448"/>
        <source>Add a new tracker...</source>
        <translation>Afegir nou tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="454"/>
        <source>Copy tracker URL</source>
        <translation>Copia la URL del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="455"/>
        <source>Edit selected tracker URL</source>
        <translation>Edita l&apos;URL del rastrejador seleccionat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="460"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Força el reanunci dels rastrejadors seleccionats</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="462"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forca el reanunci per a tots els rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="453"/>
        <source>Remove tracker</source>
        <translation>Esborrar traker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diàleg per afegir trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Llista de trackers a afegir (un per línia):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="44"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Llista d&apos;URL de µTorrent compatibles:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada-sortida</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="73"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error en intentar obrir l&apos;arxiu descarregat.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No change</source>
        <translation>Sense canvis</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="111"/>
        <source>No additional trackers were found.</source>
        <translation>No es va trobar cap Tracker.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>Download error</source>
        <translation>Error de descàrrega</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="119"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>La llista de Trackers no va poder ser descarregada. Raó: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="97"/>
        <source>Downloading</source>
        <translation>Descarregant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="103"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Baixant metadades</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="109"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Distribuint</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="133"/>
        <source>Paused</source>
        <translation>Pausat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="120"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>A cua</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="113"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembrando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="100"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detinguda</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="106"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Baixant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="116"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Sembrant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="124"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>En cua per a comprovació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="130"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Comprovant les dades de represa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="136"/>
        <source>Completed</source>
        <translation>Completat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="139"/>
        <source>Missing Files</source>
        <translation>Arxius ausents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="142"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="172"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrat per %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>fa %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="792"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="800"/>
        <source>Labels</source>
        <translation>Etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="808"/>
        <source>Trackers</source>
        <translation>Rastrejadors</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="511"/>
        <source>Column visibility</source>
        <translation>Visibilitat de columnes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="763"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="252"/>
        <source>Choose save path</source>
        <translation>Seleccioneu un camí de desada</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="439"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límit de velocitat de baixada de Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="468"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límit de velocitat de pujada de Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Recheck confirmation</source>
        <translation>Ratifica la confirmació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="499"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Esteu segurs que voleu tornar a comprovar el(s) Torrent(s) seleccionat(s)?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>New Label</source>
        <translation>Nova Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="575"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Invalid label name</source>
        <translation>Nom d&apos;Etiqueta no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="581"/>
        <source>Please don&apos;t use any special characters in the label name.</source>
        <translation>Si us plau, no utilitzi caràcters especials per al nom de l&apos;Etiqueta.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>Rename</source>
        <translation>Rebatejar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="600"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="629"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reprende</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="633"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Força reanudació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="631"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="635"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="637"/>
        <source>Preview file...</source>
        <translation>Previsualitzar arxiu...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="639"/>
        <source>Limit share ratio...</source>
        <translation>Límit ràtio compartició ...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="641"/>
        <source>Limit upload rate...</source>
        <translation>Taxa límit de Pujada...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="643"/>
        <source>Limit download rate...</source>
        <translation>Taxa límit de Baixada...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="645"/>
        <source>Open destination folder</source>
        <translation>Obrir carpeta destí</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="647"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Moure amunt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="649"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Moure avall</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="651"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Moure al principi</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="653"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Moure al final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="655"/>
        <source>Set location...</source>
        <translation>Establir una destinació...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="661"/>
        <source>Copy name</source>
        <translation>Copia el nom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="813"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="657"/>
        <source>Force recheck</source>
        <translation>Forçar verificació de arxiu</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="659"/>
        <source>Copy magnet link</source>
        <translation>Copiar magnet link</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="663"/>
        <source>Super seeding mode</source>
        <translation>Mode de SuperSembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="666"/>
        <source>Rename...</source>
        <translation>Rebatejar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="668"/>
        <source>Download in sequential order</source>
        <translation>Descarregar en ordre seqüencial</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="671"/>
        <source>Download first and last piece first</source>
        <translation>Descarregar primer, primeres i últimes parts</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>New...</source>
        <comment>New label...</comment>
        <translation>Nou...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="765"/>
        <source>Reset</source>
        <comment>Reset label</comment>
        <translation>Reset Etiquetas</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Limitació del ràtio de pujada/baixada</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global ratio limit</source>
        <translation>Utilitza límit de ràtio global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no ratio limit</source>
        <translation>Sense límits de ràtio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set ratio limit to</source>
        <translation>Limitar ràtio a</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="84"/>
        <source>The Web UI is listening on port %1</source>
        <translation>La interfície web està contactant al port %1</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI Error - Unable to bind Web UI to port %1</source>
        <translation>Error de la interfície web - Impossible ancorar la interfície al port %1</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="55"/>
        <source>An advanced BitTorrent client programmed in &lt;nobr&gt;C++&lt;/nobr&gt;, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un client BitTorrent avançat programat en &lt;nobr&gt;C++&lt;/nobr&gt;, basat en el joc d&apos;eines Qt i libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="57"/>
        <source>Copyright %1 2006-2015 The qBittorrent project</source>
        <translation>Copyright %1 2006-2015 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="59"/>
        <source>Home Page: </source>
        <translation>Pàgina principal:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="61"/>
        <source>Bug Tracker: </source>
        <translation>Rastrejador de l&apos;error:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="63"/>
        <source>Forum: </source>
        <translation>Fòrum:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="66"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent a Freenode</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Afegir parells:</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one per line):</source>
        <translation>Llista de parells a afegir (un per línia):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autentificació del Tracker</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Autentificar-se</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Usuari:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="154"/>
        <source>Log in</source>
        <translation>Connectar</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation - qBittorrent</source>
        <translation>Confirmar esborrament - qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recordar sempre aquesta elecció</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Esborrar també l&apos;arxiu del disc físic</translation>
    </message>
</context>
<context>
    <name>createTorrentDialog</name>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="308"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="14"/>
        <source>Torrent Creation Tool</source>
        <translation>Eina de creació de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="38"/>
        <source>Torrent file creation</source>
        <translation>Creació d&apos;arxiu Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="60"/>
        <source>Add file</source>
        <translation>Nou arxius</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="67"/>
        <source>Add folder</source>
        <translation>Nova carpeta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="48"/>
        <source>File or folder to add to the torrent:</source>
        <translation>Arxiu o carpeta a agregar al Torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="78"/>
        <source>Tracker URLs:</source>
        <translation>Tracker URLs:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="88"/>
        <source>Web seeds urls:</source>
        <translation>Llavors web urls:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="98"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="127"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Podeu separar grups de rastrejadors amb una línia en blanc.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="148"/>
        <source>Piece size:</source>
        <translation>Mida de la peça:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="165"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="170"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="175"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="180"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="185"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="190"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="195"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="200"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="205"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="210"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="215"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="223"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="248"/>
        <source>Private (won&apos;t be distributed on DHT network if enabled)</source>
        <translation>Privat (no es distribuirà per xarxa DHT si s&apos;habilita)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="255"/>
        <source>Start seeding after creation</source>
        <translation>Començar amb la sembra després de la creació</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignora el límit del ràtio de compartició per a aquest Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="301"/>
        <source>Create and save...</source>
        <translation>Crea i desa...</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Progress:</source>
        <translation>Progrés:</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="28"/>
        <source>Add torrent links</source>
        <translation>Afegir enllaç Torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="58"/>
        <source>One per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un per línia (enllaços HTTP, enllaços imant i informació de funcions resum (hash) permeses)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="80"/>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="87"/>
        <source>Cancel</source>
        <translation>Cancel-lar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from urls</source>
        <translation>Descarregar d&apos;urls</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>No URL entered</source>
        <translation>No s&apos;ha escrit cap URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="96"/>
        <source>Please type at least one URL.</source>
        <translation>Si us plau escriu almenys una URL.</translation>
    </message>
</context>
<context>
    <name>engineSelect</name>
    <message>
        <location filename="../searchengine/engineselect.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Cerca plugins</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="30"/>
        <source>Installed search engines:</source>
        <translation>Motors de cerca instal-lats:</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="50"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="55"/>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="60"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="65"/>
        <location filename="../searchengine/engineselect.ui" line="124"/>
        <source>Enabled</source>
        <translation>Habilitat</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="83"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Pots obtenir nous plugins de motors de cerca aquí &lt;a href=&quot;http:plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="98"/>
        <source>Install a new one</source>
        <translation>Instal-lar-ne un de nou</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="105"/>
        <source>Check for updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="112"/>
        <source>Close</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselect.ui" line="129"/>
        <source>Uninstall</source>
        <translation>Desinstal-lar</translation>
    </message>
</context>
<context>
    <name>engineSelectDlg</name>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="203"/>
        <source>Uninstall warning</source>
        <translation>Alerta de desinstal-lació</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="205"/>
        <source>Uninstall success</source>
        <translation>Desinstal-lació correcta</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="264"/>
        <source>Invalid plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="264"/>
        <source>The search engine plugin is invalid, please contact the author.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="270"/>
        <source>A more recent version of &apos;%1&apos; search engine plugin is already installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>Una versió més recent del connector de motor de cerca &apos;%1&apos; ja està instal·lada.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="295"/>
        <source>&apos;%1&apos; search engine plugin could not be updated, keeping old version.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El connector de motor de cerca &apos;%1&apos; no s&apos;ha pogut actualitzar, es mantindrà la versió antiga.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <source>&apos;%1&apos; search engine plugin could not be installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El connector de motor de cerca &apos;%1&apos; no ha pogut ser instal·lat.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="310"/>
        <source>&apos;%1&apos; search engine plugin was successfully updated.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El connector de motor de cerca &apos;%1&apos; ha estat actualitzat reeixidament.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="313"/>
        <source>&apos;%1&apos; search engine plugin was successfully installed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>El connector de motor de cerca &apos;%1&apos; ha estat instal·lat reeixidament.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="381"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>L&apos;enllaç no sembla portar a un connector de motor de cerca.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="396"/>
        <source>Select search plugins</source>
        <translation>Seleccioni els plugins de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="517"/>
        <source>Sorry, &apos;%1&apos; search plugin installation failed.</source>
        <comment>%1 is the name of the search engine</comment>
        <translation>La instal·lació del connector de cerca &apos;%1&apos; ha fallat.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="270"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="295"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="300"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="310"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="313"/>
        <source>Search plugin install</source>
        <translation>Instal-lar plugin de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="146"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="217"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="333"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="149"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="183"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="220"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="336"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="397"/>
        <source>qBittorrent search plugin</source>
        <translation>Connector de cerca qBittorrent</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="448"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="489"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="510"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="517"/>
        <source>Search plugin update</source>
        <translation>Actualització del plugin de recerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="489"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="510"/>
        <source>Sorry, update server is temporarily unavailable.</source>
        <translation>Ho sento, el servidor d&apos;actualització aquesta temporalment no disponible.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="448"/>
        <source>All your plugins are already up to date.</source>
        <translation>Tots els teus plugins ja estan actualitzats.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="205"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Tots els plugins seleccionats van ser instal-lats reeixidament</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="203"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Alguns connectors no s&apos;han pogut instal·lar perquè ja són inclosos al qBittorrent. Només els que has afegit tu mateix poden ser desinstal·lats.
De totes maneres, aquests connectors han estat inhabilitats.</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="381"/>
        <source>Invalid link</source>
        <translation>Enllaç invàlid</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="373"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="382"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nou plugin  de motor de cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/engineselectdlg.cpp" line="374"/>
        <location filename="../searchengine/engineselectdlg.cpp" line="383"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Informació de la caiguda</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/utils/fs.cpp" line="446"/>
        <location filename="../base/utils/fs.cpp" line="453"/>
        <location filename="../base/utils/fs.cpp" line="463"/>
        <location filename="../base/utils/fs.cpp" line="496"/>
        <location filename="../base/utils/fs.cpp" line="508"/>
        <source>Downloads</source>
        <translation>Baixades</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="283"/>
        <source>Python not detected</source>
        <translation>Python no detectat</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="311"/>
        <source>Python version: %1</source>
        <translation>Versió de Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="338"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="426"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="430"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="326"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconegut</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="206"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent tancarà l&apos;equip ara, perquè totes les baixades s&apos;han completat.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="419"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="422"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="457"/>
        <source>Working</source>
        <translation>Operatiu</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="455"/>
        <source>Updating...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="459"/>
        <source>Not working</source>
        <translation>No operatiu</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="453"/>
        <source>Not contacted yet</source>
        <translation>Encara no connectat</translation>
    </message>
</context>
<context>
    <name>options_imp</name>
    <message>
        <location filename="../gui/options_imp.cpp" line="1249"/>
        <location filename="../gui/options_imp.cpp" line="1251"/>
        <source>Choose export directory</source>
        <translation>Seleccioni directori d&apos;exportació</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1289"/>
        <location filename="../gui/options_imp.cpp" line="1291"/>
        <location filename="../gui/options_imp.cpp" line="1302"/>
        <location filename="../gui/options_imp.cpp" line="1304"/>
        <source>Choose a save directory</source>
        <translation>Seleccioneu un directori per a desar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1202"/>
        <source>Add directory to scan</source>
        <translation>Afegir directori per escanejar</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="185"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Paràmetres suportats</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="186"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nom del Torrent</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="187"/>
        <source>%L: Label</source>
        <translation>%L: Etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="188"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="189"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="190"/>
        <source>%D: Save path</source>
        <translation>%D: Camí de desada</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="191"/>
        <source>%C: Number of files</source>
        <translation>%C: Nombre de files</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="192"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z Mida del Torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="193"/>
        <source>%T: Current tracker</source>
        <translation>%T: Rastrejador actual</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="194"/>
        <source>%I: Info hash</source>
        <translation>%I: Informació de la funció resum (hash)</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1209"/>
        <source>Folder is already being watched.</source>
        <translation>Aquesta carpeta ja està seleccionada per escanejar.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1212"/>
        <source>Folder does not exist.</source>
        <translation>La carpeta no existeix.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1215"/>
        <source>Folder is not readable.</source>
        <translation>La carpeta no és llegible.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1225"/>
        <source>Failure</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1225"/>
        <source>Failed to add Scan Folder &apos;%1&apos;: %2</source>
        <translation>No es pot escanejar aquesta carpetes &apos;%1&apos;:%2</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1275"/>
        <location filename="../gui/options_imp.cpp" line="1277"/>
        <source>Filters</source>
        <translation>Filtres</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1275"/>
        <location filename="../gui/options_imp.cpp" line="1277"/>
        <source>Choose an IP filter file</source>
        <translation>Seleccioneu un arxiu de filtre de IP</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1344"/>
        <source>SSL Certificate</source>
        <translation>Certificat SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1356"/>
        <source>SSL Key</source>
        <translation>Clau SSL</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1389"/>
        <source>Parsing error</source>
        <translation>Error d&apos;anàlisi</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1389"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No s&apos;ha pogut analitzar el filtratge IP</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1391"/>
        <source>Successfully refreshed</source>
        <translation>Actualitzat amb èxit</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1391"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analitzat satisfactòriament el filtre IP: %1 regla ha estat aplicada.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1479"/>
        <source>Invalid key</source>
        <translation>Clau no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1479"/>
        <source>This is not a valid SSL key.</source>
        <translation>Aquesta no és una clau SSL vàlida.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1495"/>
        <source>Invalid certificate</source>
        <translation>Certificat no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1495"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Aquest no és un Certificat SSL vàlid.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1505"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Els temps d&apos;inici i d&apos;acabament no poden ser els mateixos.</translation>
    </message>
    <message>
        <location filename="../gui/options_imp.cpp" line="1508"/>
        <source>Time Error</source>
        <translation>Error de temps</translation>
    </message>
</context>
<context>
    <name>pluginSourceDlg</name>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="13"/>
        <source>Plugin source</source>
        <translation>Font del plugin</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="26"/>
        <source>Search plugin source:</source>
        <translation>Font del plugin de recerca:</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="35"/>
        <source>Local file</source>
        <translation>Arxiu local</translation>
    </message>
    <message>
        <location filename="../searchengine/pluginsource.ui" line="42"/>
        <source>Web link</source>
        <translation>Vincle web</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/preview.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Selecció de vista prèvia</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="26"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Els següents arxius permeten previsualització, seleccioneu-ne algun:</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="61"/>
        <source>Preview</source>
        <translation>Vista prèvia</translation>
    </message>
    <message>
        <location filename="../gui/preview.ui" line="68"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
</context>
<context>
    <name>search_engine</name>
    <message>
        <location filename="../searchengine/search.ui" line="14"/>
        <location filename="../searchengine/search.ui" line="28"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="51"/>
        <source>Status:</source>
        <translation>Estat:</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="75"/>
        <source>Stopped</source>
        <translation>Detingut</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="107"/>
        <source>Download</source>
        <translation>Descarregar</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="117"/>
        <source>Go to description page</source>
        <translation>Pàgina de descripció</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="127"/>
        <source>Copy description page URL</source>
        <translation>Copia la pàgina URL de descripció</translation>
    </message>
    <message>
        <location filename="../searchengine/search.ui" line="147"/>
        <source>Search engines...</source>
        <translation>Motors de cerca...</translation>
    </message>
</context>
</TS>
