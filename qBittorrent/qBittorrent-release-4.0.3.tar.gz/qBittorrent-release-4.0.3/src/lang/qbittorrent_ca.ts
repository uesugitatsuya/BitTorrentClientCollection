<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ca">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Quant al qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="56"/>
        <source>About</source>
        <translation>Quant a</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="89"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="121"/>
        <location filename="../gui/about.ui" line="212"/>
        <source>Nationality:</source>
        <translation>Nacionalitat:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="135"/>
        <location filename="../gui/about.ui" line="198"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <location filename="../gui/about.ui" line="205"/>
        <source>E-mail:</source>
        <translation>Correu electrònic:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="101"/>
        <source>Greece</source>
        <translation>Grècia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="95"/>
        <source>Current maintainer</source>
        <translation>Mantenidor actual</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="165"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="249"/>
        <source>Special Thanks</source>
        <translation>Agraïments especials</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="275"/>
        <source>Translators</source>
        <translation>Traductors</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="327"/>
        <source>Libraries</source>
        <translation>Biblioteques</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="333"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>El qBittorrent s&apos;ha construït amb les biblioteques següents:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="171"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="301"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
</context>
<context>
    <name>AbstractWebApplication</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="428"/>
        <source>WebUI: Origin header &amp; Target origin mismatch!</source>
        <translation>Interfície web: no hi ha coincidència entre capçalera i destinació d&apos;origen!</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="429"/>
        <source>Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>IP font: &quot;%1&quot;. Capçalera d&apos;origen: &quot;%2&quot;. Origen de destinació: &quot;%3&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="438"/>
        <source>WebUI: Referer header &amp; Target origin mismatch!</source>
        <translation>Interfície web: no hi ha coincidència entre capçalera de referència i origen de destinació!</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="439"/>
        <source>Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>IP font: &quot;%1&quot;. Capçalera de referència: &quot;%2&quot;. Origen de destinació: &quot;%3&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="456"/>
        <source>WebUI: Invalid Host header, port mismatch.</source>
        <translation>Interfície web: capçalera d&apos;amfitrió, no coincidència de port.</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="457"/>
        <source>Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation>Petició d&apos;IP font: &quot;%1&quot;. Port de servidor: &quot;%2&quot;. Capçalera d&apos;amfitrió rebuda: &quot;%3&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="488"/>
        <source>WebUI: Invalid Host header.</source>
        <translation>Interfície web: capçalera d&apos;amfitrió no vàlida.</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="489"/>
        <source>Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation>Petició d&apos;IP font: &quot;%1&quot;. Capçalera d&apos;amfitrió rebuda: &quot;%2&quot;.</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Desa a</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Set as default save path</source>
        <translation>Defineix com a camí de desament per defecte</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>No ho tornis a mostrar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Configuració del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>Estableix com a categoria predeterminada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Inicia el torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="190"/>
        <source>Torrent information</source>
        <translation>Informació del torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>Omet la comprovació del resum (hash)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="243"/>
        <source>Size:</source>
        <translation>Mida:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="209"/>
        <source>Hash:</source>
        <translation>Resum:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="236"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Mode de gestió de torrents</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El mode automàtic significa que diverses propietats del torrent (p. ex. camins de desament) es decidiran segons la categoria associada.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automàtic</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Si està marcat, el fitxer .torrent no se suprimirà malgrat els paràmetres de la pàgina «Baixades» al diàleg d&apos;opcions.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>No suprimeix el fitxer .torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>Crea una subcarpeta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="362"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="367"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="372"/>
        <source>Maximum</source>
        <translation>Màxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="377"/>
        <source>Do not download</source>
        <translation>No ho baixis</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="274"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="702"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada / sortida</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="288"/>
        <source>Invalid torrent</source>
        <translation>Torrent no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>Renaming</source>
        <translation>Canvi de nom</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="498"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="523"/>
        <source>Rename error</source>
        <translation>Error de canvi de nom</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="499"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>El nom està buit o conté caràcters prohibits. Si us plau, trieu-ne un altre de diferent.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="728"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="729"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="737"/>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="323"/>
        <source>Invalid magnet link</source>
        <translation>Enllaç magnètic no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="274"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>No existeix el fitxer torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>No s&apos;ha pogut llegir el fitxer torrent &apos;%1&apos; des del disc. És possible que no teniu suficients permissos.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="288"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>No ha estat possible carregar el Torrent: %1
Error: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="300"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="334"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="339"/>
        <source>Already in the download list</source>
        <translation>Ja és a la llista de baixades.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="300"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="334"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers weren&apos;t merged because it is a private torrent.</source>
        <translation>El torrent &quot;%1&quot; ja és a la llista de baixades. Els rastrejadors no s&apos;han fusionat perquè és un torrent privat.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>El torrent &quot;%1&quot; ja és a la llista de baixades. S&apos;han fusionat els rastrejadors.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Cannot add torrent</source>
        <translation>No es pot afegir el torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>No s&apos;ha pogut afegir aquest torrent. Potser encara està en estat d&apos;addició.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="323"/>
        <source>This magnet link was not recognized</source>
        <translation>Aquest enllaç magnètic no s&apos;ha reconegut.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="339"/>
        <source>Magnet link &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>L&apos;enllaç magnètic &quot;%1&quot; ja és a la llista de baixades. S&apos;han fusionat els rastrejadors.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>No s&apos;ha pogut afegir aquest torrent. Potser ja s&apos;està afegint.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="352"/>
        <source>Magnet link</source>
        <translation>Enllaç magnètic</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="358"/>
        <source>Retrieving metadata...</source>
        <translation>S&apos;estan rebent les metadades...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="443"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="445"/>
        <source>Free space on disk: %1</source>
        <translation>Espai lliure al disc: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="100"/>
        <source>Choose save path</source>
        <translation>Trieu el camí de desament</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>New name:</source>
        <translation>Nom nou:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="524"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="562"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja s&apos;usa en aquesta carpeta. Utilitzeu-ne un de diferent.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="561"/>
        <source>The folder could not be renamed</source>
        <translation>No es pot canviar el nom de la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="606"/>
        <source>Rename...</source>
        <translation>Canvia&apos;n el nom...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="610"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="703"/>
        <source>Invalid metadata</source>
        <translation>Metadades no vàlides</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="710"/>
        <source>Parsing metadata...</source>
        <translation>S&apos;estan analitzant les metadades...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="714"/>
        <source>Metadata retrieval complete</source>
        <translation>S&apos;ha completat la recuperació de metadades</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="768"/>
        <source>Download Error</source>
        <translation>Error de baixada</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="234"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="345"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Ports de sortida (Min.) [0: desactivat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Ports de sortida (Màx.) [0: desactivat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="360"/>
        <source>Recheck torrents on completion</source>
        <translation>Verifica el torrents completats</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="366"/>
        <source>Transfer list refresh interval</source>
        <translation>Interval d&apos;actualització de la llista de transferència</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="365"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="115"/>
        <source>Setting</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="115"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="230"/>
        <source> (disabled)</source>
        <translation>(inhabilitat)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="232"/>
        <source> (auto)</source>
        <translation>(automàtic)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="245"/>
        <source>All addresses</source>
        <translation>Totes les adreces</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="282"/>
        <source>qBittorrent Section</source>
        <translation>Secció de qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="284"/>
        <location filename="../gui/advancedsettings.cpp" line="289"/>
        <source>Open documentation</source>
        <translation>Obre la documentació</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="287"/>
        <source>libtorrent Section</source>
        <translation>Secció de libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="303"/>
        <source>Disk cache</source>
        <translation>Cau del disc</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="308"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="309"/>
        <source>Disk cache expiry interval</source>
        <translation>Interval d&apos;expiració de la memòria cau del disc</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="312"/>
        <source>Enable OS cache</source>
        <translation>Habilita la memòria cau del sistema operatiu.</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="315"/>
        <source>Guided read cache</source>
        <translation>Lectura de cau guiada</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="318"/>
        <source>Send upload piece suggestions</source>
        <translation>Envia suggeriments de càrrega de trossos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="322"/>
        <location filename="../gui/advancedsettings.cpp" line="327"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="324"/>
        <source>Send buffer watermark</source>
        <translation>Envia la marca d&apos;aigua de la memòria intermèdia</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="329"/>
        <source>Send buffer low watermark</source>
        <translation>Envia la marca d&apos;aigua feble de la memòria intermèdia</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="334"/>
        <source>Send buffer watermark factor</source>
        <translation>Envia el factor la marca d&apos;aigua de la memòria intermèdia</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="339"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="357"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Permet connexions múltiples des de la mateixa adreça IP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="369"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Resol els països dels parells (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="372"/>
        <source>Resolve peer host names</source>
        <translation>Resol els noms d&apos;amfitrió dels parells</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source>Strict super seeding</source>
        <translation>Supersembra estricta</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interfície de xarxa (requereix reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="408"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Adreça IP opcional per vincular (requereix un reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Contacta en adreça IPv6 (requereix reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="419"/>
        <source>Display notifications</source>
        <translation>Mostra notificacions</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Display notifications for added torrents</source>
        <translation>Mostra notificacions per als torrents afegits</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="425"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Baixa la icona de web del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="429"/>
        <source>Save path history length</source>
        <translation>Desa la llargada de l&apos;historial de camins</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="441"/>
        <source>Upload slots behavior</source>
        <translation>Comportament de les ranures de pujada</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="445"/>
        <source>Upload choking algorithm</source>
        <translation>Algorisme d&apos;ofec de pujada</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="457"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirma la comprovació del torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="461"/>
        <source>Confirm removal of all tags</source>
        <translation>Confirmació de supressió de totes les etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="465"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Sempre anuncia a tots els rastrejadors en un nivell</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="469"/>
        <source>Always announce to all tiers</source>
        <translation>Sempre anuncia a tots els nivells</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="382"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Qualsevol interfície</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="340"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Desa l&apos;interval de represa de dades</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="354"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>Algorisme de mode mesclat %1-TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="377"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Nombre màxim de connexions mig obertes [0: il·limitades]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="414"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Adreça IP per notificar als rastrejadors (requereix reinici)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="432"/>
        <source>Enable embedded tracker</source>
        <translation>Habilita el rastrejador integrat</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="437"/>
        <source>Embedded tracker port</source>
        <translation>Port d&apos;integració del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="449"/>
        <source>Check for software updates</source>
        <translation>Cerca actualitzacions del programari</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="453"/>
        <source>Use system icon theme</source>
        <translation>Utilitza les icones del tema del sistema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="149"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciat</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="290"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, s&apos;executa un programa extern, ordre: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="299"/>
        <source>Torrent: %1, run external program command too long (length &gt; %2), execution failed.</source>
        <translation>Torrent: %1, ordre de programa d&apos;execució externa massa llarga (llargada &gt; %2), n&apos;ha fallat l&apos;execució.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="323"/>
        <source>Torrent name: %1</source>
        <translation>Nom del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="324"/>
        <source>Torrent size: %1</source>
        <translation>Mida del torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="325"/>
        <source>Save path: %1</source>
        <translation>Camí de desament: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="326"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>El Torrent s&apos;ha baixat: %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="328"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Gràcies per utilitzar el qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="335"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &quot;%1&quot; ha acabat de baixar.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="349"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, enviant notificació per e-mail</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="510"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="511"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Per controlar el qBittorrent, accediu a la interfície web a http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="512"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>El nom d&apos;usuari de l&apos;administrador de la interfície web és: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="515"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>La contrasenya de l&apos;administrador de la interfície web encara és l&apos;original: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="516"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Això és un risc de seguretat, considereu canviar la vostra contrasenya a la configuració del programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="678"/>
        <source>Saving torrent progress...</source>
        <translation>S&apos;està desant el progrés del torrent...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="735"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation>El mode portable i les opcions explícites de perfil de directori són mútuament excloents.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="738"/>
        <source>Portable mode implies relative fastresume</source>
        <translation>El mode portable implica una represa ràpida relativa.</translation>
    </message>
</context>
<context>
    <name>AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="115"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>No s&apos;han pogut desar les dades del Descarregador automàtic d&apos;RSS a %1: Error: %2.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="263"/>
        <source>Invalid data format</source>
        <translation>Format de dades no vàlid.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="371"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>No s&apos;han pogut llegir les regles del Descarregador automàtic d&apos;RSS de %1: Error: %2.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="383"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>No s&apos;han pogut carregar les regles del Descarregador automàtic d&apos;RSS. Raó: %1.</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="229"/>
        <source>Save to:</source>
        <translation>Desa a:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Baixades per RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Ara la baixada de torrents RSS està inhabilitada! Podeu habilitar-la als paràmetres de l&apos;aplicació.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Regles de baixada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Definició de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Utilitza expressions regulars</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Ha de contenir:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>No ha de contenir:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Filtra l&apos;episodi:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="201"/>
        <source>Assign Category:</source>
        <translation>Assigna la categoria:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="217"/>
        <source>Save to a Different Directory</source>
        <translation>Desa en un directori diferent</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="257"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignora les coincidències subseqüents durant (0 per a desactivar) </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source>Disabled</source>
        <translation>Inhabilitat</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="270"/>
        <source> days</source>
        <translation>dies</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Add Paused:</source>
        <translation>Afegeix en pausa:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="311"/>
        <source>Use global settings</source>
        <translation>Utilitza la configuració global</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="316"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="321"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="342"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplica la regla als canals:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="364"/>
        <source>Matching RSS Articles</source>
        <translation>Coincidència d&apos;articles RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="392"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importació...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="402"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportació...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Emparella articles basant-se en el filtre d&apos;episodis.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Example: </source>
        <translation>Exemple:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>emparellarà 2, 5 i 8 a través del 15 i 30 i els propers episodis de la primera temporada</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Episode filter rules: </source>
        <translation>Regles del filtre d&apos;episodis:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>El número de temporada ha de ser un valor diferent de zero.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Filter must end with semicolon</source>
        <translation>El filtre ha d&apos;acabar en punt i coma.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Three range types for episodes are supported: </source>
        <translation>S&apos;admeten tres tipus d&apos;intervals per als episodis:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Un únic número: &lt;b&gt;1x25;&lt;b&gt; emparella l&apos;episodi 25 de la temporada u.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Interval normal: &lt;b&gt;1x25-40;&lt;b&gt; emparella de l&apos;episodi 25 al 40 de la primera temporada.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>El número d&apos;episodi ha de ser un valor positiu.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="62"/>
        <source>Rules</source>
        <translation>Regles</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules (legacy)</source>
        <translation>Regles (llegat)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Interval infinit: &lt;b&gt;1x25-;&lt;/b&gt; emparella 25 episodis i més enllà de la primera temporada, i tots els episodis de les darreres temporades.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="270"/>
        <source>Last Match: %1 days ago</source>
        <translation>Darrer aparellament: fa %1 dies</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="272"/>
        <source>Last Match: Unknown</source>
        <translation>Darrer aparellaent: desconegut</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="353"/>
        <source>New rule name</source>
        <translation>Nom de la nova regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="353"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Escriviu el nom de la nova regla de baixada.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="358"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="504"/>
        <source>Rule name conflict</source>
        <translation>Conflicte amb el nom de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="359"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="505"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Ja existeix una regla amb aquest nom, trieu-ne un altre.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="373"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Esteu segur que voleu suprimir la regla de baixada anomenada «%1»?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="375"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Esteu segur que voleu suprimir les regles de baixada seleccionades?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="376"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmació de supressió de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="385"/>
        <source>Destination directory</source>
        <translation>Directori de destinació</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="393"/>
        <source>Invalid action</source>
        <translation>Acció no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="394"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>La llista està buida, no hi ha res per exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="400"/>
        <source>Export RSS rules</source>
        <translation>Exporta regles d&apos;RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="423"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="440"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada / sortida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="424"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Ha fallat crear el fitxer de destinació. Raó: %1.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <source>Import RSS rules</source>
        <translation>Importa regles d&apos;RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="441"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Ha fallat obrir el fitxer. Raó: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="456"/>
        <source>Import Error</source>
        <translation>Error d&apos;importació</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="457"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Ha fallat importar el fitxer de regles seleccionat. Raó: %1.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="464"/>
        <source>Add new rule...</source>
        <translation>Afegeix una regla nova...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="470"/>
        <source>Delete rule</source>
        <translation>Suprimeix la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="472"/>
        <source>Rename rule...</source>
        <translation>Canvia el nom de la regla...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="475"/>
        <source>Delete selected rules</source>
        <translation>Suprimeix les regles seleccionades</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="498"/>
        <source>Rule renaming</source>
        <translation>Canvi de nom de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="498"/>
        <source>Please type the new rule name</source>
        <translation>Escriviu el nou nom de la regla</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="615"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Mode d&apos;expressió regular: usa expressions regulars compatibles amb Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="657"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="695"/>
        <source>Position %1: %2</source>
        <translation>Posició: %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="618"/>
        <source>Wildcard mode: you can use</source>
        <translation>Mode de comodí: podeu usar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="619"/>
        <source>? to match any single character</source>
        <translation>? per substituir qualsevol caràcter simple</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="620"/>
        <source>* to match zero or more of any characters</source>
        <translation>* per substituir o bé res o bé qualsevol altre nombre de caràcters.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="621"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Els espais en blanc compten com a operadors I (totes les paraules, en qualsevol ordre)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="622"/>
        <source>| is used as OR operator</source>
        <translation>| s&apos;usa com a operador OR</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="623"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Si l&apos;ordre de paraules és important, useu * en comptes de l&apos;espai en blanc.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="630"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Una expressió amb una subordinada %1 buida (p. e. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="634"/>
        <source> will match all articles.</source>
        <translation>coincidirà amb tots els articles.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="635"/>
        <source> will exclude all articles.</source>
        <translation>exclourà tots els articles.</translation>
    </message>
</context>
<context>
    <name>BanListOptions</name>
    <message>
        <location filename="../gui/banlistoptions.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Llistat d&apos;adreces IP prohibides</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="77"/>
        <source>Ban IP</source>
        <translation>Prohibeix la IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="84"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="84"/>
        <location filename="../gui/banlistoptions.cpp" line="94"/>
        <source>Warning</source>
        <translation>Advertència</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="84"/>
        <source>The entered IP address is invalid.</source>
        <translation>La adreça IP introduïda no és vàlida.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="94"/>
        <source>The entered IP is already banned.</source>
        <translation>L&apos;adreça IP que heu introduït ja estava prohibida.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="580"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>És necessari reiniciar per activar suport PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1227"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>No s&apos;ha pogut obtenir el GUID de la interfície de xarxa configurada. Es vincula a la IP %1.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1729"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Rastrejador integrat [activat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1731"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Error en iniciar el rastrejador integrat!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1734"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Rastrejador integrat [apagat]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2392"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Estat de la xarxa del sistema canviat a %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2392"/>
        <source>ONLINE</source>
        <translation>EN LÍNIA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2392"/>
        <source>OFFLINE</source>
        <translation>FORA DE LÍNIA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2414"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>S&apos;ha canviat la configuració de xarxa de %1, es reinicia la vinculació de la sessió.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2431"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>L&apos;adreça %1 de la interfície de la xarxa configurada no és vàlida.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2770"/>
        <source>Encryption support [%1]</source>
        <translation>Suport per al xifratge [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2771"/>
        <source>FORCED</source>
        <translation>FORÇAT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2895"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 no és una adreça IP vàlida i s&apos;ha rebutjat en intentar aplicar-la al llistat d&apos;adreces prohibides.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3119"/>
        <source>Anonymous mode [%1]</source>
        <translation>Mode anònim [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3545"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>No s&apos;han pogut descodificar «%1» fitxers de torrent.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3682"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Baixada recursiva del fitxer «%1» integrat al torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3781"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>Les posicions de la cua s&apos;han corregit en %1 fitxers de represa</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4007"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>No s&apos;ha pogut desar «%1.torrent»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4057"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; s&apos;ha suprimit de la llista de transferència.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4070"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; s&apos;ha suprimit de la llista de transferència i del disc.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4082"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; s&apos;ha suprimit de la llista de transferència però no se n&apos;han pogut suprimir els fitxers. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4142"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>perquè %1 està inhabilitat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4145"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>perquè %1 està inhabilitat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4163"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Ha fallat la cerca d&apos;URL de llavor per a l&apos;URL: %1, missatge: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4209"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>El qBittorrent no ha pogut escoltar el port %2%3 de la interfície %1. Raó: %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2061"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>S&apos;està baixant «%1»; espereu, si us plau...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1191"/>
        <location filename="../base/bittorrent/session.cpp" line="2508"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>El qBittorrent està intentant contactar amb algun port d&apos;interfície: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2450"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>La interfície de la xarxa definida no és vàlida:%1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1204"/>
        <location filename="../base/bittorrent/session.cpp" line="2519"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>El qBittorrent està intentant contactar amb la interfície %1 del port: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <source>DHT support [%1]</source>
        <translation>Suport de DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <location filename="../base/bittorrent/session.cpp" line="2771"/>
        <location filename="../base/bittorrent/session.cpp" line="3119"/>
        <source>ON</source>
        <translation>SÍ</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <location filename="../base/bittorrent/session.cpp" line="2771"/>
        <location filename="../base/bittorrent/session.cpp" line="3119"/>
        <source>OFF</source>
        <translation>NO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Suport local de descobriment de parells [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1779"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&quot;%1&quot; ha assolit a la ràtio màxima que heu establert. Suprimit.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1784"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&quot;%1&quot; ha assolit a la ràtio màxima que heu establert. Pausat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1803"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&quot;%1&quot; ha assolit el temps de sembra màxim que heu establert. Suprimit.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1808"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&quot;%1&quot; ha assolit el temps de sembra màxim que heu establert. Pausat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2484"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>El qBittorrent no ha trobat una adreça local %1 per a contactar-hi</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2512"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>El qBittorrent ha fallat en intentar contactar amb algun port d&apos;interfície: %1. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3456"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>S&apos;ha afegit el rastrejador «%1» al torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3466"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>S&apos;ha suprimit el rastrejador «%1» del torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3481"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>S&apos;ha afegit l&apos;URL de llavor «%1» al torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3487"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>S&apos;ha suprimit l&apos;URL de llavor «%1» del torrent «%2»</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3730"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Impossible reprendre el torrent «%1».</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3815"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>S&apos;ha analitzat satisfactòriament el filtre IP: s&apos;han aplicat %1 regles.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3825"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Error: Ha fallat l&apos;anàlisi del filtre IP proporcionat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4041"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>No s&apos;ha pogut afegir el torrent: &quot;%1&quot;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3990"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>«%1» reprès. (represa ràpida)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4017"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; afegit a la llista de baixades.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4106"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>S&apos;ha produït un error d&apos;entrada / sortida, &quot;%1&quot; en pausa. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4114"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Ha fallat el mapatge del port, missatge: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4120"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapatge del port reeixit, missatge: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4130"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>a causa del filtre IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4133"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>a causa del filtre de ports.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4136"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>a causa de restriccions de mode mixtes i2p.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4139"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>perquè te un port baix.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4183"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>El qBittorrent està contactant satisfactòriament amb la interfície %1 del port: %2%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4218"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externa: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1472"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>No s&apos;ha pogut moure el torrent: &apos;%1&apos;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1650"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>La mida del fitxer no coincideix amb el torrent «%1», es posa en pausa.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1656"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>S&apos;han negat les dades per a la represa ràpida del torrent «%1». Raó: %2. S&apos;està comprovant de nou... </translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="242"/>
        <source>Categories</source>
        <translation>Categories</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="396"/>
        <source>All</source>
        <translation>Totes</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="403"/>
        <source>Uncategorized</source>
        <translation>Sense categoria</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="115"/>
        <source>Add category...</source>
        <translation>Afegeix una categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="123"/>
        <source>Add subcategory...</source>
        <translation>Afegeix una subcategoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="129"/>
        <source>Edit category...</source>
        <translation>Edita la categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="134"/>
        <source>Remove category</source>
        <translation>Suprimeix la categoria</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="140"/>
        <source>Remove unused categories</source>
        <translation>Suprimeix les categories no utilitzades</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="147"/>
        <source>Resume torrents</source>
        <translation>Reprèn els torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="152"/>
        <source>Pause torrents</source>
        <translation>Pausa els torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="157"/>
        <source>Delete torrents</source>
        <translation>Suprimeix els torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Gestió de galetes</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Domini</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Camí</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Data de caducitat</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="49"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Esteu segur que voleu suprimir «%1» de la llista de transferència?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="51"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Esteu segur que voleu suprimir aquests %1 torrents de la llista de transferència?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>Blanc: trossos que falten</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>Verd: trossos parcials</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>Blau: trossos completats</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="39"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation>IPs bloquejades</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="108"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; ha estat blocat %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="110"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; s&apos;ha prohibit</translation>
    </message>
</context>
<context>
    <name>Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="192"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Ha fallat baixar el canal RSS a &quot;%1&quot;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="202"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Ha fallat analitzar el canal RSS a &quot;1%&quot;. Raó: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="229"/>
        <source>RSS feed at &apos;%1&apos; successfully updated. Added %2 new articles.</source>
        <translation>S&apos;ha actualitzat correctament el canal RSS a &quot;1%&quot;. S&apos;han afegit %2 articles nous.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="251"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>No s&apos;han pogut llegir les dades de la sessió RSS de %1. Error: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="262"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>No s&apos;han pogut analitzar les dades de la sessió RSS. Error: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="268"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>No s&apos;han pogut carregar les dades de la sessió RSS. Format de dades no vàlid.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="277"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>No s&apos;ha pogut carregar l&apos;article RSS &quot;%1#%2&quot;. Format de dades no vàlid.</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="49"/>
        <source>RSS feeds</source>
        <translation>Canals RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="61"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="115"/>
        <source>Unread  (%1)</source>
        <translation>Sense llegir  (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="168"/>
        <source>An error occured while trying to open the log file. Logging to file is disabled.</source>
        <translation>Error en intentar obrir el fitxer de diari. L&apos;enregistrament al fitxer està desactivat.</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="55"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="57"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Navega...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="59"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Trieu un fitxer</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="61"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Trieu una carpeta</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="276"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="438"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Error d&apos;entrada / sortida: no s&apos;ha pogut obrir el fitxer de filtres IP en mode de lectura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="344"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>La línia %1 de filtre de la IP està malformada.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="222"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="362"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>La línia %1 de filtre de la IP està malformada. La IP de l&apos;inici de l&apos;interval està malformada.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="231"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="371"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>La línia %1 de filtre de la IP està malformada. La IP del final de l&apos;interval està malformada.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="239"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="379"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>La línia %1 de filtre de la IP està malformada. Una IP és IPv4 i l&apos;altra és IPv6!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="253"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="392"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>S&apos;ha produït l&apos;excepció de filtre IP a la línia %1. L&apos;excepció és %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="263"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="402"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>Hi ha hagut %1 errors d&apos;anàlisi de filtre IP extra.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="449"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="482"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="491"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="511"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="531"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Error d&apos;anàlisi: el fitxer de filtre no és un fitxer PeerGuardian P2B vàlid.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="97"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="127"/>
        <source>Unsupported database file size.</source>
        <translation>La mida del fitxer de base de dades no és suportada.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="226"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Error de metadades: «%1» entrades no trobades.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="227"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Error de metadades: «%1» entrades tenen una escriptura no vàlida.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versió de base de dades no suportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="243"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versió IP no suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="250"/>
        <source>Unsupported record size: %1</source>
        <translation>Mida de registre no suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="263"/>
        <source>Invalid database type: %1</source>
        <translation>Tipus de base de dades no vàlida: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="284"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Base de dades corrupta: no s&apos;ha trobat secció de dades.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Exit qBittorrent</source>
        <translation>Surt del qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Only one link per line</source>
        <translation>Només un enllaç per línia</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de pujada ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de baixada ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de pujada alternatiu ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>El límit de baixada alternativa ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>El màxim de baixades actives ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>El màxim de pujades actives ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>El màxim de torrents actius ha de ser major de -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limiti de connexions ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim del limit de connexions per torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>El nombre màxim de pujades de ranures per torrent ha de ser major que 0 o estar inhabilitat.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>No es poden desar les preferències del programa, probablement el qBittorrent no és accessible.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent a Freenode</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Invalid category name:
Please do not use any special characters in the category name.</source>
        <translation>Nom de categoria no vàlid:
Si us plau, no useu caràcters especials al nom de la categoria.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Hard Disk</source>
        <translation>Disc dur</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>El límit de la ràtio de compartició ha de ser entre 0 i 9998.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>El límit de la sembra ha de ser entre 0 i 525600 minuts.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>El port utilitzat per a connexions entrants ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>El port utilitzat per a la interfície d&apos;usuari web ha de ser major de 1024 i menor de 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>No ha estat possible iniciar sessió, el qBittorrent deu estar il·localitzable en aquests moments. </translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>Invalid Username or Password.</source>
        <translation>Nom d&apos;usuari o contrasenya incorrectes.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>Username</source>
        <translation>Nom d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Password</source>
        <translation>Contrasenya</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Login</source>
        <translation>Inicia sessió</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>Original authors</source>
        <translation>Autors originals</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>Apply</source>
        <translation>Aplica</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Add</source>
        <translation>Afegeix</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Puja torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Save files to location:</source>
        <translation>Desa els fitxers a la ubicació:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Type folder here</source>
        <translation>Escriviu la carpeta aquí</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>More information</source>
        <translation>Més informació</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Information about certificates</source>
        <translation>Informació sobre certificats</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Save Files to</source>
        <translation>Desa els fitxes a</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Set location</source>
        <translation>Estableix la ubicació</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Limit upload rate</source>
        <translation>Limita la ràtio de pujada</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Limit download rate</source>
        <translation>Limita la ràtio de baixada</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Rename torrent</source>
        <translation>Canvia de nom el torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Altres ...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Dilluns</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Dimarts</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Dimecres</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Dijous</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Divendres</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Dissabte</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Diumenge</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>Logout</source>
        <translation>Tanca la sessió</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Baixa torrents des dels URL o enllaços magnètics</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Upload local torrent</source>
        <translation>Puja torrent locals</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Esteu segur que voleu suprimir els torrent seleccionats de la llista de transferències?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>qBittorrent client is not reachable</source>
        <translation>El client qBittorrent no és accessible</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>El qBittorrent s&apos;ha apagat.</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Llista de subxarxes IP en llista blanca</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exemple: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="60"/>
        <source>Add subnet</source>
        <translation>Afegeix una subxarxa</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="67"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>The entered subnet is invalid.</source>
        <translation>La subxarxa introduïda no és vàlida</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Clear</source>
        <translation>Neteja</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Eines</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Fitxer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>En acabar les baixa&amp;des...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="98"/>
        <source>&amp;View</source>
        <translation>&amp;Visualitza</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="179"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opcions...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="189"/>
        <source>&amp;Resume</source>
        <translation>&amp;Reprèn</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="222"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Creador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="227"/>
        <source>Set Upload Limit...</source>
        <translation>Establiu límit de pujada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="232"/>
        <source>Set Download Limit...</source>
        <translation>Establiu límit de baixada...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="242"/>
        <source>Set Global Download Limit...</source>
        <translation>Establiu límit de baixada global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="247"/>
        <source>Set Global Upload Limit...</source>
        <translation>Establiu límit de pujada global...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Minimum Priority</source>
        <translation>Prioritat mínima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Top Priority</source>
        <translation>Prioritat màxima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="268"/>
        <source>Decrease Priority</source>
        <translation>Disminueix-ne la prioritat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="276"/>
        <source>Increase Priority</source>
        <translation>Incrementa&apos;n la prioritat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="287"/>
        <location filename="../gui/mainwindow.ui" line="290"/>
        <source>Alternative Speed Limits</source>
        <translation>Límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="298"/>
        <source>&amp;Top Toolbar</source>
        <translation>Barra d&apos;eines &amp;superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="301"/>
        <source>Display Top Toolbar</source>
        <translation>Mostra barra d&apos;eines superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="309"/>
        <source>Status &amp;Bar</source>
        <translation>&amp;Barra d&apos;estat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="317"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>Mostra v&amp;elocitat a la barra de títol</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="320"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostra velocitat de transferència a la barra de títol</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="328"/>
        <source>&amp;RSS Reader</source>
        <translation>Lector &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="336"/>
        <source>Search &amp;Engine</source>
        <translation>&amp;Motor de cerca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="341"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>B&amp;loca el qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="352"/>
        <source>Do&amp;nate!</source>
        <translation>Feu una do&amp;nació!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="199"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;eprèn-ho tot</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="423"/>
        <source>Manage Cookies...</source>
        <translation>Gestió de galetes...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="426"/>
        <source>Manage stored network cookies</source>
        <translation>Gestió de galetes de xarxa emmagatzemades</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="442"/>
        <source>Normal Messages</source>
        <translation>Missatges normals</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="450"/>
        <source>Information Messages</source>
        <translation>Missatges informatius</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="458"/>
        <source>Warning Messages</source>
        <translation>Missatges d&apos;advertència</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="466"/>
        <source>Critical Messages</source>
        <translation>Missatges crítics</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="102"/>
        <source>&amp;Log</source>
        <translation>&amp;Registre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="363"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Tanca el qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="371"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspèn el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="379"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hiberna el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="387"/>
        <source>S&amp;hutdown System</source>
        <translation>A&amp;paga el sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="395"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Inhabilitat</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="410"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Estadístiques</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="415"/>
        <source>Check for Updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="418"/>
        <source>Check for Program Updates</source>
        <translation>Cerca actualitzacions del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="184"/>
        <source>&amp;About</source>
        <translation>&amp;Quant a</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="194"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="209"/>
        <source>&amp;Delete</source>
        <translation>&amp;Suprimeix</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="204"/>
        <source>P&amp;ause All</source>
        <translation>Pausa-ho tot</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="166"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Afegeix un fitxer de torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>E&amp;xit</source>
        <translation>T&amp;anca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="217"/>
        <source>Open URL</source>
        <translation>Obre un URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="237"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentació</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="344"/>
        <source>Lock</source>
        <translation>Bloca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="400"/>
        <location filename="../gui/mainwindow.ui" line="434"/>
        <location filename="../gui/mainwindow.cpp" line="1623"/>
        <source>Show</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1827"/>
        <source>Check for program updates</source>
        <translation>Cerca actualitzacions del programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="214"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Afegeix un &amp;enllaç de torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="355"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Si us agrada el qBittorrent, feu una donació!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1861"/>
        <source>Execution Log</source>
        <translation>Execució Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Clear the password</source>
        <translation>Neteja la contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="233"/>
        <source>Filter torrent list...</source>
        <translation>Filtra la llista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="203"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Estableix contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="171"/>
        <source>Preferences</source>
        <translation>Preferències</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="205"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Neteja la contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="256"/>
        <source>Transfers</source>
        <translation>Transferint</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="452"/>
        <source>Torrent file association</source>
        <translation>Associació de fitxers torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="453"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>El qBittorrent no és l&apos;aplicació predeterminada per obrir fitxers torrent o enllaços magnètics.
Voleu que el qBittorrent sigui el programa predeterminat per gestionar aquests fitxers?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="536"/>
        <source>Icons Only</source>
        <translation>Només icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="538"/>
        <source>Text Only</source>
        <translation>Només text</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="540"/>
        <source>Text Alongside Icons</source>
        <translation>Text al costat de les icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="542"/>
        <source>Text Under Icons</source>
        <translation>Text sota les icones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="544"/>
        <source>Follow System Style</source>
        <translation>Segueix l&apos;estil del sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1003"/>
        <source>UI lock password</source>
        <translation>Contrasenya de bloqueig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1003"/>
        <source>Please type the UI lock password:</source>
        <translation>Escriviu la contrasenya de bloqueig:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Com a mínim la contrasenya ha de tenir 3 caràcters</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>Password update</source>
        <translation>Actualització de contrasenya</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>La contrasenya de bloqueig del qBittorrent s&apos;ha actualitzat correctament</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Esteu segurs que voleu netejar la contrasenya?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="704"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>Transfers (%1)</source>
        <translation>Transferències (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="816"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="816"/>
        <source>Failed to add torrent: %1</source>
        <translation>No ha estat possible afegir el torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>Torrent added</source>
        <translation>Torrent afegit</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>S&apos;ha afegit &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="829"/>
        <source>Download completion</source>
        <translation>Baixada completada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="835"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Error d&apos;entrada / sortida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="920"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmació de baixades recursives</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="921"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="922"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="923"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="945"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="960"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat límit global de baixada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1026"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>El qBittorrent s&apos;ha actualitzat i s&apos;ha de reiniciar perquè els canvis tinguin efecte.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1123"/>
        <source>Some files are currently transferring.</source>
        <translation>Ara s&apos;estan transferint alguns fitxers.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1123"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Segur que voleu sortir del qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1125"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1126"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1127"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Sempre sí</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1522"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1746"/>
        <source>Old Python Interpreter</source>
        <translation>Intèrpret de Python antic</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1746"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>La vostra versió de Python (%1) no està actualitzada. Actualitzeu a la darrera versió per que funcionin els motors de cerca.
Versió mínima requerida: 2.7.9/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1811"/>
        <source>qBittorrent Update Available</source>
        <translation>Actualització del qBittorrent disponible</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1812"/>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation>Hi ha una versió nova disponible.
Voleu baixar la versió %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1821"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Ja feu servir la darrera versió del qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1756"/>
        <source>Undetermined Python version</source>
        <translation>Versió de Python no determinada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="829"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>«%1» ha acabat de baixar.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="835"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>S&apos;ha produït un error d&apos;entrada / sortida al torrent «%1».
Raó: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="920"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>El torrent «%1» conté fitxers torrent, voleu seguir endavant amb la baixada?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="935"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>No s&apos;ha pogut baixar el fitxer en l&apos;URL «%1», raó: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1728"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>S&apos;ha trobat Python a %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1756"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>No s&apos;ha pogut determinar la vostra versió de Python (%1). Motor de cerca inhabilitat.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1767"/>
        <location filename="../gui/mainwindow.cpp" line="1779"/>
        <source>Missing Python Interpreter</source>
        <translation>Falta intèrpret Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1768"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Es requereix Python per a fer servir el motor de cerca i sembla que no el teniu instal·lat.
Voleu instal·lar-lo ara?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1779"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Es requereix Python per a fer servir el motor de cerca i sembla que no el teniu instal·lat.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1822"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>No hi ha actualitzacions disponibles.
Esteu fent servir la darrera versió.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1826"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1985"/>
        <source>Checking for Updates...</source>
        <translation>Cercant actualitzacions...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1986"/>
        <source>Already checking for program updates in the background</source>
        <translation>Ja s&apos;estan cercant actualitzacions en segon terme</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2002"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python ha trobat en %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2071"/>
        <source>Download error</source>
        <translation>Error de baixada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2071"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>No ha estat possible baixar l&apos;instal·lador de Python, raó: 51.
Instal·leu-lo manualment.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <location filename="../gui/mainwindow.cpp" line="1018"/>
        <source>Invalid password</source>
        <translation>Contrasenya no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="672"/>
        <location filename="../gui/mainwindow.cpp" line="682"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="935"/>
        <source>URL download error</source>
        <translation>error al baixar l&apos;URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1018"/>
        <source>The password is invalid</source>
        <translation>La contrasenya no és vàlida.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1507"/>
        <location filename="../gui/mainwindow.cpp" line="1514"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Velocitat de baixada: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1510"/>
        <location filename="../gui/mainwindow.cpp" line="1516"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Velocitat de pujada: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1529"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[B: %1, P: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1623"/>
        <source>Hide</source>
        <translation>Amaga</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1121"/>
        <source>Exiting qBittorrent</source>
        <translation>S&apos;està sortint del qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1320"/>
        <source>Open Torrent Files</source>
        <translation>Obre fitxers de torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1321"/>
        <source>Torrent Files</source>
        <translation>Fitxers torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1371"/>
        <source>Options were saved successfully.</source>
        <translation>Opcions desades correctament.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>S&apos;ha actualitzat correctament el vostre DNS dinàmic.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Error de DNS dinàmica: El servei no està disponible temporalment, nou reintent en 30 minuts.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;amfitrió proporcionat no existeix en el compte especificat.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Error DNS dinàmica: nom d&apos;usuari/contrasenya no vàlides.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: el qBittorrent ha estat inclòs en la llista negra, informeu d&apos;això a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Error de DNS dinàmica: %1 ha estat rebutjat pel servei. Informeu d&apos;aquest error a http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Error de DNS dinàmica: El seu nom d&apos;usuari ha estat blocat degut a un abús.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari subministrat és massa curt.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari proporcionat és massa curt.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Error de DNS dinàmica: el nom d&apos;usuari subministrat és massa curt.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="105"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada / sortida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="118"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>La mida d&apos;aquest fitxer és de %1. Això excedeix el límit de baixada de %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="187"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redirecció no esperada a un URL magnètic.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="105"/>
        <location filename="../base/net/geoipmanager.cpp" line="434"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Base de dades GeoIP carregada. Tipus: %1. Temps de compilació: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="109"/>
        <location filename="../base/net/geoipmanager.cpp" line="455"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>No s&apos;ha pogut carregar la base de dades GeoIP. Raó: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Veneçuela, República Bolivariana de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Viet Nam</source>
        <translation>Viet Nam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Emirats Àrabs Units</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afganistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua i Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antarctica</source>
        <translation>Antàrtica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>American Samoa</source>
        <translation>Samoa Nord-americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Austria</source>
        <translation>Àustria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Australia</source>
        <translation>Austràlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>Azerbaidjan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bòsnia i Hercegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>Bangladeix</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Bèlgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgària</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>Benín</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahamas</source>
        <translation>Bahames</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bouvet Island</source>
        <translation>Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belarus</source>
        <translation>Bielorússia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Canada</source>
        <translation>Canadà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Illes Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Congo, República Democràtica del</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Central African Republic</source>
        <translation>República Centreafricana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Switzerland</source>
        <translation>Suïssa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cook Islands</source>
        <translation>Illes Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Chile</source>
        <translation>Xile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Cameroon</source>
        <translation>Camerun</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>China</source>
        <translation>Xina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Colombia</source>
        <translation>Colòmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cape Verde</source>
        <translation>Cap Verd</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Christmas Island</source>
        <translation>Illa Christmas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Cyprus</source>
        <translation>Xipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Czech Republic</source>
        <translation>República Txeca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Germany</source>
        <translation>Alemanya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Algeria</source>
        <translation>Algèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Ecuador</source>
        <translation>Equador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Estonia</source>
        <translation>Estònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Egypt</source>
        <translation>Egipte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Western Sahara</source>
        <translation>Sahara Occidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Spain</source>
        <translation>Espanya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Ethiopia</source>
        <translation>Etiòpia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Finland</source>
        <translation>Finlàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Illes Malvines (Falkland)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronèsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Faroe Islands</source>
        <translation>Illes Fèroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>United Kingdom</source>
        <translation>Regne Unit</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Georgia</source>
        <translation>Geòrgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>French Guiana</source>
        <translation>Guaiana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Greenland</source>
        <translation>Groenlàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gambia</source>
        <translation>Gàmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe (França)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Equatorial Guinea</source>
        <translation>Guinea Equatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greece</source>
        <translation>Grècia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Illes Geòrgia del Sud i Sandwich del Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Illes Heard i McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Honduras</source>
        <translation>Hondures</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Croatia</source>
        <translation>Croàcia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Haiti</source>
        <translation>Haití</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hungary</source>
        <translation>Hongria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Indonesia</source>
        <translation>Indonèsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>India</source>
        <translation>Índia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>British Indian Ocean Territory</source>
        <translation>Territori Britànic de l&apos;Oceà Índic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Iran</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Iceland</source>
        <translation>Islàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Italy</source>
        <translation>Itàlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Jordan</source>
        <translation>Jordània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Japan</source>
        <translation>Japó</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kenya</source>
        <translation>Kènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kyrgyzstan</source>
        <translation>Kirguizistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cambodia</source>
        <translation>Cambodja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint Christopher i Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Corea del Nord</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Korea, Republic of</source>
        <translation>Corea del Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Cayman Islands</source>
        <translation>Illes Caiman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lebanon</source>
        <translation>Líban</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Saint Lucia</source>
        <translation>Saint Lucia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Liberia</source>
        <translation>Libèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Lithuania</source>
        <translation>Lituània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Latvia</source>
        <translation>Letònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Morocco</source>
        <translation>Marroc</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Monaco</source>
        <translation>Mònaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Moldova, Republic of</source>
        <translation>Moldàvia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Marshall Islands</source>
        <translation>Illes Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mongolia</source>
        <translation>Mongòlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Northern Mariana Islands</source>
        <translation>Illes Mariannes Septentrionals</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Mauritania</source>
        <translation>Mauritània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mauritius</source>
        <translation>Maurici</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Maldives</source>
        <translation>Maldives</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mexico</source>
        <translation>Mèxic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malaysia</source>
        <translation>Malàsia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mozambique</source>
        <translation>Moçambic</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Namibia</source>
        <translation>Namíbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>New Caledonia</source>
        <translation>Nova Caledònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Norfolk Island</source>
        <translation>Illa Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nigeria</source>
        <translation>Nigèria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Netherlands</source>
        <translation>Països Baixos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>New Zealand</source>
        <translation>Nova Zelanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Panama</source>
        <translation>Panamà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>French Polynesia</source>
        <translation>Polinèsia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Papua New Guinea</source>
        <translation>Papua Nova Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Philippines</source>
        <translation>Filipines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Poland</source>
        <translation>Polònia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint-Pierre i Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Reunion</source>
        <translation>Reunió</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Romania</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Russian Federation</source>
        <translation>Federació Russa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Saudi Arabia</source>
        <translation>Aràbia Saudí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Solomon Islands</source>
        <translation>Illes Solomon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sudan</source>
        <translation>Sudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Sweden</source>
        <translation>Suècia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovenia</source>
        <translation>Eslovènia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard i Jan mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Slovakia</source>
        <translation>Eslovàquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Somalia</source>
        <translation>Somàlia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sao Tome and Principe</source>
        <translation>São Tomé i Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Syrian Arab Republic</source>
        <translation>República Àrab Siriana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Swaziland</source>
        <translation>Swazilàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Turks and Caicos Islands</source>
        <translation>Illes Turks i Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Chad</source>
        <translation>Txad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>French Southern Territories</source>
        <translation>Terres Australs i Antàrtiques Franceses</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Thailand</source>
        <translation>Tailàndia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tajikistan</source>
        <translation>Tadjikistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tunisia</source>
        <translation>Tuníssia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="423"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>No s&apos;ha pogut descomprimir el fitxer de base de dades GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Timor-Leste</source>
        <translation>Timor Oriental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolívia, Estat Plurinacional de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire, Sint Eustatius i Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Costa d&apos;Ivori</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Libya</source>
        <translation>Líbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Saint Martin (French part)</source>
        <translation>Sant Martí (part francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedònia, Antiga República Iugoslava de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Pitcairn</source>
        <translation>Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palestine, State of</source>
        <translation>Palestina, Estat de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Elena, Ascensió i Tristan da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>South Sudan</source>
        <translation>Sudan del Sud</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sant Martí (part holandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Turkey</source>
        <translation>Turquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinitat i Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzània</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Ukraine</source>
        <translation>Ucraïna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Illes Perifèriques Menors dels EUA</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>United States</source>
        <translation>Estats Units</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Ciutat del Vaticà</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Saint Vincent i les Grenadines</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, British</source>
        <translation>Illes Verges Britàniques</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Illes Verges Nord-americanes</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis i Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Yemen</source>
        <translation>Iemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Serbia</source>
        <translation>Sèrbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>South Africa</source>
        <translation>Sud Àfrica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zambia</source>
        <translation>Zàmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aland Islands</source>
        <translation>Illes Åland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Isle of Man</source>
        <translation>Illa de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Saint Barthelemy</source>
        <translation>Saint-Barthélemy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>No ha estat possible desar el fitxer de base de dades GeoIP baixat.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Base de dades GeoIP actualitzada correctament.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>No s&apos;ha pogut baixar la base de dades GeoIP. Raó: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="127"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Suport UPnP / NAT-PMP [Encès]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="143"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Suport UPnP / NAT-PMP [Apagat]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="509"/>
        <source>Email Notification Error:</source>
        <translation>Error de notificació de correu electrònic:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdlg.ui" line="14"/>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportament</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="57"/>
        <source>Downloads</source>
        <translation>Baixades</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="62"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="67"/>
        <source>Speed</source>
        <translation>Velocitat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>Bittorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="82"/>
        <source>Web UI</source>
        <translation>IU Web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avançat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="133"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>Llengua de la interfície d&apos;usuari:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(Requereix reiniciar el qBittorrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="197"/>
        <source>Transfer List</source>
        <translation>Llista de transferència</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation>Demana confirmació per suprimir torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Usa colors alterns a les files de la llista</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation>Amaga els valors zero i infinit</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="233"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation>Només els torrents pausats</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="267"/>
        <source>Action on double-click</source>
        <translation>Acció a fer amb un doble click</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation>Torrents de baixada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="293"/>
        <location filename="../gui/optionsdlg.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Aturar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="298"/>
        <location filename="../gui/optionsdlg.ui" line="324"/>
        <source>Open destination folder</source>
        <translation>Obre la carpeta de destinació</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="303"/>
        <location filename="../gui/optionsdlg.ui" line="329"/>
        <source>No action</source>
        <translation>Sense acció</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>Torrents completats:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="343"/>
        <source>Desktop</source>
        <translation>Escriptori</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Inicia el qBittorrent durant l&apos;arrencada de Windows</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation>Mostra la pantalla de benvinguda en iniciar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>Inicia el qBittorrent minimitzat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirma el tancament quan hi hagi torrents actius.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirma el tancament automàtic quan les baixades acabin.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1111"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Notificació per corre&amp;u electrònic de l&apos;acabament de les descàrregues</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1206"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Executa un programa e&amp;xtern en acabar el torrent.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1665"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Fi&amp;ltratge d&apos;IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1864"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Programació de l&apos;ús de lími&amp;ts de ràtio alternatius</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2261"/>
        <source>&amp;Torrent Queueing</source>
        <translation>Cua de &amp;torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2515"/>
        <source>minutes</source>
        <translation>minuts</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2522"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Sembra torrents fins que s&apos;esgoti el seu temps de sembra.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2538"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>Afegeix a&amp;utomàticament aquests rastrejadors a les baixades noves:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2611"/>
        <source>RSS Reader</source>
        <translation>Lector RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2617"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Habilita l&apos;obtenció de canals RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2626"/>
        <source>Feeds refresh interval:</source>
        <translation>Interval d&apos;actualització dels canals:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2636"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Nombre màxim d&apos;articles per canal:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2646"/>
        <source> min</source>
        <translation> min.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2690"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Descarregador automàtic de torrents RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2696"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Habilita baixades automàtiques de torrents RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2703"/>
        <source>Edit auto downloading rules...</source>
        <translation>Edita les regles de baixada automàtica...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2761"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Interfície d&apos;usuari web (control remot)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2775"/>
        <source>IP address:</source>
        <translation>Adreça IP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2782"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>Adreça IP amb què es vincularà la interfície web.
Especifiqueu una adreça IPv4 o IPv6. Podeu especificar &quot;0.0.0.0&quot; per a qualsevol adreça IPv4,
&quot;::&quot; per a qualsevol adreça IPv6 o bé &quot;*&quot; per a IPv4 i IPv6.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2815"/>
        <source>Server domains:</source>
        <translation>Dominis de servidor:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2822"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>Llista blanca per filtrar els valors de la capçalera de l&apos;amfitrió HTTP.
Per tal de defensar-se contra atacs de revinculació de DNS, hauríeu
d&apos;introduir noms de domini utilitzats pel servidor WebUI.

Useu &quot;;&quot; per separar les entrades. Podeu usar el comodí &quot;*&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2845"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>Usa HTTPS en lloc d&apos;HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3008"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Evita l&apos;autenticació per als clients en l&apos;amfitrió local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3015"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Evita l&apos;autenticació per als clients en subxarxes en la llista blanca</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3028"/>
        <source>IP subnet whitelist...</source>
        <translation>Llista blanca de subxarxes IP...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3052"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Actuali&amp;tza el meu nom de domini dinàmic</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimitza el qBittorrent a l&apos;àrea de notificació.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Tanca el qBittorrent a l&apos;àrea de notificació.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>Estil de la icona al plafó:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="429"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monochrome (Tema obscur)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monochrome (Tema clar)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="452"/>
        <source>File association</source>
        <translation>Associació de fitxers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Utilitzeu qBittorrent per obrir fitxers .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usa qBittorrent per a enllaços magnètics</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="478"/>
        <source>Power Management</source>
        <translation>Gestió de la bateria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="484"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Inhibiu la suspensió del sistema si hi ha torrents actius.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="514"/>
        <source>Save path:</source>
        <translation>Camí de desament:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="531"/>
        <source>Backup the log file after:</source>
        <translation>Feu una còpia del registre desprès de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="538"/>
        <source> MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="574"/>
        <source>Delete backup logs older than:</source>
        <translation>Suprimeix registres de còpia de seguretat més antics de...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="598"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>dies</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="603"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>mesos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="608"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>anys</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="682"/>
        <source>When adding a torrent</source>
        <translation>En afegir un torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="700"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Porteu el diàleg del Torrent al davant</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="723"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>No iniciïs la baixada de forma automàtica</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="730"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>S&apos;hauria de suprimir el fitxer de torrent després d&apos;afegir-lo?</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="745"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Suprimeix també els fitxers .torrent dels quals n&apos;hàgiu cancel·lat l&apos;addició.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="748"/>
        <source>Also when addition is cancelled</source>
        <translation>També quan hagi estat cancel·lada l&apos;addició.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="770"/>
        <source>Warning! Data loss possible!</source>
        <translation>Atenció! Es poden perdre dades!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="785"/>
        <source>Saving Management</source>
        <translation>Gestió del desament</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="793"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Mode de Gestió dels Torrents per definició:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="805"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>El Mode Automàtic significa que diverses propietats dels torrent (p.ex. camins de desament) es configuraran segons la categoria associada.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="809"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="814"/>
        <source>Automatic</source>
        <translation>Automàtic</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="837"/>
        <source>When Torrent Category changed:</source>
        <translation>En canviar la categoria del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="847"/>
        <source>Relocate torrent</source>
        <translation>Realltogeu el torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="852"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Canvieu el torrent a Mode Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="875"/>
        <source>When Default Save Path changed:</source>
        <translation>Quan es canvia el camí de desament per defecte:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="888"/>
        <location filename="../gui/optionsdlg.ui" line="929"/>
        <source>Relocate affected torrents</source>
        <translation>Reallotgeu els torrents afectats.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="893"/>
        <location filename="../gui/optionsdlg.ui" line="934"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Canvieu els torrents afectats a Mode Manual.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="916"/>
        <source>When Category changed:</source>
        <translation>En canviar la categoria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="959"/>
        <source>Use Subcategories</source>
        <translation>Usa subcategories</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="978"/>
        <source>Default Save Path:</source>
        <translation>Camí de desament per defecte:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="992"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Mantenir Torrents incomplets a:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="985"/>
        <source>Copy .torrent files to:</source>
        <translation>Copieu els fitxers torrent a:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Mostra el &amp;qBittorrent a l&apos;àrea de notificació.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="494"/>
        <source>&amp;Log file</source>
        <translation>Fit&amp;xer de registre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="688"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Mostra el contingut del &amp;torrent i algunes opcions</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="713"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>Crea una subcarpeta per als torrents amb fitxers múltiples.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="733"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>Su&amp;primeix els fitxers .torrent després.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="971"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copia els fitxers .torrent de les baixades acabades a:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1010"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Preassigna espai al disc per a tots els fitxers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1017"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Afegeix l&apos;extensió .!qB a fitxers incomplets</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1027"/>
        <source>Automatically add torrents from:</source>
        <translation>Afegeix torrents automàticament des de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1074"/>
        <source>Add entry</source>
        <translation>Afegeix una entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1084"/>
        <source>Remove entry</source>
        <translation>Suprimeix l&apos;entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1135"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1157"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>El servidor requereix una connexió segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1164"/>
        <location filename="../gui/optionsdlg.ui" line="2976"/>
        <source>Authentication</source>
        <translation>Autentificació</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1176"/>
        <location filename="../gui/optionsdlg.ui" line="1626"/>
        <location filename="../gui/optionsdlg.ui" line="3035"/>
        <location filename="../gui/optionsdlg.ui" line="3110"/>
        <source>Username:</source>
        <translation>Nom d&apos;usuari:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1186"/>
        <location filename="../gui/optionsdlg.ui" line="1636"/>
        <location filename="../gui/optionsdlg.ui" line="3042"/>
        <location filename="../gui/optionsdlg.ui" line="3124"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1274"/>
        <source>Enabled protocol:</source>
        <translation>Protocol habilitat:</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="1282"/>
        <source>TCP and μTP</source>
        <translation>TCP i μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1302"/>
        <source>Listening Port</source>
        <translation>Port d&apos;escolta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1310"/>
        <source>Port used for incoming connections:</source>
        <translation>Port utilitzat per a connexions entrants:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1330"/>
        <source>Random</source>
        <translation>Aleatori</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1352"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Utilitza UPnP / NAT-PMP reenviament de ports del router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1362"/>
        <source>Use different port on each startup</source>
        <translation>Usa un pot diferent a cada inici</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1372"/>
        <source>Connections Limits</source>
        <translation>Límits de connexió</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1388"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Nombre màxim de connexions per torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1398"/>
        <source>Global maximum number of connections:</source>
        <translation>Nombre global màxim de connexions:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1437"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Nombre màxim de ranures de pujada per torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1447"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Nombre global màxim de ranures de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1486"/>
        <source>Proxy Server</source>
        <translation>Servidor intermediaria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1494"/>
        <source>Type:</source>
        <translation>Tipus:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1502"/>
        <source>(None)</source>
        <translation>(Cap)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1507"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1512"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1517"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1528"/>
        <source>Host:</source>
        <translation>Amfitrió:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1548"/>
        <location filename="../gui/optionsdlg.ui" line="2791"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1576"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Per contra, el servidor intermediari s&apos;utilitzarà només per les connexions tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1579"/>
        <source>Use proxy for peer connections</source>
        <translation>Usa un servidor intermediari per a connexions d&apos;igual a igual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1586"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Inhabilita les connexions no admeses per servidors intermediaris</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1596"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Els canals RSS, motors de cerca, actualitzacions de programari o altres coses que no siguin transferències de torrent i operacions relacionades (com ara intercanvis de parells) faran servir una connexió directa.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1599"/>
        <source>Use proxy only for torrents</source>
        <translation>Utilitza el servidor intermediari només per als torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1612"/>
        <source>A&amp;uthentication</source>
        <translation>A&amp;utenticació</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1652"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Informació: la contrasenya es desa sense xifrar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1673"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Camí del filtre (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1689"/>
        <source>Reload the filter</source>
        <translation>Actualitza el filtre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1704"/>
        <source>Manually banned IP addresses...</source>
        <translation>Adreces IP prohibides manualment...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1711"/>
        <source>Apply to trackers</source>
        <translation>Aplica als rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1769"/>
        <source>Global Rate Limits</source>
        <translation>Límits de velocitat globals</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1791"/>
        <location filename="../gui/optionsdlg.ui" line="1982"/>
        <source>Upload:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1798"/>
        <location filename="../gui/optionsdlg.ui" line="1821"/>
        <location filename="../gui/optionsdlg.ui" line="2028"/>
        <location filename="../gui/optionsdlg.ui" line="2035"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1835"/>
        <location filename="../gui/optionsdlg.ui" line="1989"/>
        <source>Download:</source>
        <translation>Baixada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1858"/>
        <source>Alternative Rate Limits</source>
        <translation>Límits de velocitat alternatius</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1148"/>
        <location filename="../gui/optionsdlg.ui" line="1876"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Des de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1128"/>
        <location filename="../gui/optionsdlg.ui" line="1900"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>A:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1927"/>
        <source>When:</source>
        <translation>Quan:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1941"/>
        <source>Every day</source>
        <translation>Cada dia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1946"/>
        <source>Weekdays</source>
        <translation>De dilluns a divendres</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1951"/>
        <source>Weekends</source>
        <translation>Caps de setmana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2058"/>
        <source>Rate Limits Settings</source>
        <translation>Paràmetres dels límits de velocitat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2078"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplica el límit de velocitat als parells amb LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2071"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplica un límit de velocitat a la sobrecàrrega de transport</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2064"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplica un límit de velocitat al protocol µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2136"/>
        <source>Privacy</source>
        <translation>Privacitat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2142"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Activa DHT (xarxa descentralitzada) per trobar més parells</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2152"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Intercanvia parells amb clients compatibles amb Bittorrent (µTorrent, Vuze...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2155"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilita l&apos;intercanvi de parells (PeX) per trobar-ne més </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2165"/>
        <source>Look for peers on your local network</source>
        <translation>Cerca parells a la xarxa local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2168"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilita el descobriment de parells locals per trobar-ne més</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2180"/>
        <source>Encryption mode:</source>
        <translation>Mode de xifratge:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2188"/>
        <source>Prefer encryption</source>
        <translation>Preferència de xifratge</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2193"/>
        <source>Require encryption</source>
        <translation>Requereix xifratge</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2198"/>
        <source>Disable encryption</source>
        <translation>Inhabilita el xifratge</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2223"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilita quan utilitzi un servidor intermediari o una connexió VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2226"/>
        <source>Enable anonymous mode</source>
        <translation>Habilita el mode anònim</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2233"/>
        <source> (&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Més informació&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2276"/>
        <source>Maximum active downloads:</source>
        <translation>Màxim de baixades actives:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2296"/>
        <source>Maximum active uploads:</source>
        <translation>Màxim de pujades actives:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2316"/>
        <source>Maximum active torrents:</source>
        <translation>Màxim de torrent actius:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2375"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>No comptis els torrents lents fora d&apos;aquests límits</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2385"/>
        <source>Share Ratio Limiting</source>
        <translation>Limitació de ràtio de compartició</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2391"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Sembra els torrents fins que la ràtio arribi a </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2411"/>
        <source>then</source>
        <translation>després</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2425"/>
        <source>Pause them</source>
        <translation>Pausa-ho</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2430"/>
        <source>Remove them</source>
        <translation>Suprimeix-ho</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2835"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Utilitza UPnP / NAT-PMP per reenviar el port des de l&apos;encaminador</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2876"/>
        <source>Certificate:</source>
        <translation>Certificat:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2888"/>
        <source>Import SSL Certificate</source>
        <translation>Importa el certificat SSl</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2929"/>
        <source>Key:</source>
        <translation>Clau:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2941"/>
        <source>Import SSL Key</source>
        <translation>Importa la clau SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2963"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Informació sobre els certificats&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3064"/>
        <source>Service:</source>
        <translation>Servei:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3087"/>
        <source>Register</source>
        <translation>Registre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3096"/>
        <source>Domain name:</source>
        <translation>Nom de domini:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="113"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Si s&apos;habiliten aquestes opcions, podeu &lt;strong&gt;perdre irrevocablement&lt;/strong&gt; els vostres fitxers .torrent!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="115"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Quan aquestes opcions estan habilitades, el qBittorent &lt;strong&gt;suprimirà&lt;/strong&gt; fitxers .torrent després que s&apos;hagin afegit correctament (la primera opció) o no (la segona) a la seva cua de baixada. Això s&apos;aplicarà &lt;strong&gt;no només&lt;/strong&gt; als fitxers oberts oberts a través de l&apos;acció de menú &amp;ldquo;Afegeix un torrent&amp;rdquo; sinó també als oberts a través de l&apos;&lt;strong&gt;associació de tipus de fitxer&lt;/strong&gt;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="120"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Si habiliteu la segona opció (&amp;ldquo;També quan l&apos;addició es cancel·la&amp;rdquo;) el fitxer .torrent &lt;strong&gt;se suprimirà&lt;/strong&gt; fins i tot si premeu &amp;ldquo;&lt;strong&gt;Cancel·la&lt;/strong&gt;&amp;rdquo; dins el diàleg &amp;ldquo;Afegeix un torrent&amp;rdquo;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="263"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Paràmetres admesos (sensible a majúscules):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="264"/>
        <source>%N: Torrent name</source>
        <translation>%N: nom del torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="265"/>
        <source>%L: Category</source>
        <translation>%L: categoria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="266"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Camí del contingut (igual que el camí d&apos;arrel per a torrents de fitxers múltiples)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="267"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: camí d&apos;arrel (camí del subdirectori del primer torrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="268"/>
        <source>%D: Save path</source>
        <translation>%D: camí de desament</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="269"/>
        <source>%C: Number of files</source>
        <translation>%C: nombre de fitxers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="270"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z mida del torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="271"/>
        <source>%T: Current tracker</source>
        <translation>%T: rastrejador actual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="272"/>
        <source>%I: Info hash</source>
        <translation>%I: informació del resum</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="273"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Tip: emmarqueu el paràmetre amb cometes per evitar que el text es talli a l&apos;espai en blanc (p.e., &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1451"/>
        <source>Select folder to monitor</source>
        <translation>Seleccioneu una carpeta a monitoritzar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1458"/>
        <source>Folder is already being monitored:</source>
        <translation>La carpeta ja s&apos;està monitoritzant:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1461"/>
        <source>Folder does not exist:</source>
        <translation>La carpeta no existeix:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1464"/>
        <source>Folder is not readable:</source>
        <translation>La carpeta no es pot llegir:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1475"/>
        <source>Adding entry failed</source>
        <translation>No s&apos;ha pogut afegir l&apos;entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="382"/>
        <location filename="../gui/optionsdlg.cpp" line="385"/>
        <location filename="../gui/optionsdlg.cpp" line="1503"/>
        <location filename="../gui/optionsdlg.cpp" line="1505"/>
        <source>Choose export directory</source>
        <translation>Trieu un directori d&apos;exportació</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="379"/>
        <location filename="../gui/optionsdlg.cpp" line="392"/>
        <location filename="../gui/optionsdlg.cpp" line="395"/>
        <source>Choose a save directory</source>
        <translation>Trieu un directori de desament</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="388"/>
        <source>Choose an IP filter file</source>
        <translation>Trieu un fitxer de filtre IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="389"/>
        <source>All supported filters</source>
        <translation>Tots els filtres suportats</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1539"/>
        <source>SSL Certificate</source>
        <translation>Certificat SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1589"/>
        <source>Parsing error</source>
        <translation>Error d&apos;anàlisi</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1589"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>No s&apos;ha pogut analitzar el filtratge IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1591"/>
        <source>Successfully refreshed</source>
        <translation>Actualitzat amb èxit</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1591"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>S&apos;ha analitzat satisfactòriament el filtre IP proporcionat: s&apos;han aplicat %1 regles.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1564"/>
        <source>Invalid key</source>
        <translation>Clau no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1564"/>
        <source>This is not a valid SSL key.</source>
        <translation>Aquesta no és una clau SSL vàlida.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1549"/>
        <source>Invalid certificate</source>
        <translation>Certificat no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="86"/>
        <source>Preferences</source>
        <translation>Preferències</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1539"/>
        <source>Import SSL certificate</source>
        <translation>Importa un certificat SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1549"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Aquest no és un certificat SSL vàlid.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1554"/>
        <source>Import SSL key</source>
        <translation>Importa una clau SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1554"/>
        <source>SSL key</source>
        <translation>Clau SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1714"/>
        <source>Time Error</source>
        <translation>Error de temps</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1714"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Els temps d&apos;inici i d&apos;acabament no poden ser els mateixos.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1723"/>
        <location filename="../gui/optionsdlg.cpp" line="1727"/>
        <source>Length Error</source>
        <translation>Error de longitud</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1723"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>El nom  d&apos;usuari de la interfície web ha de tenir almenys 3 caràcters.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1727"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>La contrasenya de la interfície web ha de tenir almenys 6 caràcters.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="280"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interessats (local) i muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="286"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="295"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interessats (parells) i muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="301"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="309"/>
        <source>optimistic unchoke</source>
        <translation>no mut optimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="316"/>
        <source>peer snubbed</source>
        <translation>parell rebutjat</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="323"/>
        <source>incoming connection</source>
        <translation>connexió d&apos;entrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="330"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>no interessats (local) i no muts (parells)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="337"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>no interessats (parells) i no muts (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="344"/>
        <source>peer from PEX</source>
        <translation>parell de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="351"/>
        <source>peer from DHT</source>
        <translation>parell de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="358"/>
        <source>encrypted traffic</source>
        <translation>trànsit xifrat</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="365"/>
        <source>encrypted handshake</source>
        <translation>salutació xifrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="379"/>
        <source>peer from LSD</source>
        <translation>parell de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Flags</source>
        <translation>Banderes</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Connection</source>
        <translation>Connexió</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Client</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocitat de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Rellevància</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Fitxers</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="154"/>
        <source>Column visibility</source>
        <translation>Visibilitat de les columnes</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="231"/>
        <source>Add a new peer...</source>
        <translation>Afegeix un parell nou...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="239"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>Ban peer permanently</source>
        <translation>Prohibició permanent de Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="252"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>S&apos;està afegint manualment el parell «%1»...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="256"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>No s&apos;ha pogut afegir el parell «%1» a aquest torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="288"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>S&apos;està prohibint manualment el parell «%1»...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="260"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="262"/>
        <source>Peer addition</source>
        <translation>Incorporació de parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="237"/>
        <source>Copy IP:port</source>
        <translation>Copia IP:port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="260"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>No s&apos;han pogut afegir alguns parells. Reviseu el registre per a més detalls.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="262"/>
        <source>The peers were added to this torrent.</source>
        <translation>S&apos;han afegit els parells al torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Esteu segur que voleu prohibir permanentment els parells seleccionats?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="279"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="279"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="62"/>
        <source>No peer entered</source>
        <translation>No s&apos;ha entrat cap parell</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="63"/>
        <source>Please type at least one peer.</source>
        <translation>Escriviu almenys un parell.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="73"/>
        <source>Invalid peer</source>
        <translation>Parell no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="74"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>El parell «%1» no és vàlid.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>Blanc: trossos no disponibles</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>Blau: trossos disponibles</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>Fitxers en aquest tros:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>Fitxer en aquest tros</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>Fitxer en aquests trossos</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Espera fins que les metadades estiguin disponibles per veure&apos;n la informació detallada.</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Mantingueu premuda la tecla de majúscules per veure&apos;n la informació detallada</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Connectors de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Connectors de cerca instal·lats:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="53"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="58"/>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="68"/>
        <location filename="../gui/search/pluginselectdlg.ui" line="134"/>
        <source>Enabled</source>
        <translation>Habilitat</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Avís: assegureu-vos que compliu les lleis de dret de còpia del vostre país quan baixeu torrents des de qualsevol d&apos;aquests motors de cerca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Podeu obtenir connectors de motors de cerca nous aquí: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Instal·la&apos;n un de nou</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Cerca actualitzacions</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="122"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Desinstal·la</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="162"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="224"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="283"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="166"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="205"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="228"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="287"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Uninstall warning</source>
        <translation>Alerta de desinstal·lació</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Alguns connectors no s&apos;han pogut instal·lar perquè ja estan inclosos al qBittorrent. Només es poden desinstal·lar els que heu afegit.
Aquests connectors han estat inhabilitats.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>Uninstall success</source>
        <translation>Desinstal·lació correcta</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Tots els connectors seleccionats s&apos;han instal·lat correctament</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="325"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Connectors instal·lats o actualitzats: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="345"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="352"/>
        <source>New search engine plugin URL</source>
        <translation>URL del nou connector de motor de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="346"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="353"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="350"/>
        <source>Invalid link</source>
        <translation>Enllaç no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="350"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>L&apos;enllaç no sembla portar a un connector de motor de cerca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="366"/>
        <source>Select search plugins</source>
        <translation>Seleccioneu els connectors de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="367"/>
        <source>qBittorrent search plugin</source>
        <translation>Connector de cerca del qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="325"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="424"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="438"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="469"/>
        <source>Search plugin update</source>
        <translation>Actualització del connector de recerca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="424"/>
        <source>All your plugins are already up to date.</source>
        <translation>Tots els connectors ja estan actualitzats.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="438"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>No s&apos;han pogut comprovar les actualitzacions del connector. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="452"/>
        <source>Search plugin install</source>
        <translation>Instal·lació del connector de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="452"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>No s&apos;ha pogut instal·lar el connector de motor de cerca &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>No s&apos;ha pogut actualitzar el connector de motor de cerca &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Font del connector</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Font del connector de recerca:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="36"/>
        <source>Local file</source>
        <translation>Fitxer local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="43"/>
        <source>Web link</source>
        <translation>Enllaç web</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="54"/>
        <source>Preview</source>
        <translation>Vista prèvia</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="61"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="96"/>
        <location filename="../gui/previewselectdialog.cpp" line="141"/>
        <source>Preview impossible</source>
        <translation>Vista prèvia impossible</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="96"/>
        <location filename="../gui/previewselectdialog.cpp" line="141"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>No es pot mostrar una vista prèvia d&apos;aquest fitxer</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&quot;%1&quot; no existeix.</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&quot;%1&quot; no apunta a un directori.</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&quot;%1&quot; no apunta a un fitxer.</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>No té permís de lectura a &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>No té permís de lectura a &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="118"/>
        <source>Not downloaded</source>
        <translation>No baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="136"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="188"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>No ho baixis</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="121"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Mixt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="124"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Màxim</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>Trackers</source>
        <translation>Rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="77"/>
        <source>HTTP Sources</source>
        <translation>Fonts HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="86"/>
        <source>Content</source>
        <translation>Contingut</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="97"/>
        <source>Speed</source>
        <translation>Velocitat</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Baixat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Disponibilitat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progrés:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferència</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Temps actiu:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Temps estimat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Llavors:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocitat de baixada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocitat de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Parells:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Límit de baixada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Límit de pujada:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Perdut:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Connexions:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentari:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1020"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1027"/>
        <source>Select None</source>
        <translation>Treure Seleccions</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1103"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1098"/>
        <source>High</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Ràtio de compartició:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Reanuncia:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Últim cop vist complet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Mida total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Trossos:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Creat per:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Afegit el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Completat el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Creat el:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Resum del torrent (hash):</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Camí de desament:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1093"/>
        <source>Maximum</source>
        <translation>Màxim</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1085"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <source>Do not download</source>
        <translation>No baixis</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="460"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="467"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (té %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="412"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="415"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 en aquesta sessió)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="424"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrat durant %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="431"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 màxim)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="444"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="448"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="452"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="456"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 de mitjana)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="595"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="596"/>
        <source>Open Containing Folder</source>
        <translation>Obre la carpeta contenidora</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="597"/>
        <source>Rename...</source>
        <translation>Canvia el nom...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="602"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="650"/>
        <source>New Web seed</source>
        <translation>Llavor web nova</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="656"/>
        <source>Remove Web seed</source>
        <translation>Suprimeix la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="658"/>
        <source>Copy Web seed URL</source>
        <translation>Copia l&apos;URL de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="659"/>
        <source>Edit Web seed URL</source>
        <translation>Edita l&apos;URL de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="687"/>
        <source>New name:</source>
        <translation>Nom nou:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="719"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="757"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Aquest nom ja està en ús. Indiqueu un nom diferent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="756"/>
        <source>The folder could not be renamed</source>
        <translation>No es pot canviar el nom de la carpeta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="860"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="88"/>
        <source>Filter files...</source>
        <translation>Filtra els fitxers...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="687"/>
        <source>Renaming</source>
        <translation>Canvi de nom</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="692"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="718"/>
        <source>Rename error</source>
        <translation>Error de canvi de nom</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="693"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>El nom està buit o conté caràcters prohibits. Si us plau, trieu-ne un altre de diferent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="803"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Llavor URL nova</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="804"/>
        <source>New URL seed:</source>
        <translation>Llavor URL nova:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="810"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="861"/>
        <source>This URL seed is already in the list.</source>
        <translation>Aquesta llavor URL ja és a la llista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="854"/>
        <source>Web seed editing</source>
        <translation>Edició de la llavor web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="855"/>
        <source>Web seed URL:</source>
        <translation>URL de la llavor web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="144"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>La vostra adreça IP s&apos;ha prohibit després de massa intents d&apos;autentificació fallits.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="497"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Error: «%1» no és un fitxer torrent vàlid.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="515"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Error: no s&apos;ha pogut afegir el torrent a la sessió.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="490"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Error d&apos;entrada / sortida: no s&apos;ha pogut crear un fitxer temporal.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="147"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 és un parametre de comanda de línia no conegut.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="157"/>
        <location filename="../app/main.cpp" line="166"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 ha de ser un sol paràmetre de comanda de línia.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="189"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>No podeu utilitzar %1: el qBittorrent ja s&apos;està executant per a aquest usuari.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="521"/>
        <source>Usage:</source>
        <translation>Utilització:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="524"/>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="158"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>El paràmetre &quot;%1&quot; ha de seguir la sintaxi &quot;%1=%2&quot;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="204"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>El paràmetre &quot;%1&quot; ha de seguir la sintaxi &quot;%1=%2&quot;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="218"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>S&apos;esperava un número enter a la variable d&apos;entorn &quot;%1&quot;, però s&apos;ha obtingut &quot;%2&quot;.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="271"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>El paràmetre &quot;%1&quot; ha de seguir la sintaxi &quot;%1=%2&quot;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="295"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>S&apos;esperava %1 a la variable d&apos;entorn &quot;%2&quot;, però s&apos;ha obtingut &quot;%3&quot;.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>port</source>
        <translation>port</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="420"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 ha d&apos;especificar un port vàlid (d&apos;1 a 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>Display program version and exit</source>
        <translation>Mostra la versió del programa i surt.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>Display this help message and exit</source>
        <translation>Mostra aquest missatge d&apos;ajuda i surt.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="530"/>
        <source>Change the Web UI port</source>
        <translation>Canvia el port de la interfície web.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="533"/>
        <source>Disable splash screen</source>
        <translation>Desactiva finestra de benvinguda</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="535"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Executa en mode dimoni (segon terme)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>dir</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Desa els fitxers de configuració a &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <location filename="../app/cmdoptions.cpp" line="556"/>
        <source>name</source>
        <translation>nom</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Desa els fitxers de configuració en directoris qBittorrent_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Entreu als fitxers de represa ràpida de libtorrent i feu els camins dels fitxers relatius al directori del perfil.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>files or URLs</source>
        <translation>fitxers o URLs</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Download the torrents passed by the user</source>
        <translation>Baixa els Torrents passats per l&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="563"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Especifica si el diàleg &quot;Afegeix un torrent nou&quot; s&apos;obre quan s&apos;afegeixi un torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Options when adding new torrents:</source>
        <translation>Opcions en afegir torrents nous:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>Drecera per a %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>path</source>
        <translation>camí</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Torrent save path</source>
        <translation>Camí de desament del torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Add torrents as started or paused</source>
        <translation>Afegeix torrents com a iniciats o pausats</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Skip hash check</source>
        <translation>Omet la comprovació del resum (hash)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Assignació de torrents a una categoria. Si la categoria no existeix, es crearà.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Download files in sequential order</source>
        <translation>Baixa fitxers en ordre seqüencial</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Download first and last pieces first</source>
        <translation>Baixa primer el primer i l&apos;últim tros.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="567"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Els valors de les opcions es poden proporcionar a través de variables d&apos;entorn. Per a l&apos;opció anomenada &quot;parameter-name&quot;, el nom de la variable d&apos;entorn és &quot;QBT_PARAMETER_NAME&quot; (en majúscules, &quot;-&quot; reemplaçat per &quot;_&quot;). Per passar valors d&apos;indicadors, establiu la variable a &quot;1&quot; o &quot;TRUE&quot;. Per exemple, per inhabilitar la pantalla de benvinguda: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Els paràmetres de la línia d&apos;ordres tenen prioritat per davant de les variables d&apos;entorn.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="583"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="354"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Executa l&apos;aplicació amb l&apos;opció -h per a llegir quant als paràmetres de comandes de línia.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="356"/>
        <source>Bad command line</source>
        <translation>Comanda de línia errònia</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="362"/>
        <source>Bad command line: </source>
        <translation>Comanda de línia errònia:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="375"/>
        <source>Legal Notice</source>
        <translation>Notes legals</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="376"/>
        <location filename="../app/main.cpp" line="386"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>El qBittorrent és un programa per a compartir fitxers. Quan s&apos;executa un torrent, les dades d&apos;aquest es fan disponibles als altres. Qualsevol contingut que compartiu serà sobre la vostra responsabilitat.

No es mostraran més avisos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="377"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Premeu la tecla %1 per a acceptar i continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="387"/>
        <source>Legal notice</source>
        <translation>Notes legals</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="388"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="389"/>
        <source>I Agree</source>
        <translation>Hi estic d&apos;acord</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="205"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>No s&apos;ha trobat el nom d&apos;amfitrió remot (nom d&apos;amfitrió no vàlid)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="207"/>
        <source>The operation was canceled</source>
        <translation>S&apos;ha cancel·lat l&apos;operació</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="209"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>El servidor remot ha tancat la connexió abans de temps, abans quela resposta fos rebuda i processada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="211"/>
        <source>The connection to the remote server timed out</source>
        <translation>Temps d&apos;espera esgotat per a la connexió amb el servidor remot</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="213"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Salutació SSL/TSL fallida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="215"/>
        <source>The remote server refused the connection</source>
        <translation>El servidor remot ha rebutjat la connexió</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="217"/>
        <source>The connection to the proxy server was refused</source>
        <translation>S&apos;ha rebutjat la connexió amb el servidor intermediari</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="219"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>El servidor intermediari ha tancat la connexió abans de temps</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="221"/>
        <source>The proxy host name was not found</source>
        <translation>El nom del servidor intermediari no s&apos;ha trobat</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="223"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>La connexió amb el servidor intermediari s&apos;ha esgotat, o el servidor no ha respost a temps a la sol·licitud enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="225"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>El servidor intermediari requereix autenticació per a atendre la sol·licitud, però no ha acceptat les credencials ofertes</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="227"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>S&apos;ha rebutjat l&apos;accés al contingut remot (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="229"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>L&apos;operació sol·licitada en el contingut remot no és permesa</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="231"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>El contingut remot no es troba al servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="233"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>El servidor remot requereix autenticació per servir el contingut, però les credencials proporcionades no són correctes</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="235"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>L&apos;accés a la xarxa de l&apos;API no pot complir amb la sol·licitud perquè el protocol és desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="237"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>L&apos;operació sol·licitada no és vàlida per a aquest protocol</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="239"/>
        <source>An unknown network-related error was detected</source>
        <translation>Error de xarxa desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="241"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Error de servidor intermediari desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="243"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Error de contingut remot desconegut</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="245"/>
        <source>A breakdown in protocol was detected</source>
        <translation>S&apos;ha detectat una error en el protocol</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="247"/>
        <source>Unknown error</source>
        <translation>Error desconegut</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="77"/>
        <source>Upgrade</source>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="67"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Heu actualitzat des d&apos;una versió antiga que desava les coses de manera diferent. Heu de migrar al nou sistema de desament i no podreu tornar a fer servir una versió més antiga de 3.3.0. Voleu continuar? [s/n]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="76"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Heu actualitzat des d&apos;una versió antiga que desava les coses de manera diferent. Heu de migrar al nou sistema de desada. Si continueu, no podreu tornar a fer servir una versió més antiga de la 3.3.0.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="182"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>No s&apos;ha pogut migrar el torrent amb la funció resum (hash): %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="185"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>No s&apos;ha pogut migrar el torrent. Nom del fitxer de represa ràpida no vàlid: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="244"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>S&apos;ha detectat una sortida de programa incorrecta. S&apos;usarà el fitxer de recuperació per restaurar-ne la configuració.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="307"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Hi ha hagut un error en intentar escriure el fitxer de configuració.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="309"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Hi ha hagut un error de format en intentar escriure al fitxer de configuració.</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="78"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="85"/>
        <source>Invalid data format.</source>
        <translation>Format de dades no vàlid.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="261"/>
        <source>Invalid RSS feed.</source>
        <translation>Canal RSS no vàlid.</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="264"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (línia: %2, columna: %3, desplaçament: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="140"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>El canal RSS amb l&apos;URL proporcionat ja existeix: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="159"/>
        <source>Cannot move root folder.</source>
        <translation>No es pot desplaçar la carpeta d&apos;arrel.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="166"/>
        <location filename="../base/rss/rss_session.cpp" line="204"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>No existeix l&apos;element %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="197"/>
        <source>Cannot delete root folder.</source>
        <translation>No es pot suprimir la carpeta d&apos;arrel.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="348"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Camí a l&apos;element RSS incorrecte: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="354"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>L&apos;element RSS amb el camí proporcionat ja existeix: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="362"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>No existeix la carpeta mare %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Ara la baixada de torrents RSS està inhabilitada! Podeu habilitar-la als paràmetres de l&apos;aplicació.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Subscripció nova</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Marca els elements llegits</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Actualitza els canals RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Actualitza-ho tot</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>Descarregador RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (doble clic per a baixar-los)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Canvia&apos;n el nom...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Canvia&apos;n el nom</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Subscripció nova...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Actualitza tots els canals</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Baixa el torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Obre l&apos;URL de notícies</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Copia l&apos;URL del canal</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Carpeta nova...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Please choose a folder name</source>
        <translation>Si us plau, trieu un nom de carpeta.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Folder name:</source>
        <translation>Nom de la carpeta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>New folder</source>
        <translation>Carpeta nova</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Please type a RSS feed URL</source>
        <translation>Si us plau, escriviu l&apos;URL d&apos;un canal RSS.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Feed URL:</source>
        <translation>URL del canal:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Deletion confirmation</source>
        <translation>Confirmació de supressió</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Esteu segur que voleu suprimir els canals RSS seleccionats?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Si us plau, trieu un nom nou per a aquest canal RSS.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>New feed name:</source>
        <translation>Nom del canal nou:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="391"/>
        <source>Rename failed</source>
        <translation>El canvi de nom ha fallat.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="454"/>
        <source>Date: </source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="456"/>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Select save location</source>
        <translation>Seleccioneu la ubicació de desament</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="151"/>
        <source>Monitored Folder</source>
        <translation>Carpeta monitorada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="154"/>
        <source>Override Save Location</source>
        <translation>Salta&apos;t la ubicació de desament</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Monitored folder</source>
        <translation>Carpeta monitorada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Default save location</source>
        <translation>Ubicació de desament per defecte</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="399"/>
        <source>Browse...</source>
        <translation>Explora...</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../base/searchengine.cpp" line="177"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Format de fitxer desconegut del connector de motor de cerca.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="191"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Ja hi ha instal·lada una versió més recent d&apos;aquest connector.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="219"/>
        <location filename="../base/searchengine.cpp" line="222"/>
        <source>Plugin is not supported.</source>
        <translation>El connector no està suportat.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="376"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>Actualitzar el servidor està temporalment inhabilitat. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="394"/>
        <location filename="../base/searchengine.cpp" line="396"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>No s&apos;ha pogut baixar el connector del fitxer. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="625"/>
        <source>An incorrect update info received.</source>
        <translation>S&apos;ha rebut informació d&apos;actualització incorrecta.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="649"/>
        <source>All categories</source>
        <translation>Totes les categories</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="650"/>
        <source>Movies</source>
        <translation>Pel·lícules</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="651"/>
        <source>TV shows</source>
        <translation>Programes de TV</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="652"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="653"/>
        <source>Games</source>
        <translation>Jocs</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="654"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="655"/>
        <source>Software</source>
        <translation>Programari</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="656"/>
        <source>Pictures</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="657"/>
        <source>Books</source>
        <translation>Llibres</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="682"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>El connector de cerca &quot;%1&quot; conté una cadena de versió no vàlida (&quot;%2&quot;)</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="60"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="74"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="75"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="76"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Sembradors</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="77"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechers</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="78"/>
        <source>Search engine</source>
        <translation>Motor de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="204"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Resultats (se&apos;n mostren &lt;i&gt;%1&lt;/i&gt; d&apos;un total de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="250"/>
        <source>Torrent names only</source>
        <translation>Només noms de torrents</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="251"/>
        <source>Everywhere</source>
        <translation>Arreu</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="262"/>
        <source>Searching...</source>
        <translation>S&apos;està cercant..</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="264"/>
        <source>Search has finished</source>
        <translation>La cerca s&apos;ha acabat.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="266"/>
        <source>Search aborted</source>
        <translation>Cerca avortada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="268"/>
        <source>An error occurred during search...</source>
        <translation>S&apos;ha produït un error durant la cerca...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="270"/>
        <source>Search returned no results</source>
        <translation>La cerca no ha trobat cap resultat</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="312"/>
        <source>Column visibility</source>
        <translation>Visibilitat de les columnes</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="14"/>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Resultats (xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="45"/>
        <source>Search in:</source>
        <translation>Cerca a:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everyhing returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Alguns motors de cerca també fan cerques en descripcions de torrents i i noms de fitxers de torrents. Si els resultats d&apos;aquesta cerca es mostren o no a la llista de sota ho controla aquest mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Arreu&lt;/span&gt; inhabilita el filtratge i mostra tot el que han trobat els motors de cerca.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Només noms de torrents&lt;/span&gt; mostra només els torrents el nom dels quals coincideix amb els termes de la consulta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Estableix un nombre mínim i màxim de sembradors permesos&lt;p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Llavors:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre mínim de llavors&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="116"/>
        <location filename="../gui/search/searchtab.ui" line="204"/>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nombre màxim de llavors&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/search/searchtab.ui" line="126"/>
        <location filename="../gui/search/searchtab.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Estableix una mida mínima i màxima de torrent permesa&lt;p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="170"/>
        <source>Size:</source>
        <translation>Mida:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mida mínima de torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Mida màxima de torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="265"/>
        <location filename="../gui/search/searchwidget.cpp" line="291"/>
        <location filename="../gui/search/searchwidget.cpp" line="358"/>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>No hi ha connectors de cerca instal·lats.
Cliqueu al botó &quot;Connectors de cerca...&quot; del cantó de baix a la dreta de la finestra per instal·lar-ne.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>Baixa</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>Vés a la pàgina de descripció</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>Copia l&apos;URL de la pàgina de descripció</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>Cerca connectors...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="87"/>
        <source>A phrase to search for.</source>
        <translation>Una frase per cercar..</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="88"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Els espais als termes de cerca es poden protegir amb cometes dobles.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="90"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Exemple:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="92"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: cerca &lt;b&gt;foo&lt;/b&gt; i &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="96"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: cerca &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="165"/>
        <source>All plugins</source>
        <translation>Tots els connectors</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="164"/>
        <source>Only enabled</source>
        <translation>Només habilitat</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="166"/>
        <source>Select...</source>
        <translation>Selecció...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <location filename="../gui/search/searchwidget.cpp" line="346"/>
        <location filename="../gui/search/searchwidget.cpp" line="364"/>
        <source>Search Engine</source>
        <translation>Motor de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Instal·leu Python per fer servir el motor de cerca.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="301"/>
        <source>Empty search pattern</source>
        <translation>Patró de recerca buit</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="301"/>
        <source>Please type a search pattern first</source>
        <translation>Escriviu primer un patró de cerca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="337"/>
        <source>Stop</source>
        <translation>Atura&apos;t</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="346"/>
        <source>Search has finished</source>
        <translation>La cerca s&apos;ha acabat.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="364"/>
        <source>Search has failed</source>
        <translation>La cerca ha fallat</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="110"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorrent es tancarà ara.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="111"/>
        <source>E&amp;xit Now</source>
        <translation>&amp;Surt ara</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="112"/>
        <source>Exit confirmation</source>
        <translation>Confirmació de sortida</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="115"/>
        <source>The computer is going to shutdown.</source>
        <translation>L&apos;ordinador s&apos;aturarà.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="116"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Atura ara</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="120"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>L&apos;ordinador entrarà en mode de suspensió.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="121"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Suspèn el sistema</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="122"/>
        <source>Suspend confirmation</source>
        <translation>Confirmació de suspensió</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="125"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>L&apos;ordinador entrarà en mode d&apos;hibernació.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="126"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Hiberna ara</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="127"/>
        <source>Hibernate confirmation</source>
        <translation>Confirmació d&apos;hibernació</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="137"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Podeu cancel·lar aquesta acció durant %1 segons.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="117"/>
        <source>Shutdown confirmation</source>
        <translation>Tanca la confirmació</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="81"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Total Upload</source>
        <translation>Total pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Download</source>
        <translation>Total baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Payload Upload</source>
        <translation>Càrrega de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Download</source>
        <translation>Càrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>Overhead Upload</source>
        <translation>Sobrecàrrega de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Download</source>
        <translation>Sobrecàrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>DHT Upload</source>
        <translation>Pujada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Download</source>
        <translation>Baixada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="72"/>
        <source>Tracker Upload</source>
        <translation>Pujada del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Download</source>
        <translation>Baixada del rastrejador</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Període:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minuts</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minuts</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 hores</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="106"/>
        <source>Select Graphs</source>
        <translation>Seleccioneu gràfics</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Upload</source>
        <translation>Total pujat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Download</source>
        <translation>Total baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Upload</source>
        <translation>Càrrega de pujada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Download</source>
        <translation>Càrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Upload</source>
        <translation>Pujada per damunt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Download</source>
        <translation>Sobrecàrrega de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Upload</source>
        <translation>Pujada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Download</source>
        <translation>Baixada DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Upload</source>
        <translation>Pujada del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Download</source>
        <translation>Baixada del rastrejador</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estadístiques</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estadístiques d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Connexions de parells totals:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Ràtio global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Temps total baixat:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Temps total pujat:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Despesa total (aquesta sessió):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estadístiques de memòria cau</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Resultats de lectura de la memòria cau:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Mitjana de temps a la cua:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Mida total de la memòria intermèdia (buffer):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estadístiques de rendiment</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Ordres d&apos;entrada / sortida a la cua:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Escriure memòria cau sobrecarregada:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Llegir memòria cau sobrecarregada:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Mida total a la cua:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="100"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>No hi ha connexions directes. Això pot indicar problemes en la configuració de la xarxa.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nodes</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>El qBittorrent s&apos;ha de reiniciar!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Estat de la connexió:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Fora de línia. Això normalment significa que el qBittorrent no pot contactar al port seleccionat per a les connexions entrants.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>En línea</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat alternativa</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Cliqueu per canviar als límits de velocitat normal</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocitat del límit global de baixada</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocitat límit global de pujada</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="124"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Tots (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="127"/>
        <source>Downloading (0)</source>
        <translation>Baixant (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="130"/>
        <source>Seeding (0)</source>
        <translation>Sembrant (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="133"/>
        <source>Completed (0)</source>
        <translation>Completats (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="136"/>
        <source>Resumed (0)</source>
        <translation>Represos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="139"/>
        <source>Paused (0)</source>
        <translation>Pausats (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="142"/>
        <source>Active (0)</source>
        <translation>Actius (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="145"/>
        <source>Inactive (0)</source>
        <translation>Inactius (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="148"/>
        <source>Errored (0)</source>
        <translation>Amb errors (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>All (%1)</source>
        <translation>Tots (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Downloading (%1)</source>
        <translation>Baixant (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="167"/>
        <source>Seeding (%1)</source>
        <translation>Sembrant (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="168"/>
        <source>Completed (%1)</source>
        <translation>Completats (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="169"/>
        <source>Paused (%1)</source>
        <translation>Pausats (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="170"/>
        <source>Resumed (%1)</source>
        <translation>Represos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="171"/>
        <source>Active (%1)</source>
        <translation>Actius (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="172"/>
        <source>Inactive (%1)</source>
        <translation>Inactius (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="173"/>
        <source>Errored (%1)</source>
        <translation>Amb errors (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="147"/>
        <source>Tags</source>
        <translation>Etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="258"/>
        <source>All</source>
        <translation>Tot</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>Untagged</source>
        <translation>Sense etiquetar</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="113"/>
        <source>Add tag...</source>
        <translation>Afegeix una etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove tag</source>
        <translation>Suprimeix l&apos;etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="126"/>
        <source>Remove unused tags</source>
        <translation>Suprimeix les etiquetes no usades</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Reprèn els torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="139"/>
        <source>Pause torrents</source>
        <translation>Pausa els torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="145"/>
        <source>Delete torrents</source>
        <translation>Suprimeix els torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>New Tag</source>
        <translation>Etiqueta nova</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>Tag:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Invalid tag name</source>
        <translation>Nom d&apos;etiqueta no vàlid</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>El nom d&apos;etiqueta &quot;%1&quot; no és vàlid.</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag exists</source>
        <translation>L&apos;etiqueta ja existeix.</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag name already exists.</source>
        <translation>El nom d&apos;etiqueta ja existeix.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Propietats de les categories del torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Camí de desament:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>Categoria nova</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>El nom de la categoria no és vàlid</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>El nom de la categoria no pot incluore &quot;\&quot;.
El nom de la categoria no pot començar ni acabar amb &quot;/&quot;.
El nom de la categoria no pot incloure la seqüència &quot;//&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation>Error de creació de la categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Ja existeix una categoria amb aquest nom.
Si us plau, trieu-ne un altre i torneu-ho a provar.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Progress</source>
        <translation>Progrés</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Download Priority</source>
        <translation>Prioritat de baixada</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Remaining</source>
        <translation>Restant</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Availability</source>
        <translation>Disponibilitat</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="68"/>
        <source>Create Torrent</source>
        <translation>Crea un torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="146"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Raó: el camí al fitxer o la carpeta no és llegible.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="146"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="188"/>
        <source>Torrent creation failed</source>
        <translation>Ha fallat la creació del torrent.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="153"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Fitxers torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="153"/>
        <source>Select where to save the new torrent</source>
        <translation>Seleccioneu on desar el torrent nou.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="176"/>
        <source>Reason: %1</source>
        <translation>Raó: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="188"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Raó: el torrent creat no és vàlid. No s&apos;afegirà a la llista de baixades.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="199"/>
        <source>Torrent creator</source>
        <translation>Creador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="199"/>
        <source>Torrent created:</source>
        <translation>Creació del torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Creador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>Seleccioneu un fitxer o una carpeta per compartir.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="31"/>
        <source>Path:</source>
        <translation>Camí:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[Àrea per arrossegar-hi i deixar-hi anar elements]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="68"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="109"/>
        <source>Select file</source>
        <translation>Seleccioneu un fitxer</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="75"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="102"/>
        <source>Select folder</source>
        <translation>Seleccioneu una carpeta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="87"/>
        <source>Settings</source>
        <translation>Paràmetres</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="95"/>
        <source>Piece size:</source>
        <translation>Mida del tros:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="109"/>
        <source>Auto</source>
        <translation>Automàtic</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="172"/>
        <source>Calculate number of pieces:</source>
        <translation>Càlcul del nombre de trossos:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="201"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Torrent privat (no es distribuirà per xarxa DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="208"/>
        <source>Start seeding immediately</source>
        <translation>Inicia la sembra immediatament</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="218"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignora els límits de ràtio de compartició per a aquest torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="228"/>
        <source>Fields</source>
        <translation>Camps</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="234"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Podeu separar els nivells de rastrejadors o grups amb una línia en blanc.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="244"/>
        <source>Web seed URLs:</source>
        <translation>URLs de llavor web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Tracker URLs:</source>
        <translation>URLs de rastrejador:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Comments:</source>
        <translation>Comentaris:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="284"/>
        <source>Progress:</source>
        <translation>Progrés:</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Fet</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Vel. de baixada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Vel. de pujada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Ràtio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Temps estimat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Tags</source>
        <translation>Etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Afegit el</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completat a</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Tracker</source>
        <translation>Rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Límit baixada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Límit pujada</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Baixats</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Pujats</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Baixades durant la sessió</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Pujades durant la sessió</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restants</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Temps actiu</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Camí de desament:</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Límit de ràtio</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Últim cop vist complet</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Darrera activitat</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="125"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Mida total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="193"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Tots (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="196"/>
        <source>Trackerless (0)</source>
        <translation>Sense rastrejadors (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="199"/>
        <source>Error (0)</source>
        <translation>Errors (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="202"/>
        <source>Warning (0)</source>
        <translation>Advertències (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="246"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="301"/>
        <source>Trackerless (%1)</source>
        <translation>Sense rastrejadors (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="339"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="371"/>
        <source>Error (%1)</source>
        <translation>Errors (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="352"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="386"/>
        <source>Warning (%1)</source>
        <translation>Advertències (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="446"/>
        <source>Resume torrents</source>
        <translation>Reprèn els torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="447"/>
        <source>Pause torrents</source>
        <translation>Pausa els torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="448"/>
        <source>Delete torrents</source>
        <translation>Suprimeix els torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="482"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="496"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Tots (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="588"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="589"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="590"/>
        <source>Received</source>
        <translation>Rebut</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="591"/>
        <source>Seeds</source>
        <translation>Llavors</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="592"/>
        <source>Peers</source>
        <translation>Parells</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="593"/>
        <source>Downloaded</source>
        <translation>Baixat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="594"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="255"/>
        <location filename="../gui/properties/trackerlist.cpp" line="345"/>
        <source>Working</source>
        <translation>Treballant</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="256"/>
        <source>Disabled</source>
        <translation>Inhabilitat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="277"/>
        <source>This torrent is private</source>
        <translation>Aquest torrent és privat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="349"/>
        <source>Updating...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="353"/>
        <source>Not working</source>
        <translation>Aturat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="357"/>
        <source>Not contacted yet</source>
        <translation>Encara sense connexió</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="458"/>
        <source>Tracker URL:</source>
        <translation>URL del rastrejador:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="458"/>
        <source>Tracker editing</source>
        <translation>Edició del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="463"/>
        <location filename="../gui/properties/trackerlist.cpp" line="473"/>
        <source>Tracker editing failed</source>
        <translation>Edició del rastrejador fallada</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="463"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>L&apos;URL del rastrejador introduït no és vàlid.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="473"/>
        <source>The tracker URL already exists.</source>
        <translation>L&apos;URL del rastrejador ja existeix.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="527"/>
        <source>Add a new tracker...</source>
        <translation>Afegeix un rastrejador nou...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="533"/>
        <source>Copy tracker URL</source>
        <translation>Copia la URL del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="534"/>
        <source>Edit selected tracker URL</source>
        <translation>Edita l&apos;URL del rastrejador seleccionat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="539"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Força el reanunci als rastrejadors seleccionats</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="541"/>
        <source>Force reannounce to all trackers</source>
        <translation>Força repetir l&apos;anunci per a tots els rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="614"/>
        <source>Column visibility</source>
        <translation>Visibilitat de columnes</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="532"/>
        <source>Remove tracker</source>
        <translation>Suprimeix el rastrejador</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diàleg per a afegir rastrejadors</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Llista de rastrejadors a afegir (un per línia):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Llista d&apos;URL de µTorrent compatibles:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="84"/>
        <source>I/O Error</source>
        <translation>Error d&apos;entrada / sortida</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="84"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Error en intentar obrir el fitxer baixat.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="122"/>
        <source>No change</source>
        <translation>Sense canvis</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="122"/>
        <source>No additional trackers were found.</source>
        <translation>No s&apos;ha trobat cap rastrejador addicional.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="130"/>
        <source>Download error</source>
        <translation>Error de baixada</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="130"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>No s&apos;ha pogut baixar la llista de rastrejadors Raó: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="232"/>
        <source>Downloading</source>
        <translation>S&apos;està baixant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="238"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Baixant metadades</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="244"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Distribuint</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="270"/>
        <source>Paused</source>
        <translation>Pausat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="255"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>A la cua</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="248"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Sembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="235"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Detinguda</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="241"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Baixant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="251"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>Sembrant [F] </translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="259"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificant</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="263"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>A la cua per comprovar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="267"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>S&apos;estan comprovant les dades de represa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="273"/>
        <source>Completed</source>
        <translation>Completat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="276"/>
        <source>Missing Files</source>
        <translation>Fitxers absents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="279"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Amb errors</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="128"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (sembrat durant %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="189"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>fa %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="576"/>
        <source>Status</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="584"/>
        <source>Categories</source>
        <translation>Categories</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="603"/>
        <source>Tags</source>
        <translation>Etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="621"/>
        <source>Trackers</source>
        <translation>Rastrejadors</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="672"/>
        <source>Column visibility</source>
        <translation>Visibilitat de columnes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="386"/>
        <source>Choose save path</source>
        <translation>Trieu un camí de desament</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="591"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Límit de velocitat de baixada de torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="616"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Límit de velocitat de pujada de torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="660"/>
        <source>Recheck confirmation</source>
        <translation>Ratifica la confirmació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="660"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Esteu segur que voleu tornar a comprovar els torrents seleccionats?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="802"/>
        <source>Rename</source>
        <translation>Canvia el nom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="802"/>
        <source>New name:</source>
        <translation>Nou nom:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="837"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Reprèn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="841"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Força la represa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="839"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="393"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>Estableix la ubicació: s&apos;està movent «%1», de «%2» a «%3»</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="744"/>
        <source>Add Tags</source>
        <translation>Afegeix etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="752"/>
        <source>Remove All Tags</source>
        <translation>Suprimeix totes les etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="752"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Voleu suprimir totes les etiquetes dels torrents seleccionats?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="766"/>
        <source>Comma-separated tags:</source>
        <translation>Etiquetes separades per comes:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="773"/>
        <source>Invalid tag</source>
        <translation>Etiqueta no vàlida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="774"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>El nom d&apos;etiqueta &quot;%1&quot; no és vàlid.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="843"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="845"/>
        <source>Preview file...</source>
        <translation>Previsualitza el fitxer...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="847"/>
        <source>Limit share ratio...</source>
        <translation>Límit de ràtio de compartició...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="849"/>
        <source>Limit upload rate...</source>
        <translation>Ràtio límit de pujada...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="851"/>
        <source>Limit download rate...</source>
        <translation>Ràtio límit de baixada...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="853"/>
        <source>Open destination folder</source>
        <translation>Obre la carpeta de destinació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="855"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Moure amunt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="857"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Moure avall</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="859"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Moure al principi</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="861"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Moure al final</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="863"/>
        <source>Set location...</source>
        <translation>Estableix una destinació...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Copy name</source>
        <translation>Copia el nom</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Copy hash</source>
        <translation>Copia&apos;n l&apos;etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Download first and last pieces first</source>
        <translation>Baixa primer el primer i l&apos;últim tros.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="884"/>
        <source>Automatic Torrent Management</source>
        <translation>Gestió automàtica dels torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="886"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>El mode automàtic significa que diverses propietats dels torrent (p. ex. els camins de desament) es configuraran segons la categoria associada.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="993"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="994"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nou...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="995"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Restableix</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1012"/>
        <source>Tags</source>
        <translation>Etiquetes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1013"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Afegeix...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1014"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Suprimeix-ho tot</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1075"/>
        <source>Priority</source>
        <translation>Prioritat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="865"/>
        <source>Force recheck</source>
        <translation>Força la verificació</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Copy magnet link</source>
        <translation>Copia l&apos;enllaç magnètic</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Super seeding mode</source>
        <translation>Mode de supersembra</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="876"/>
        <source>Rename...</source>
        <translation>Canvia el nom...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="878"/>
        <source>Download in sequential order</source>
        <translation>Baixa en ordre seqüencial</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Limitació de ràtio de pujada / baixada</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global share limit</source>
        <translation>Usa el límit de compartició global</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no share limit</source>
        <translation>No estableixis límit de compartició</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set share limit to</source>
        <translation>Estableix el límit de compartició a</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="100"/>
        <source>ratio</source>
        <translation>ràtio</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="107"/>
        <source>minutes</source>
        <translation>minuts</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="81"/>
        <source>No share limit method selected</source>
        <translation>No s&apos;ha seleccionat mètode de límit de compartició.</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="82"/>
        <source>Please select a limit method first</source>
        <translation>Si us plau, seleccioneu primer un mètode de límit.</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="834"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Interfície web, establiment de la ubicació: movent &quot;%1&quot;, de &quot;%2&quot; a &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="911"/>
        <source>Incorrect category name</source>
        <translation>El nom de la categoria no és vàlid.</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Interfície web: configuració d&apos;HTTPS correcta.</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Interfície web: ha fallat la configuració d&apos;HTTPS, es torna a HTTP.</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Interfície web: ara s&apos;escolta la IP %1, port %2.</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Interfície web: no es pot vincular a la IP %1, port %2. Raó: %3</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="67"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Un client BitTorrent avançat programat en C++, basat en el joc d&apos;eines Qt i libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="68"/>
        <source>Copyright %1 2006-2017 The qBittorrent project</source>
        <translation>Copyright %1 2006-2017 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="69"/>
        <source>Home Page:</source>
        <translation>Pàgina principal:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="70"/>
        <source>Forum:</source>
        <translation>Fòrum:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="71"/>
        <source>Bug Tracker:</source>
        <translation>Rastrejador d&apos;errors:</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Afegeix parells:</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Llista de parells per afegir (una IP per línia):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port / [IPv6]:port</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autentificació del rastrejador</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Rastrejador:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Inicia sessió</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Usuari:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Contrasenya:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Confirmació de supressió</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Recorda sempre aquesta elecció</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Suprimeix també el fitxer del disc dur</translation>
    </message>
</context>
<context>
    <name>confirmShutdownDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>No ho tornis a mostrar.</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Afegeix enllaços de torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Baixa des d&apos;URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Un enllaç per línia (es permeten enllaços HTTP, enllaços magnètics i informació de funcions resum (hash))</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="55"/>
        <source>Download</source>
        <translation>Baixa</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="109"/>
        <source>No URL entered</source>
        <translation>No s&apos;ha escrit cap URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="109"/>
        <source>Please type at least one URL.</source>
        <translation>Escriviu almenys un URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Informació de la caiguda</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="93"/>
        <source>Downloads</source>
        <translation>Baixades</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="90"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="91"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="283"/>
        <source>Python not detected</source>
        <translation>Python no detectat</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="312"/>
        <source>Python version: %1</source>
        <translation>Versió de Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="325"/>
        <source>Normalized Python version: %1</source>
        <translation>Versió de Python normalitzada: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="371"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="463"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="468"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="364"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconegut</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="123"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>El qBittorrent tancarà l&apos;ordinador ara, perquè s&apos;han completat totes les baixades.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="454"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt;1m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="458"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="798"/>
        <source>Working</source>
        <translation>Operatiu</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="796"/>
        <source>Updating...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="800"/>
        <source>Not working</source>
        <translation>No operatiu</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="794"/>
        <source>Not contacted yet</source>
        <translation>Encara no connectat</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Selecció de vista prèvia</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Els següents fitxers permeten previsualització, seleccioneu-ne algun:</translation>
    </message>
</context>
<context>
    <name>trackerLogin</name>
    <message>
        <location filename="../gui/trackerlogin.cpp" line="44"/>
        <source>Log in</source>
        <translation>Entreu</translation>
    </message>
</context>
</TS>
